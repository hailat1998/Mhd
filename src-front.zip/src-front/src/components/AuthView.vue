<template>
  <div class="auth-page">
    <div class="auth-container">
      <transition name="fade" mode="out-in">
        <div v-if="isLogin" key="login" class="auth-form">
          <h2 class="form-title">Welcome Back</h2>
          
          <form @submit.prevent="handleLogin">
            <div class="form-group">
              <label class="form-label" for="login-username">Username</label>
              <input 
                id="login-username"
                v-model="loginForm.username" 
                type="text" 
                class="form-input" 
                placeholder="Enter your username"
                required
              >
            </div>
            
            <div class="form-group">
              <label class="form-label" for="login-password">Password</label>
              <input 
                id="login-password"
                v-model="loginForm.password" 
                type="password" 
                class="form-input" 
                placeholder="Enter your password"
                required
              >
            </div>

            <div v-if="loginError" class="error-message">
              {{ loginError }}
            </div>
            
            <button type="submit" class="submit-btn" :class="{ loading: isLoading }">
              {{ isLoading ? 'Signing in...' : 'Sign In' }}
            </button>
          </form>
          
          <div class="switch-text">
            Don't have an account? 
            <a @click="switchToSignup" class="switch-link">Sign up</a>
          </div>
        </div>

        <div v-else key="signup" class="auth-form">
          <h2 class="form-title">Create Account</h2>
          
          <form @submit.prevent="handleSignup">
            <div class="form-group">
              <label class="form-label" for="signup-name">Name</label>
              <input 
                id="signup-name"
                v-model="signupForm.name" 
                type="text" 
                class="form-input" 
                placeholder="Enter your full name"
                required
              >
            </div>
            
            <div class="form-group">
              <label class="form-label" for="signup-username">Username</label>
              <input 
                id="signup-username"
                v-model="signupForm.username" 
                type="text" 
                class="form-input" 
                placeholder="Choose a username"
                required
              >
            </div>
            
            <div class="form-group">
              <label class="form-label" for="signup-password">Password</label>
              <input 
                id="signup-password"
                v-model="signupForm.password" 
                type="password" 
                class="form-input" 
                placeholder="Create a password"
                required
              >
            </div>

            <div v-if="signupError" class="error-message">
              {{ signupError }}
            </div>

            <div v-if="signupSuccess" class="success-message">
              Account created successfully! You can now sign in.
            </div>
            
            <button type="submit" class="submit-btn" :class="{ loading: isLoading }">
              {{ isLoading ? 'Creating account...' : 'Sign Up' }}
            </button>
          </form>
          
          <div class="switch-text">
            Already have an account? 
            <a @click="switchToLogin" class="switch-link">Sign in</a>
          </div>
        </div>
      </transition>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'

const isLogin = ref(true)
const isLoading = ref(false)
const loginError = ref('')
const signupError = ref('')
const signupSuccess = ref(false)

const loginForm = reactive({
  username: '',
  password: ''
})

const signupForm = reactive({
  name: '',
  username: '',
  password: ''
})

const switchToSignup = () => {
  clearMessages()
  isLogin.value = false
}

const switchToLogin = () => {
  clearMessages()
  isLogin.value = true
}

const clearMessages = () => {
  loginError.value = ''
  signupError.value = ''
  signupSuccess.value = false
}

const handleLogin = async () => {
  if (!loginForm.username || !loginForm.password) {
    loginError.value = 'Please fill in all fields'
    return
  }

  isLoading.value = true
  loginError.value = ''

  // Simulate API call
  setTimeout(() => {
    // Mock validation - in real app, this would be an API call
    if (loginForm.username === 'demo' && loginForm.password === 'demo') {
      alert('Login successful! Welcome back!')
      resetLoginForm()
    } else {
      loginError.value = 'Invalid username or password'
    }
    isLoading.value = false
  }, 1500)
}

const handleSignup = async () => {
  if (!signupForm.name || !signupForm.username || !signupForm.password) {
    signupError.value = 'Please fill in all fields'
    return
  }

  if (signupForm.password.length < 6) {
    signupError.value = 'Password must be at least 6 characters long'
    return
  }

  isLoading.value = true
  signupError.value = ''
  signupSuccess.value = false

  // Simulate API call
  setTimeout(() => {
    // Mock validation - in real app, this would be an API call
    if (signupForm.username === 'demo') {
      signupError.value = 'Username already exists'
    } else {
      signupSuccess.value = true
      setTimeout(() => {
        switchToLogin()
        resetSignupForm()
      }, 2000)
    }
    isLoading.value = false
  }, 1500)
}

const resetLoginForm = () => {
  loginForm.username = ''
  loginForm.password = ''
}

const resetSignupForm = () => {
  signupForm.name = ''
  signupForm.username = ''
  signupForm.password = ''
}
</script>

<style scoped>
.auth-page {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
}

.auth-container {
  background: white;
  border-radius: 20px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  overflow: hidden;
  width: 100%;
  max-width: 450px;
  position: relative;
  min-height: 500px;
}

.auth-form {
  padding: 40px;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.form-title {
  font-size: 28px;
  font-weight: 700;
  color: #2c3e50;
  margin-bottom: 30px;
  text-align: center;
}

.form-group {
  margin-bottom: 20px;
}

.form-label {
  display: block;
  margin-bottom: 8px;
  color: #34495e;
  font-weight: 500;
  font-size: 14px;
}

.form-input {
  width: 100%;
  padding: 12px 16px;
  border: 2px solid #3498db;
  border-radius: 10px;
  font-size: 16px;
  transition: all 0.3s ease;
  background: #f8f9fa;
}

.form-input:focus {
  outline: none;
  border-color: #2980b9;
  background: white;
  box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
}

.form-input::placeholder {
  color: #95a5a6;
}

.submit-btn {
  width: 100%;
  padding: 14px;
  background: linear-gradient(135deg, #3498db, #2980b9);
  color: white;
  border: none;
  border-radius: 10px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-top: 10px;
}

.submit-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(52, 152, 219, 0.3);
}

.submit-btn:active {
  transform: translateY(0);
}

.submit-btn.loading {
  opacity: 0.7;
  pointer-events: none;
}

.switch-text {
  text-align: center;
  margin-top: 20px;
  color: #7f8c8d;
  font-size: 14px;
}

.switch-link {
  color: #3498db;
  text-decoration: none;
  font-weight: 600;
  cursor: pointer;
  transition: color 0.3s ease;
}

.switch-link:hover {
  color: #2980b9;
  text-decoration: underline;
}

/* Transitions */
.fade-enter-active, .fade-leave-active {
  transition: all 0.5s ease;
}

.fade-enter-from {
  opacity: 0;
  transform: translateX(50px);
}

.fade-leave-to {
  opacity: 0;
  transform: translateX(-50px);
}

/* Mobile responsive */
@media (max-width: 480px) {
  .auth-page {
    padding: 10px;
  }

  .auth-container {
    max-width: 100%;
    min-height: 450px;
  }

  .auth-form {
    padding: 30px 20px;
  }

  .form-title {
    font-size: 24px;
    margin-bottom: 25px;
  }

  .form-input {
    padding: 10px 14px;
    font-size: 15px;
  }

  .submit-btn {
    padding: 12px;
    font-size: 15px;
  }

  .switch-text {
    font-size: 13px;
  }
}

@media (max-width: 360px) {
  .auth-form {
    padding: 25px 15px;
  }

  .form-title {
    font-size: 22px;
  }

  .form-input {
    padding: 9px 12px;
    font-size: 14px;
  }

  .submit-btn {
    padding: 11px;
    font-size: 14px;
  }
}

.error-message {
  color: #e74c3c;
  font-size: 14px;
  margin-top: 5px;
  text-align: center;
}

.success-message {
  color: #27ae60;
  font-size: 14px;
  margin-top: 5px;
  text-align: center;
}
</style>
