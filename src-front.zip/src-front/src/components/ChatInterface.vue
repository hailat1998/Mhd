<template>
  <div class="chat-interface">
    <!-- Messages Container -->
    <div class="messages-container" ref="messagesContainer">
      <div class="messages-list">
        <div 
          v-for="message in messages" 
          :key="message.id" 
          :class="['message', message.type, { 'has-attachment': message.attachment, 'show-actions': activeMessageId === message.id }]"
          @mouseenter="showMessageActions(message.id)"
          @mouseleave="hideMessageActions"
          @click="toggleMessageActions(message.id)"
        >
          <div v-if="message.type === 'received'" class="message-wrapper">
            <!-- Receiver Avatar -->
            <div v-if="message.receiverAvatar" class="receiver-avatar">
              <img v-if="message.receiverAvatar.photo" :src="message.receiverAvatar.photo" :alt="message.receiverAvatar.name" />
              <div v-else class="avatar-initials">
                {{ getInitials(message.receiverAvatar.name) }}
              </div>
            </div>
            
            <div class="message-content-container">
              <div class="message-content">
                <p v-if="!message.isEditing" class="message-text">{{ message.text }}</p>
                <div v-else class="edit-container">
                  <input 
                    v-model="editingText"
                    @keydown.enter="saveEdit(message.id)"
                    @keydown.escape="cancelEdit"
                    @click.stop
                    type="text"
                    class="edit-input"
                    ref="editInput"
                  />
                  <div class="edit-actions">
                    <button @click.stop="saveEdit(message.id)" class="save-btn">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="20,6 9,17 4,12"></polyline>
                      </svg>
                    </button>
                    <button @click.stop="cancelEdit" class="cancel-btn">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                      </svg>
                    </button>
                  </div>
                </div>
                <AttachmentDisplay 
                  v-if="message.attachment" 
                  :attachment="message.attachment" 
                />
              </div>
              <div class="message-time">{{ formatTime(message.timestamp) }}</div>
            </div>
          </div>
          
          <!-- Sent messages (no wrapper needed) -->
          <div v-else class="message-content-container">
            <div class="message-content">
              <p v-if="!message.isEditing" class="message-text">{{ message.text }}</p>
              <div v-else class="edit-container">
                <input 
                  v-model="editingText"
                  @keydown.enter="saveEdit(message.id)"
                  @keydown.escape="cancelEdit"
                  @click.stop
                  type="text"
                  class="edit-input"
                  ref="editInput"
                />
                <div class="edit-actions">
                  <button @click.stop="saveEdit(message.id)" class="save-btn">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <polyline points="20,6 9,17 4,12"></polyline>
                    </svg>
                  </button>
                  <button @click.stop="cancelEdit" class="cancel-btn">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <line x1="18" y1="6" x2="6" y2="18"></line>
                      <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                  </button>
                </div>
              </div>
              <AttachmentDisplay 
                v-if="message.attachment" 
                :attachment="message.attachment" 
              />
            </div>
            <div class="message-time">{{ formatTime(message.timestamp) }}</div>
          </div>
          
          <!-- Message Actions -->
          <div :class="['message-actions', { 'visible': activeMessageId === message.id }]" @click.stop>
            <button v-if="message.type === 'sent'" @click="editMessage(message.id)" class="action-btn edit-btn">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
              </svg>
            </button>
            <button @click="deleteMessage(message.id)" class="action-btn delete-btn">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="3,6 5,6 21,6"></polyline>
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Input Area -->
    <div class="input-area">
      <!-- Attachment Preview -->
      <div v-if="selectedFile" class="attachment-preview">
        <div class="attachment-info">
          <svg class="file-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
            <polyline points="14,2 14,8 20,8"></polyline>
          </svg>
          <div class="file-details">
            <div class="file-name">{{ selectedFile.name }}</div>
            <div class="file-type">{{ selectedFile.type || 'Unknown type' }}</div>
          </div>
          <button @click="removeFile" class="remove-file">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
      </div>

      <!-- Input Controls -->
      <div class="input-controls">
        <button @click="triggerFileInput" class="attach-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path>
          </svg>
        </button>
        
        <input 
          ref="fileInput"
          type="file"
          @change="handleFileSelect"
          style="display: none"
        />
        
        <div class="text-input-container">
          <input 
            v-model="messageText"
            @keydown.enter="sendMessage"
            @keydown.ctrl.enter="addNewLine"
            type="text"
            placeholder="Type a message..."
            class="message-input"
            ref="messageInput"
          />
        </div>
        
        <button @click="sendMessage" :disabled="!messageText.trim() && !selectedFile" class="send-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="22" y1="2" x2="11" y2="13"></line>
            <polygon points="22,2 15,22 11,13 2,9 22,2"></polygon>
          </svg>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, nextTick, onMounted } from 'vue'
import AttachmentDisplay from './AttachmentDisplay.vue'

interface Attachment {
  name: string
  type: string
  path: string
  caption?: string
}

interface Message {
  id: number
  text: string
  type: 'sent' | 'received'
  timestamp: Date
  attachment?: Attachment
  isEditing?: boolean
  receiverAvatar?: {
    name: string
    photo?: string
  }
}

const messages = reactive<Message[]>([
  {
    id: 1,
    text: 'Hey! How are you doing?',
    type: 'received',
    timestamp: new Date(Date.now() - 1000 * 60 * 30),
    receiverAvatar: {
      name: 'Alice Smith',
      photo: undefined
    }
  },
  {
    id: 2,
    text: "I'm doing great! Just working on some new features. How about you?",
    type: 'sent',
    timestamp: new Date(Date.now() - 1000 * 60 * 25),
  },
  {
    id: 3,
    text: 'That sounds interesting! I wanted to share this document with you.',
    type: 'received',
    timestamp: new Date(Date.now() - 1000 * 60 * 20),
    receiverAvatar: {
      name: 'Alice Smith',
      photo: undefined
    },
    attachment: {
      name: 'project-proposal.pdf',
      type: 'application/pdf',
      path: '/files/project-proposal.pdf',
      caption: 'Q4 Project Proposal'
    }
  },
  {
    id: 4,
    text: 'Thanks! I\'ll take a look at it right away.',
    type: 'sent',
    timestamp: new Date(Date.now() - 1000 * 60 * 15),
  }
])

const messageText = ref('')
const selectedFile = ref<File | null>(null)
const messagesContainer = ref<HTMLElement | null>(null)
const messageInput = ref<HTMLInputElement | null>(null)
const fileInput = ref<HTMLInputElement | null>(null)
const editInput = ref<HTMLInputElement | null>(null)
const activeMessageId = ref<number | null>(null)
const editingText = ref('')
const hoverTimeout = ref<NodeJS.Timeout | null>(null)

let messageIdCounter = messages.length + 1

const getInitials = (name: string): string => {
  return name
    .split(' ')
    .map(word => word.charAt(0).toUpperCase())
    .slice(0, 2)
    .join('')
}

const formatTime = (timestamp: Date): string => {
  const now = new Date()
  const diff = now.getTime() - timestamp.getTime()
  const minutes = Math.floor(diff / (1000 * 60))
  const hours = Math.floor(diff / (1000 * 60 * 60))
  const days = Math.floor(diff / (1000 * 60 * 60 * 24))

  if (minutes < 1) return 'Just now'
  if (minutes < 60) return `${minutes}m ago`
  if (hours < 24) return `${hours}h ago`
  if (days < 7) return `${days}d ago`
  return timestamp.toLocaleDateString()
}

const scrollToBottom = () => {
  nextTick(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
    }
  })
}

const sendMessage = () => {
  if (!messageText.value.trim() && !selectedFile.value) return

  const newMessage: Message = {
    id: messageIdCounter++,
    text: messageText.value.trim(),
    type: 'sent',
    timestamp: new Date(),
  }

  // Add attachment if present
  if (selectedFile.value) {
    newMessage.attachment = {
      name: selectedFile.value.name,
      type: selectedFile.value.type || 'Unknown type',
      path: URL.createObjectURL(selectedFile.value),
      caption: `Shared file: ${selectedFile.value.name}`
    }
  }

  messages.push(newMessage)
  messageText.value = ''
  selectedFile.value = null
  
  if (fileInput.value) {
    fileInput.value.value = ''
  }

  scrollToBottom()
  focusInput()

  // Simulate a received message after a delay
  setTimeout(() => {
    simulateReceivedMessage()
  }, 2000)
}

const simulateReceivedMessage = () => {
  const responses = [
    'That sounds great!',
    'I agree with you.',
    'Thanks for sharing!',
    'Let me think about that.',
    'Interesting point!',
    'I\'ll get back to you on this.'
  ]
  
  const randomResponse = responses[Math.floor(Math.random() * responses.length)]
  
  const receivedMessage: Message = {
    id: messageIdCounter++,
    text: randomResponse,
    type: 'received',
    timestamp: new Date(),
  }
  
  messages.push(receivedMessage)
  scrollToBottom()
}

const triggerFileInput = () => {
  fileInput.value?.click()
}

const handleFileSelect = (event: Event) => {
  const target = event.target as HTMLInputElement
  if (target.files && target.files.length > 0) {
    selectedFile.value = target.files[0]
  }
}

const removeFile = () => {
  selectedFile.value = null
  if (fileInput.value) {
    fileInput.value.value = ''
  }
  focusInput()
}

const addNewLine = (event: KeyboardEvent) => {
  event.preventDefault()
  // For multi-line support, you could use a textarea instead
  // For now, we'll just prevent the default behavior
}

const focusInput = () => {
  nextTick(() => {
    messageInput.value?.focus()
  })
}

const showMessageActions = (messageId: number) => {
  if (hoverTimeout.value) {
    clearTimeout(hoverTimeout.value)
  }
  activeMessageId.value = messageId
}

const hideMessageActions = () => {
  hoverTimeout.value = setTimeout(() => {
    activeMessageId.value = null
  }, 200)
}

const toggleMessageActions = (messageId: number) => {
  if (activeMessageId.value === messageId) {
    activeMessageId.value = null
  } else {
    activeMessageId.value = messageId
  }
}

const editMessage = (messageId: number) => {
  const message = messages.find(m => m.id === messageId)
  if (message && message.type === 'sent') {
    message.isEditing = true
    editingText.value = message.text
    activeMessageId.value = null
    nextTick(() => {
      editInput.value?.focus()
      editInput.value?.select()
    })
  }
}

const saveEdit = (messageId: number) => {
  const message = messages.find(m => m.id === messageId)
  if (message && message.isEditing) {
    message.text = editingText.value.trim()
    message.isEditing = false
    editingText.value = ''
  }
}

const cancelEdit = () => {
  const editingMessage = messages.find(m => m.isEditing)
  if (editingMessage) {
    editingMessage.isEditing = false
  }
  editingText.value = ''
}

const deleteMessage = (messageId: number) => {
  const index = messages.findIndex(m => m.id === messageId)
  if (index !== -1) {
    messages.splice(index, 1)
    activeMessageId.value = null
  }
}

onMounted(() => {
  scrollToBottom()
  focusInput()
})
</script>

<style scoped>
.chat-interface {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: white;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
  display: flex;
  flex-direction: column;
}

.messages-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
  max-width: 800px;
  margin: 0 auto;
  width: 100%;
}

.message {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 4px;
  position: relative;
  transition: all 0.3s ease;
}

.message:hover {
  transform: translateY(-1px);
}

.message.sent {
  align-items: flex-end;
}

.message.received {
  align-items: flex-start;
}

.message.received .message-wrapper {
  display: flex;
  align-items: flex-end;
  gap: 8px;
  width: 100%;
}

.receiver-avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  overflow: hidden;
  flex-shrink: 0;
}

.receiver-avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.avatar-initials {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: linear-gradient(135deg, #9c27b0, #7b1fa2);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  font-size: 12px;
}

.message-actions {
  position: absolute;
  top: -40px;
  right: 0;
  background: white;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  display: flex;
  gap: 4px;
  padding: 4px;
  opacity: 0;
  visibility: hidden;
  transform: translateY(-10px);
  transition: all 0.3s ease;
  z-index: 10;
}

.message-actions.visible {
  opacity: 1;
  visibility: visible;
  transform: translateY(0);
}

.message.received .message-actions {
  left: 0;
  right: auto;
}

.action-btn {
  background: transparent;
  border: none;
  padding: 8px;
  border-radius: 6px;
  cursor: pointer;
  color: #666;
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.action-btn:hover {
  background: #f5f5f5;
}

.edit-btn:hover {
  color: #2196f3;
  background: #e3f2fd;
}

.delete-btn:hover {
  color: #f44336;
  background: #ffebee;
}

.action-btn svg {
  width: 16px;
  height: 16px;
}

.edit-container {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.edit-input {
  width: 100%;
  padding: 8px 12px;
  border: 2px solid #2196f3;
  border-radius: 8px;
  font-size: 14px;
  font-family: inherit;
  outline: none;
  background: white;
  color: #333;
}

.edit-actions {
  display: flex;
  gap: 8px;
  justify-content: flex-end;
}

.save-btn,
.cancel-btn {
  background: transparent;
  border: none;
  padding: 6px;
  border-radius: 4px;
  cursor: pointer;
  color: #666;
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.save-btn:hover {
  color: #4caf50;
  background: #e8f5e8;
}

.cancel-btn:hover {
  color: #f44336;
  background: #ffebee;
}

.save-btn svg,
.cancel-btn svg {
  width: 14px;
  height: 14px;
}

.message-content {
  background: white;
  padding: 12px 16px;
  border-radius: 18px;
  max-width: 70%;
  word-wrap: break-word;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.message.sent .message-content {
  background: linear-gradient(135deg, #e3f2fd, #bbdefb);
  color: #1565c0;
  border: 1px solid #90caf9;
}

.message.sent.has-attachment .message-content {
  background: linear-gradient(135deg, #f5f5f5, #e8eaf6);
  color: #1976d2;
  border: 1px solid #c5cae9;
}

.message.received .message-content {
  background: rgba(255, 255, 255, 0.95);
  color: #333;
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.message-text {
  margin: 0;
  line-height: 1.4;
  font-size: 14px;
}

.message-time {
  font-size: 11px;
  color: #666;
  margin: 0 8px;
}

.message.sent .message-time {
  text-align: right;
}

.input-area {
  background: #f8f9fa;
  border-top: 1px solid #e9ecef;
  padding: 16px;
}

.attachment-preview {
  margin-bottom: 12px;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 12px;
  padding: 12px;
}

.attachment-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.file-icon {
  width: 24px;
  height: 24px;
  color: #666;
  flex-shrink: 0;
}

.file-details {
  flex: 1;
}

.file-name {
  font-size: 14px;
  font-weight: 600;
  color: #333;
  margin-bottom: 2px;
}

.file-type {
  font-size: 12px;
  color: #666;
}

.remove-file {
  background: transparent;
  border: none;
  padding: 4px;
  border-radius: 50%;
  cursor: pointer;
  color: #666;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.remove-file:hover {
  background: rgba(0, 0, 0, 0.1);
  color: #333;
}

.remove-file svg {
  width: 16px;
  height: 16px;
}

.input-controls {
  display: flex;
  align-items: center;
  gap: 12px;
  background: rgba(255, 255, 255, 0.95);
  border-radius: 24px;
  padding: 8px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
}

.attach-btn {
  background: transparent;
  border: none;
  padding: 8px;
  border-radius: 50%;
  cursor: pointer;
  color: #666;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.attach-btn:hover {
  background: rgba(0, 0, 0, 0.05);
  color: #2196f3;
}

.attach-btn svg {
  width: 20px;
  height: 20px;
}

.text-input-container {
  flex: 1;
}

.message-input {
  width: 100%;
  border: none;
  background: transparent;
  padding: 8px 12px;
  font-size: 14px;
  color: #333;
  outline: none;
}

.message-input::placeholder {
  color: #999;
}

.send-btn {
  background: linear-gradient(135deg, #2196f3, #1976d2);
  border: none;
  padding: 8px;
  border-radius: 50%;
  cursor: pointer;
  color: white;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 36px;
  height: 36px;
}

.send-btn:hover:not(:disabled) {
  background: linear-gradient(135deg, #1976d2, #1565c0);
  transform: scale(1.05);
}

.send-btn:disabled {
  background: #ccc;
  cursor: not-allowed;
  transform: none;
}

.send-btn svg {
  width: 18px;
  height: 18px;
}

/* Scrollbar styling */
.messages-container::-webkit-scrollbar {
  width: 6px;
}

.messages-container::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.1);
}

.messages-container::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.3);
  border-radius: 3px;
}

.messages-container::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.5);
}

/* Responsive Design */
@media (max-width: 768px) {
  .messages-container {
    padding: 16px;
  }
  
  .message-content {
    max-width: 85%;
  }
  
  .input-area {
    padding: 12px;
  }
  
  .input-controls {
    gap: 8px;
    padding: 6px;
  }
}

@media (max-width: 480px) {
  .messages-container {
    padding: 12px;
  }
  
  .message-content {
    max-width: 90%;
    padding: 10px 12px;
  }
  
  .message-text {
    font-size: 13px;
  }
  
  .input-area {
    padding: 8px;
  }
}
</style>
