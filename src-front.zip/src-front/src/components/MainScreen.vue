<template>
  <div class="main-screen">
    <!-- Top App Bar -->
    <div class="app-bar">
      <button @click="toggleSidebar" class="menu-btn">
        <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="3" y1="12" x2="21" y2="12"></line>
          <line x1="3" y1="6" x2="21" y2="6"></line>
          <line x1="3" y1="18" x2="21" y2="18"></line>
        </svg>
      </button>
      
      <h1 class="app-title">My App</h1>
      
      <div class="profile-section">
        <button @click="openSearch" class="search-btn">
          <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"></circle>
            <path d="m21 21-4.35-4.35"></path>
          </svg>
        </button>
        
        <button @click="toggleProfileMenu" class="profile-btn">
          <div v-if="userProfile.photo" class="profile-photo">
            <img :src="userProfile.photo" :alt="userProfile.name" />
          </div>
          <div v-else class="profile-initials">
            {{ getInitials(userProfile.name) }}
          </div>
        </button>
        
        <!-- Profiles List Overlay -->
        <div v-if="showProfileMenu" class="profiles-overlay">
          <div class="profiles-container">
            <div class="profiles-header">
              <h3>Profiles</h3>
              <button @click="toggleProfileMenu" class="close-btn">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <line x1="18" y1="6" x2="6" y2="18"></line>
                  <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
              </button>
            </div>
            <div class="profiles-list">
              <div 
                v-for="profile in loggedProfiles" 
                :key="profile.id" 
                @click="selectProfile(profile)"
                :class="['profile-item', { 'active': profile.id === userProfile.id }]"
              >
                <div class="profile-avatar">
                  <img v-if="profile.photo" :src="profile.photo" :alt="profile.name" />
                  <div v-else class="profile-avatar-initials">
                    {{ getInitials(profile.name) }}
                  </div>
                </div>
                <div class="profile-info">
                  <h4>{{ profile.name }}</h4>
                  <p>{{ profile.email }}</p>
                </div>
                <div v-if="profile.id === userProfile.id" class="active-indicator">
                  <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="20,6 9,17 4,12"></polyline>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="main-content">
      <!-- Sidebar -->
      <div :class="['sidebar', { 'sidebar-open': sidebarOpen, 'sidebar-closed': !sidebarOpen }]">
        <div class="sidebar-content">
          <h3 class="sidebar-title">Menu</h3>
          <nav class="sidebar-nav">
            <button @click="handleDashboard" class="nav-item">
              <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="3" y="3" width="7" height="7"></rect>
                <rect x="14" y="3" width="7" height="7"></rect>
                <rect x="14" y="14" width="7" height="7"></rect>
                <rect x="3" y="14" width="7" height="7"></rect>
              </svg>
              Dashboard
            </button>
            <button @click="handleMessages" class="nav-item">
              <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
              Messages
            </button>
            <button @click="handleProfile" class="nav-item">
              <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
              </svg>
              Profile
            </button>
            <button @click="handleSettings" class="nav-item">
              <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="3"></circle>
                <path d="M12 1v6m0 6v6m4.22-13.22l4.24 4.24M1.54 1.54l4.24 4.24M1 12h6m6 0h6"></path>
              </svg>
              Settings
            </button>
          </nav>
        </div>
      </div>

      <!-- Content Area -->
      <div class="content">
        <div class="list-container">
          <div class="item-list">
            <div v-for="item in listItems" :key="item.id" class="list-item">
              <div class="item-photo">
                <img v-if="item.photo" :src="item.photo" :alt="item.title" />
                <div v-else class="item-initials">
                  {{ getInitials(item.title) }}
                </div>
              </div>
              <div class="item-content">
                <h3 class="item-title">{{ item.title }}</h3>
                <p class="item-description">{{ item.description }}</p>
              </div>
              <div class="item-time">
                {{ formatTime(item.timestamp) }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Overlay for mobile sidebar -->
    <div v-if="sidebarOpen && isSmallScreen" class="sidebar-overlay" @click="toggleSidebar"></div>
    
    <!-- Search Screen Overlay -->
    <div v-if="showSearchScreen" class="search-screen-overlay">
      <div class="search-screen">
        <div class="search-header">
          <button @click="closeSearch" class="back-btn">
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
          </button>
          <div class="search-input-container">
            <input 
              ref="searchInput"
              v-model="searchQuery"
              @input="handleSearch"
              @keydown.escape="closeSearch"
              type="text"
              placeholder="Search..."
              class="search-input"
            />
          </div>
        </div>
        
        <div class="search-content">
          <div v-if="searchQuery && searchResults.length > 0" class="search-results">
            <h3 class="results-title">Search Results</h3>
            <div v-for="result in searchResults" :key="result.id" class="search-result-item">
              <div class="result-photo">
                <img v-if="result.photo" :src="result.photo" :alt="result.title" />
                <div v-else class="result-initials">
                  {{ getInitials(result.title) }}
                </div>
              </div>
              <div class="result-content">
                <h4 class="result-title">{{ highlightMatch(result.title) }}</h4>
                <p class="result-description">{{ highlightMatch(result.description) }}</p>
              </div>
            </div>
          </div>
          
          <div v-else-if="searchQuery && searchResults.length === 0" class="no-results">
            <svg class="no-results-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="11" cy="11" r="8"></circle>
              <path d="m21 21-4.35-4.35"></path>
            </svg>
            <p>No results found for "{{ searchQuery }}"</p>
          </div>
          
          <div v-else class="search-placeholder">
            <svg class="search-placeholder-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="11" cy="11" r="8"></circle>
              <path d="m21 21-4.35-4.35"></path>
            </svg>
            <p>Start typing to search...</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, onUnmounted, nextTick } from 'vue'

interface ListItem {
  id: number
  title: string
  description: string
  photo?: string
  timestamp: Date
}

interface UserProfile {
  id: number
  name: string
  email: string
  photo?: string
}

const sidebarOpen = ref(false)
const showProfileMenu = ref(false)
const isSmallScreen = ref(false)
const showSearchScreen = ref(false)
const searchQuery = ref('')
const searchResults = ref<ListItem[]>([])
const searchInput = ref<HTMLInputElement | null>(null)

const userProfile = reactive<UserProfile>({
  id: 1,
  name: 'John Doe',
  email: 'john.doe@example.com',
  photo: undefined // Set to undefined to show initials
})

const loggedProfiles = reactive<UserProfile[]>([
  {
    id: 1,
    name: 'John Doe',
    email: 'john.doe@example.com',
    photo: undefined
  },
  {
    id: 2,
    name: 'Alice Johnson',
    email: 'alice.j@example.com',
    photo: 'https://picsum.photos/seed/alice/100/100.jpg'
  },
  {
    id: 3,
    name: 'Bob Smith',
    email: 'bob.smith@example.com',
    photo: undefined
  }
])

const listItems = reactive<ListItem[]>([
  {
    id: 1,
    title: 'Alice Johnson',
    description: 'Shared a new document with you',
    timestamp: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
    photo: 'https://picsum.photos/seed/alice/100/100.jpg'
  },
  {
    id: 2,
    title: 'Bob Smith',
    description: 'Commented on your post',
    timestamp: new Date(Date.now() - 1000 * 60 * 15), // 15 minutes ago
    photo: undefined
  },
  {
    id: 3,
    title: 'Carol White',
    description: 'Sent you a message',
    timestamp: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
    photo: 'https://picsum.photos/seed/carol/100/100.jpg'
  },
  {
    id: 4,
    title: 'David Brown',
    description: 'Updated the project status',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
    photo: undefined
  },
  {
    id: 5,
    title: 'Emma Davis',
    description: 'Added you to a team',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
    photo: 'https://picsum.photos/seed/emma/100/100.jpg'
  }
])

const checkScreenSize = () => {
  isSmallScreen.value = window.innerWidth < 768
  if (!isSmallScreen.value) {
    sidebarOpen.value = true // Always open on large screens
  } else {
    sidebarOpen.value = false // Closed by default on small screens
  }
}

const getInitials = (name: string): string => {
  return name
    .split(' ')
    .map(word => word.charAt(0).toUpperCase())
    .slice(0, 2)
    .join('')
}

const formatTime = (timestamp: Date): string => {
  const now = new Date()
  const diff = now.getTime() - timestamp.getTime()
  const minutes = Math.floor(diff / (1000 * 60))
  const hours = Math.floor(diff / (1000 * 60 * 60))
  const days = Math.floor(diff / (1000 * 60 * 60 * 24))

  if (minutes < 1) return 'Just now'
  if (minutes < 60) return `${minutes}m ago`
  if (hours < 24) return `${hours}h ago`
  if (days < 7) return `${days}d ago`
  return timestamp.toLocaleDateString()
}

const toggleSidebar = () => {
  sidebarOpen.value = !sidebarOpen.value
}

const toggleProfileMenu = () => {
  showProfileMenu.value = !showProfileMenu.value
}

const handleDashboard = () => {
  console.log('Dashboard clicked')
  if (isSmallScreen.value) sidebarOpen.value = false
}

const handleMessages = () => {
  console.log('Messages clicked')
  if (isSmallScreen.value) sidebarOpen.value = false
}

const selectProfile = (profile: UserProfile) => {
  // Update current user profile
  userProfile.id = profile.id
  userProfile.name = profile.name
  userProfile.email = profile.email
  userProfile.photo = profile.photo
  
  // Close the profiles overlay
  showProfileMenu.value = false
  
  console.log(`Switched to profile: ${profile.name}`)
}

const openSearch = () => {
  showSearchScreen.value = true
  // Focus on input after the DOM updates
  nextTick(() => {
    if (searchInput.value) {
      searchInput.value.focus()
    }
  })
}

const closeSearch = () => {
  showSearchScreen.value = false
  searchQuery.value = ''
  searchResults.value = []
}

const handleSearch = () => {
  if (!searchQuery.value.trim()) {
    searchResults.value = []
    return
  }
  
  const query = searchQuery.value.toLowerCase()
  searchResults.value = listItems.filter(item => 
    item.title.toLowerCase().includes(query) || 
    item.description.toLowerCase().includes(query)
  )
}

const highlightMatch = (text: string): string => {
  if (!searchQuery.value) return text
  
  const regex = new RegExp(`(${searchQuery.value})`, 'gi')
  return text.replace(regex, '<mark>$1</mark>')
}

// Close profile menu when clicking outside
const handleClickOutside = (event: MouseEvent) => {
  const target = event.target as HTMLElement
  if (!target.closest('.profile-section')) {
    showProfileMenu.value = false
  }
}

onMounted(() => {
  checkScreenSize()
  window.addEventListener('resize', checkScreenSize)
  document.addEventListener('click', handleClickOutside)
  
  // Set initial sidebar state based on screen size
  sidebarOpen.value = !isSmallScreen.value
})

onUnmounted(() => {
  window.removeEventListener('resize', checkScreenSize)
  document.removeEventListener('click', handleClickOutside)
})
</script>

<style scoped>
.main-screen {
  height: 100vh;
  display: flex;
  flex-direction: column;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  background-color: #f8fafc;
}

/* App Bar */
.app-bar {
  background: linear-gradient(135deg, #ffffff 0%, #e3f2fd 100%);
  border-bottom: 1px solid #bbdefb;
  padding: 0 20px;
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  box-shadow: 0 2px 8px rgba(33, 150, 243, 0.1);
  position: relative;
  z-index: 100;
}

.menu-btn {
  background: transparent;
  border: none;
  padding: 8px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  z-index: 10;
}

.menu-btn:hover {
  background: rgba(33, 150, 243, 0.1);
}

.menu-btn .icon {
  width: 24px;
  height: 24px;
  color: #1976d2;
}

.search-btn {
  background: transparent;
  border: none;
  padding: 8px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  z-index: 10;
}

.search-btn:hover {
  background: rgba(33, 150, 243, 0.1);
}

.search-btn .icon {
  width: 24px;
  height: 24px;
  color: #1976d2;
}

.app-title {
  font-size: 20px;
  font-weight: 600;
  color: #1565c0;
  margin: 0;
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
}

/* Profile Section */
.profile-section {
  position: relative;
  display: flex;
  align-items: center;
  gap: 8px;
}

/* Profiles Overlay */
.profiles-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 150;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.profiles-container {
  background: white;
  border-radius: 16px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  width: 100%;
  max-width: 400px;
  max-height: 80vh;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.profiles-header {
  background: linear-gradient(135deg, #ffffff 0%, #e3f2fd 100%);
  border-bottom: 1px solid #bbdefb;
  padding: 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.profiles-header h3 {
  font-size: 20px;
  font-weight: 600;
  color: #1565c0;
  margin: 0;
}

.close-btn {
  background: transparent;
  border: none;
  padding: 8px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.close-btn:hover {
  background: rgba(33, 150, 243, 0.1);
}

.close-btn .icon {
  width: 20px;
  height: 20px;
  color: #1976d2;
}

.profiles-list {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
}

.profile-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
  border: 1px solid transparent;
  margin-bottom: 8px;
}

.profile-item:hover {
  background: #f5f5f5;
  transform: translateY(-1px);
}

.profile-item.active {
  background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
  border-color: #90caf9;
}

.profile-avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  overflow: hidden;
  flex-shrink: 0;
}

.profile-avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.profile-avatar-initials {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: linear-gradient(135deg, #64b5f6, #42a5f5);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  font-size: 16px;
}

.profile-info {
  flex: 1;
}

.profile-info h4 {
  font-size: 16px;
  font-weight: 600;
  color: #1565c0;
  margin: 0 0 4px 0;
}

.profile-info p {
  font-size: 14px;
  color: #616161;
  margin: 0;
}

.active-indicator {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  background: #4caf50;
  border-radius: 50%;
  flex-shrink: 0;
}

.active-indicator .icon {
  width: 16px;
  height: 16px;
  color: white;
  stroke-width: 3;
}

.profile-btn {
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 4px;
  border-radius: 50%;
  transition: all 0.3s ease;
}

.profile-btn:hover {
  background: rgba(33, 150, 243, 0.1);
}

.profile-photo {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  overflow: hidden;
}

.profile-photo img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.profile-initials {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: linear-gradient(135deg, #2196f3, #1976d2);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  font-size: 14px;
}

.profile-menu {
  position: absolute;
  top: 100%;
  right: 0;
  margin-top: 8px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  min-width: 150px;
  overflow: hidden;
  z-index: 1000;
}

.menu-item {
  width: 100%;
  background: transparent;
  border: none;
  padding: 12px 16px;
  text-align: left;
  cursor: pointer;
  transition: background 0.3s ease;
  font-size: 14px;
  color: #333;
}

.menu-item:hover {
  background: #e3f2fd;
  color: #1976d2;
}

/* Main Content */
.main-content {
  flex: 1;
  display: flex;
  overflow: hidden;
}

/* Sidebar */
.sidebar {
  background: white;
  border-right: 1px solid #e3f2fd;
  width: 250px;
  transition: transform 0.3s ease;
  overflow-y: auto;
  position: relative;
  z-index: 50;
}

.sidebar-closed {
  transform: translateX(-100%);
}

.sidebar-content {
  padding: 20px;
}

.sidebar-title {
  font-size: 18px;
  font-weight: 600;
  color: #1565c0;
  margin: 0 0 20px 0;
}

.sidebar-nav {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.nav-item {
  background: transparent;
  border: none;
  padding: 12px 16px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 14px;
  color: #424242;
  text-align: left;
  width: 100%;
}

.nav-item:hover {
  background: #e3f2fd;
  color: #1976d2;
  transform: translateX(4px);
}

.nav-icon {
  width: 20px;
  height: 20px;
  flex-shrink: 0;
}

/* Content Area */
.content {
  flex: 1;
  overflow-y: auto;
  padding: 24px;
}

.list-container {
  max-width: 800px;
  margin: 0 auto;
}

.list-title {
  font-size: 24px;
  font-weight: 600;
  color: #1565c0;
  margin: 0 0 24px 0;
}

.item-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.list-item {
  background: white;
  border-radius: 12px;
  padding: 16px;
  display: flex;
  align-items: center;
  gap: 16px;
  box-shadow: 0 2px 8px rgba(33, 150, 243, 0.08);
  transition: all 0.3s ease;
  border: 1px solid #e3f2fd;
}

.list-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 16px rgba(33, 150, 243, 0.15);
}

.item-photo {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  overflow: hidden;
  flex-shrink: 0;
}

.item-photo img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.item-initials {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: linear-gradient(135deg, #64b5f6, #42a5f5);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  font-size: 16px;
}

.item-content {
  flex: 1;
}

.item-title {
  font-size: 16px;
  font-weight: 600;
  color: #1565c0;
  margin: 0 0 4px 0;
}

.item-description {
  font-size: 14px;
  color: #616161;
  margin: 0;
  line-height: 1.4;
}

.item-time {
  font-size: 12px;
  color: #9e9e9e;
  flex-shrink: 0;
}

/* Sidebar Overlay for mobile */
.sidebar-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 40;
}

/* Search Screen Overlay */
.search-screen-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(255, 255, 255, 0.98);
  z-index: 200;
  display: flex;
  flex-direction: column;
}

.search-screen {
  height: 100%;
  display: flex;
  flex-direction: column;
}

.search-header {
  background: linear-gradient(135deg, #ffffff 0%, #e3f2fd 100%);
  border-bottom: 1px solid #bbdefb;
  padding: 16px 20px;
  display: flex;
  align-items: center;
  gap: 12px;
  box-shadow: 0 2px 8px rgba(33, 150, 243, 0.1);
}

.back-btn {
  background: transparent;
  border: none;
  padding: 8px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.back-btn:hover {
  background: rgba(33, 150, 243, 0.1);
}

.back-btn .icon {
  width: 24px;
  height: 24px;
  color: #1976d2;
}

.search-input-container {
  flex: 1;
  position: relative;
}

.search-input {
  width: 100%;
  padding: 12px 16px;
  border: 2px solid #e3f2fd;
  border-radius: 24px;
  font-size: 16px;
  background: white;
  color: #1565c0;
  outline: none;
  transition: all 0.3s ease;
}

.search-input:focus {
  border-color: #1976d2;
  box-shadow: 0 0 0 3px rgba(33, 150, 243, 0.1);
}

.search-input::placeholder {
  color: #90caf9;
}

.search-content {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
}

.search-results {
  max-width: 800px;
  margin: 0 auto;
}

.results-title {
  font-size: 18px;
  font-weight: 600;
  color: #1565c0;
  margin: 0 0 16px 0;
}

.search-result-item {
  background: white;
  border-radius: 12px;
  padding: 16px;
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 12px;
  box-shadow: 0 2px 8px rgba(33, 150, 243, 0.08);
  border: 1px solid #e3f2fd;
  transition: all 0.3s ease;
}

.search-result-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 16px rgba(33, 150, 243, 0.15);
}

.result-photo {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  overflow: hidden;
  flex-shrink: 0;
}

.result-photo img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.result-initials {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: linear-gradient(135deg, #64b5f6, #42a5f5);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  font-size: 16px;
}

.result-content {
  flex: 1;
}

.result-title {
  font-size: 16px;
  font-weight: 600;
  color: #1565c0;
  margin: 0 0 4px 0;
}

.result-description {
  font-size: 14px;
  color: #616161;
  margin: 0;
  line-height: 1.4;
}

.no-results,
.search-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 20px;
  text-align: center;
  color: #90caf9;
}

.no-results-icon,
.search-placeholder-icon {
  width: 64px;
  height: 64px;
  margin-bottom: 16px;
  opacity: 0.6;
}

.no-results p,
.search-placeholder p {
  font-size: 16px;
  margin: 0;
}

/* Highlight search matches */
:deep(mark) {
  background: #fff59d;
  color: #1565c0;
  padding: 1px 2px;
  border-radius: 2px;
}

/* Responsive Design */
@media (max-width: 768px) {
  .app-bar {
    padding: 0 16px;
  }
  
  .app-title {
    font-size: 18px;
  }
  
  .sidebar {
    position: fixed;
    top: 64px;
    left: 0;
    bottom: 0;
    z-index: 50;
  }
  
  .content {
    padding: 16px;
  }
  
  .search-header {
    padding: 10px 12px;
  }
  
  .search-input {
    padding: 8px 12px;
    font-size: 16px; /* Prevents zoom on iOS */
  }
  
  .search-content {
    padding: 12px;
  }
  
  .search-result-item {
    padding: 10px;
    gap: 12px;
  }
  
  .result-photo,
  .result-initials {
    width: 40px;
    height: 40px;
  }
  
  .result-title {
    font-size: 14px;
  }
  
  .result-description {
    font-size: 13px;
  }
  
  .profiles-overlay {
    padding: 16px;
  }
  
  .profiles-container {
    max-width: 100%;
    max-height: 90vh;
  }
  
  .profiles-header {
    padding: 16px;
  }
  
  .profiles-list {
    padding: 12px;
  }
  
  .profile-item {
    padding: 12px;
    gap: 10px;
  }
  
  .profile-avatar,
  .profile-avatar-initials {
    width: 40px;
    height: 40px;
  }
  
  .profile-avatar-initials {
    font-size: 14px;
  }
  
  .profile-info h4 {
    font-size: 14px;
  }
  
  .profile-info p {
    font-size: 13px;
  }
  
  .list-title {
    font-size: 20px;
  }
  
  .list-item {
    padding: 12px;
  }
  
  .item-photo,
  .item-initials {
    width: 40px;
    height: 40px;
  }
  
  .item-title {
    font-size: 14px;
  }
  
  .item-description {
    font-size: 13px;
  }
  
  .item-time {
    font-size: 11px;
  }
}

@media (max-width: 480px) {
  .app-bar {
    padding: 0 12px;
    height: 56px;
  }
  
  .app-title {
    font-size: 16px;
  }
  
  .sidebar {
    top: 56px;
  }
  
  .content {
    padding: 12px;
  }
  
  .list-title {
    font-size: 18px;
    margin-bottom: 16px;
  }
  
  .list-item {
    padding: 10px;
    gap: 12px;
  }
  
  .item-photo,
  .item-initials {
    width: 36px;
    height: 36px;
  }
  
  .item-title {
    font-size: 13px;
  }
  
  .item-description {
    font-size: 12px;
  }
  
  .item-time {
    font-size: 10px;
  }
}
</style>
