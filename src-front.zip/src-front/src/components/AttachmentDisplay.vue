<template>
  <div class="attachment-display">
    <div class="attachment-card">
      <div class="attachment-icon">
        <component :is="getFileIcon" />
      </div>
      <div class="attachment-info">
        <div class="attachment-name">{{ attachment.name }}</div>
        <div class="attachment-type">{{ attachment.type }}</div>
        <div v-if="attachment.caption" class="attachment-caption">{{ attachment.caption }}</div>
      </div>
      <button @click="downloadAttachment" class="download-btn">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
          <polyline points="7,10 12,15 17,10"></polyline>
          <line x1="12" y1="15" x2="12" y2="3"></line>
        </svg>
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

interface Attachment {
  name: string
  type: string
  path: string
  caption?: string
}

interface Props {
  attachment: Attachment
}

const props = defineProps<Props>()

const getFileIcon = computed(() => {
  const fileType = props.attachment.type.toLowerCase()
  
  // Image icon
  if (fileType.startsWith('image/')) {
    return {
      template: `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
          <circle cx="8.5" cy="8.5" r="1.5"></circle>
          <polyline points="21 15 16 10 5 21"></polyline>
        </svg>
      `,
      style: 'color: #4caf50;'
    }
  }
  
  // PDF icon
  if (fileType === 'application/pdf') {
    return {
      template: `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
          <polyline points="14,2 14,8 20,8"></polyline>
          <line x1="16" y1="13" x2="8" y2="13"></line>
          <line x1="16" y1="17" x2="8" y2="17"></line>
          <polyline points="10,9 9,9 8,9"></polyline>
        </svg>
      `,
      style: 'color: #f44336;'
    }
  }
  
  // Video icon
  if (fileType.startsWith('video/')) {
    return {
      template: `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polygon points="23 7 16 12 23 17 23 7"></polygon>
          <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
        </svg>
      `,
      style: 'color: #ff9800;'
    }
  }
  
  // Audio icon
  if (fileType.startsWith('audio/')) {
    return {
      template: `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M9 18V5l12-2v13"></path>
          <circle cx="6" cy="18" r="3"></circle>
          <circle cx="18" cy="16" r="3"></circle>
        </svg>
      `,
      style: 'color: #9c27b0;'
    }
  }
  
  // Archive icon (zip, rar, etc.)
  if (fileType.includes('zip') || fileType.includes('rar') || fileType.includes('7z') || fileType.includes('tar')) {
    return {
      template: `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
          <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
          <line x1="12" y1="22.08" x2="12" y2="12"></line>
        </svg>
      `,
      style: 'color: #795548;'
    }
  }
  
  // Document icon (word, text, etc.)
  if (fileType.includes('document') || fileType.includes('text') || fileType.includes('word')) {
    return {
      template: `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
          <polyline points="14,2 14,8 20,8"></polyline>
          <line x1="16" y1="13" x2="8" y2="13"></line>
          <line x1="16" y1="17" x2="8" y2="17"></line>
          <polyline points="10,9 9,9 8,9"></polyline>
        </svg>
      `,
      style: 'color: #2196f3;'
    }
  }
  
  // Spreadsheet icon
  if (fileType.includes('sheet') || fileType.includes('excel')) {
    return {
      template: `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
          <polyline points="14,2 14,8 20,8"></polyline>
          <line x1="16" y1="13" x2="8" y2="13"></line>
          <line x1="16" y1="17" x2="8" y2="17"></line>
          <polyline points="10,9 9,9 8,9"></polyline>
        </svg>
      `,
      style: 'color: #4caf50;'
    }
  }
  
  // Default file icon
  return {
    template: `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
        <polyline points="14,2 14,8 20,8"></polyline>
      </svg>
    `,
    style: 'color: #666;'
  }
})

const downloadAttachment = () => {
  const link = document.createElement('a')
  link.href = props.attachment.path
  link.download = props.attachment.name
  link.target = '_blank'
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}
</script>

<style scoped>
.attachment-display {
  margin-top: 8px;
  width: 100%;
}

.attachment-card {
  display: flex;
  align-items: center;
  gap: 12px;
  background: rgba(0, 0, 0, 0.05);
  border: 1px solid rgba(0, 0, 0, 0.1);
  border-radius: 12px;
  padding: 12px;
  transition: all 0.3s ease;
  cursor: pointer;
}

.attachment-card:hover {
  background: rgba(0, 0, 0, 0.08);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.attachment-icon {
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(255, 255, 255, 0.8);
  border-radius: 8px;
  flex-shrink: 0;
}

.attachment-icon svg {
  width: 24px;
  height: 24px;
}

.attachment-info {
  flex: 1;
  min-width: 0;
}

.attachment-name {
  font-size: 14px;
  font-weight: 600;
  color: #333;
  margin-bottom: 2px;
  word-break: break-word;
  line-height: 1.3;
}

.attachment-type {
  font-size: 12px;
  color: #666;
  margin-bottom: 4px;
}

.attachment-caption {
  font-size: 12px;
  color: #888;
  font-style: italic;
  line-height: 1.3;
}

.download-btn {
  background: transparent;
  border: none;
  padding: 8px;
  border-radius: 8px;
  cursor: pointer;
  color: #666;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.download-btn:hover {
  background: rgba(0, 0, 0, 0.1);
  color: #2196f3;
}

.download-btn svg {
  width: 18px;
  height: 18px;
}

/* Dark theme support for sent messages */
:deep(.message.sent) .attachment-card {
  background: rgba(255, 255, 255, 0.15);
  border-color: rgba(255, 255, 255, 0.2);
}

:deep(.message.sent) .attachment-card:hover {
  background: rgba(255, 255, 255, 0.2);
}

:deep(.message.sent) .attachment-icon {
  background: rgba(255, 255, 255, 0.9);
}

:deep(.message.sent) .attachment-name {
  color: white;
}

:deep(.message.sent) .attachment-type {
  color: rgba(255, 255, 255, 0.8);
}

:deep(.message.sent) .attachment-caption {
  color: rgba(255, 255, 255, 0.7);
}

:deep(.message.sent) .download-btn {
  color: rgba(255, 255, 255, 0.8);
}

:deep(.message.sent) .download-btn:hover {
  background: rgba(255, 255, 255, 0.2);
  color: white;
}

/* Responsive Design */
@media (max-width: 480px) {
  .attachment-card {
    padding: 10px;
    gap: 10px;
  }
  
  .attachment-icon {
    width: 36px;
    height: 36px;
  }
  
  .attachment-icon svg {
    width: 20px;
    height: 20px;
  }
  
  .attachment-name {
    font-size: 13px;
  }
  
  .attachment-type,
  .attachment-caption {
    font-size: 11px;
  }
}
</style>
