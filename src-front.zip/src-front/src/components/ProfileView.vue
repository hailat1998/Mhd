<template>
  <div class="profile-page">
    <div class="profile-container">
      <div class="profile-header">
        <div class="header-top">
          <button @click="handleBack" class="back-btn">
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
          </button>
          
          <div class="profile-info">
            <h1 class="profile-name">{{ profile.name }}</h1>
            <div class="username-container">
              <span class="profile-username">@{{ profile.username }}</span>
              <button @click="copyUsername" class="copy-btn" :title="copyTooltip">
                {{ copied ? 'Copied!' : 'Copy' }}
              </button>
            </div>
          </div>
          
          <div class="header-right">
            <button @click="handleMessage" class="message-btn">
              <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
              </svg>
            </button>
          </div>
        </div>
      </div>
      
      <div class="profile-image-container">
        <img 
          :src="profile.imageUrl" 
          :alt="profile.name"
          class="profile-image"
          @load="onImageLoad"
          @error="onImageError"
          v-show="!imageLoading"
        >
        <div v-if="imageLoading" class="image-loading">
          <div class="loading-spinner"></div>
        </div>
        <div v-if="profileLoading" class="shimmer-wrapper">
          <div class="shimmer">
            <div class="shimmer-header">
              <div class="shimmer-name"></div>
              <div class="shimmer-username"></div>
            </div>
            <div class="shimmer-image"></div>
          </div>
        </div>
      </div>
      
      <div v-if="!profileLoading && !imageLoading" class="profile-actions">
        <button @click="handleUpdate" class="action-btn update-btn">
          <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
            <circle cx="12" cy="13" r="4"/>
          </svg>
          <span>Update</span>
        </button>
        
        <button @click="handleDelete" class="action-btn delete-btn">
          <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="3,6 5,6 21,6"/>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
          </svg>
          <span>Delete</span>
        </button>
        
        <button @click="handleSetFirst" class="action-btn set-first-btn">
          <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26"/>
          </svg>
          <span>Set First</span>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'

const profile = reactive({
  name: 'John Doe',
  username: 'johndoe123',
  imageUrl: ''
})

const imageLoading = ref(true)
const profileLoading = ref(true)
const copied = ref(false)
const copyTooltip = ref('Copy username to clipboard')

const fetchProfileImage = async () => {
  imageLoading.value = true
  try {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    // Using Lorem Picsum for random profile images
    const seed = profile.username.replace(/[^a-zA-Z0-9]/g, '')
    const response = await fetch(`https://picsum.photos/seed/${seed}/400/400.jpg`)
    if (response.ok) {
      profile.imageUrl = `https://picsum.photos/seed/${seed}/400/400.jpg`
    } else {
      // Fallback to a different API
      profile.imageUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${seed}`
    }
  } catch (error) {
    console.error('Failed to fetch profile image:', error)
    // Fallback to placeholder
    profile.imageUrl = `https://ui-avatars.com/api/?name=${encodeURIComponent(profile.name)}&size=400&background=3498db&color=fff`
  } finally {
    imageLoading.value = false
  }
}

const fetchProfileData = async () => {
  profileLoading.value = true
  try {
    // Simulate API call for profile data
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // Mock API response - in real app, this would fetch from backend
    const mockProfileData = {
      name: 'John Doe',
      username: 'johndoe123'
    }
    
    profile.name = mockProfileData.name
    profile.username = mockProfileData.username
    
  } catch (error) {
    console.error('Failed to fetch profile data:', error)
  } finally {
    profileLoading.value = false
    await fetchProfileImage()
  }
}

const copyUsername = async () => {
  try {
    await navigator.clipboard.writeText(`@${profile.username}`)
    copied.value = true
    copyTooltip.value = 'Username copied!'
    
    setTimeout(() => {
      copied.value = false
      copyTooltip.value = 'Copy username to clipboard'
    }, 2000)
  } catch (error) {
    console.error('Failed to copy username:', error)
    // Fallback for older browsers
    const textArea = document.createElement('textarea')
    textArea.value = `@${profile.username}`
    document.body.appendChild(textArea)
    textArea.select()
    document.execCommand('copy')
    document.body.removeChild(textArea)
    
    copied.value = true
    setTimeout(() => {
      copied.value = false
    }, 2000)
  }
}

const onImageLoad = () => {
  imageLoading.value = false
}

const onImageError = () => {
  imageLoading.value = false
  // Try fallback image
  profile.imageUrl = `https://ui-avatars.com/api/?name=${encodeURIComponent(profile.name)}&size=400&background=3498db&color=fff`
}

const handleUpdate = () => {
  alert('Update profile functionality would be implemented here')
}

const handleDelete = () => {
  if (confirm('Are you sure you want to delete this profile?')) {
    alert('Profile deleted (mock action)')
  }
}

const handleSetFirst = () => {
  alert('Set as first profile functionality would be implemented here')
}

const handleBack = () => {
  alert('Navigate back functionality would be implemented here')
}

const handleMessage = () => {
  alert('Message functionality would be implemented here')
}

onMounted(() => {
  fetchProfileData()
})
</script>

<style scoped>
.profile-page {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  background: linear-gradient(135deg, #74b9ff 0%, #0984e3 100%);
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
}

.profile-container {
  background: white;
  border-radius: 20px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  padding: 40px;
  width: 100%;
  max-width: 500px;
  text-align: center;
}

.profile-header {
  margin-bottom: 30px;
}

.header-top {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 15px;
}

.back-btn {
  background: transparent;
  border: none;
  padding: 8px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  margin-top: 8px;
}

.back-btn:hover {
  background: rgba(52, 152, 219, 0.1);
  transform: translateX(-2px);
}

.back-btn .icon {
  width: 24px;
  height: 24px;
  color: #2c3e50;
  stroke-width: 2.5;
}

.profile-info {
  flex: 1;
  text-align: left;
  display: flex;
  flex-direction: column;
  align-items: flex-start;   /* important */
  justify-content: center;
}

.header-right {
  display: flex;
  align-items: center;
  flex-shrink: 0;
  margin-top: 8px;
}

.message-btn {
  background: transparent;
  border: none;
  padding: 8px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.message-btn:hover {
  background: rgba(52, 152, 219, 0.1);
  transform: scale(1.05);
}

.message-btn .icon {
  width: 28px;
  height: 28px;
  color: #2c3e50;
  stroke-width: 2.5;
}

.profile-name {
  font-size: 32px;
  font-weight: 700;
  color: #2c3e50;
  margin: 0 0 8px 0;
  text-align: left;
  width: 100%;
}

.username-container {
  display: flex;
  align-items: center;
  justify-content: flex-start;   /* changed */
  gap: 8px;
  flex-wrap: wrap;
  width: 100%;
}

.profile-username {
  font-size: 18px;
  color: #7f8c8d;
  font-weight: 500;
  text-align: left;
}

.copy-btn {
  background: #3498db;
  color: white;
  border: none;
  border-radius: 6px;
  padding: 4px 12px;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  min-width: 60px;
}

.copy-btn:hover {
  background: #2980b9;
  transform: translateY(-1px);
}

.copy-btn:active {
  transform: translateY(0);
}

.copy-btn:disabled {
  opacity: 0.7;
  cursor: not-allowed;
}

.profile-image-container {
  position: relative;
  width: 100%;
  margin-top: 20px;
}

.profile-image {
  display: block;
  margin: 0 auto;
  width: 100%;
  max-width: 300px;
  height: 300px;
  object-fit: cover;
  border-radius: 20px;
}

.profile-image:hover {
  transform: scale(1.02);
}

.image-loading {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.loading-spinner {
  width: 40px;
  height: 40px;
  border: 4px solid #f3f3f3;
  border-top: 4px solid #3498db;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

.shimmer-wrapper {
  position: absolute;
  inset: 0;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  pointer-events: none;
}

.shimmer {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.shimmer-header {
  width: 300px;              /* same as image */
  margin-bottom: 18px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.shimmer-name {
  width: 140px;
  height: 32px;
  border-radius: 8px;
}

.shimmer-username {
  width: 110px;
  height: 18px;
  border-radius: 6px;
}

.shimmer-image {
  width: 300px;
  height: 300px;
  border-radius: 20px;
}


@keyframes shimmer {
  0% {
    background-position: -200% 0;
  }
  100% {
    background-position: 200% 0;
  }
}

.profile-actions {
  display: flex;
  justify-content: center;
  gap: 15px;
  margin-top: 30px;
  flex-wrap: wrap;
}

.action-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 20px;
  border: none;
  border-radius: 10px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  min-width: 100px;
  justify-content: center;
}

.action-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.action-btn:active {
  transform: translateY(0);
}

.action-btn .icon {
  width: 16px;
  height: 16px;
}

.update-btn {
  background: #3498db;
  color: white;
}

.update-btn:hover {
  background: #2980b9;
}

.delete-btn {
  background: #e74c3c;
  color: white;
}

.delete-btn:hover {
  background: #c0392b;
}

.set-first-btn {
  background: #f39c12;
  color: white;
}

.set-first-btn:hover {
  background: #e67e22;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* Mobile responsive */
@media (max-width: 768px) {
  .profile-page {
    padding: 15px;
  }

  .profile-container {
    padding: 30px 20px;
    max-width: 100%;
  }

  .profile-name {
    font-size: 28px;
  }

  .profile-username {
    font-size: 16px;
  }

  .profile-image {
    max-width: 250px;
    height: 250px;
  }
  
  .shimmer {
    align-items: flex-start;
  }
  
   .shimmer-header,
  .shimmer-image {
    width: 250px;
  }

  
  .profile-actions {
    gap: 10px;
  }
  
  .action-btn {
    padding: 10px 16px;
    font-size: 13px;
    min-width: 90px;
  }
  
  .header-top {
    gap: 10px;
  }
  
  .back-btn {
    margin-top: 4px;
  }

  .message-btn {
  background: transparent;
  border: none;
  padding: 10px;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}
  .back-btn .icon,
.message-btn .icon {
    width: 30px;
    height: 30px;
  }
  
  .header-right {
    margin-top: 6px;
  }
  
 .shimmer-image {
    height: 250px;
  }
}

@media (max-width: 480px) {
  .profile-page {
    padding: 10px;
  }

  .profile-container {
    padding: 25px 15px;
  }

  .profile-name {
    font-size: 24px;
  }

  .profile-username {
    font-size: 15px;
  }

  .copy-btn {
    font-size: 11px;
    padding: 3px 10px;
    min-width: 55px;
  }

  .profile-image {
    max-width: 200px;
    height: 200px;
  }
  
  .shimmer {
    align-items: flex-start;
  }
  
   .shimmer-header,
  .shimmer-image {
    width: 200px;
  }

   .shimmer-image {
    height: 200px;
  }
  
  .profile-actions {
    gap: 8px;
    margin-top: 20px;
  }
  
  .action-btn {
    padding: 8px 12px;
    font-size: 12px;
    min-width: 80px;
  }
  
  .header-top {
    gap: 8px;
  }
  
  .back-btn {
    margin-top: 2px;
  }
  
  .back-btn .icon,
 .message-btn .icon {
    width: 28px;
    height: 28px;
  }

  
  .header-right {
    margin-top: 4px;
  }
  
  .message-btn .icon {
    width: 22px;
    height: 22px;
  }
}

/* Large screens - make the image more prominent */
@media (min-width: 1024px) {
  .profile-container {
    max-width: 600px;
    padding: 50px;
  }

  .profile-name {
    font-size: 36px;
  }

  .profile-username {
    font-size: 20px;
  }

  .profile-image {
    max-width: 400px;
    height: 400px;
  }
  
  .shimmer {
    align-items: flex-start;
  }
  
  .shimmer-header,
  .shimmer-image {
    width: 400px;
  }

    .shimmer-image {
    height: 400px;
  }
   .message-btn .icon {
    width: 42px;
    height: 42px;
  }
}

@media (min-width: 1440px) {
  .profile-container {
    max-width: 700px;
  }

  .profile-image {
    max-width: 500px;
    height: 500px;
  }
  
  .shimmer {
    align-items: flex-start;
  }
  
    .shimmer-header,
  .shimmer-image {
    width: 500px;
  }
    .shimmer-image {
    height: 500px;
  }
}
</style>
