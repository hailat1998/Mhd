<template>
  <div class="settings-screen">
    <!-- Header -->
    <div class="settings-header">
      <button @click="$emit('close')" class="back-btn">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M19 12H5M12 19l-7-7 7-7"/>
        </svg>
      </button>
      <h1 class="settings-title">Settings</h1>
    </div>

    <!-- Settings Content -->
    <div class="settings-content">
      <!-- Account Section -->
      <div class="settings-section">
        <div class="section-header" @click="toggleAccountDropdown">
          <div class="section-info">
            <svg class="section-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
              <circle cx="12" cy="7" r="4"></circle>
            </svg>
            <span class="section-title">Account</span>
          </div>
          <svg class="dropdown-arrow" :class="{ 'rotated': accountDropdownOpen }" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="6,9 12,15 18,9"></polyline>
          </svg>
        </div>
        
        <div v-show="accountDropdownOpen" class="dropdown-content">
          <button @click="openEditModal" class="dropdown-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
            </svg>
            Edit
          </button>
          <button @click="showSessions" class="dropdown-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
              <line x1="16" y1="2" x2="16" y2="6"></line>
              <line x1="8" y1="2" x2="8" y2="6"></line>
              <line x1="3" y1="10" x2="21" y2="10"></line>
            </svg>
            Session
          </button>
          <button @click="handleLogout" class="dropdown-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
              <polyline points="16,17 21,12 16,7"></polyline>
              <line x1="21" y1="12" x2="9" y2="12"></line>
            </svg>
            Logout
          </button>
          <button @click="handleDelete" class="dropdown-item delete-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3,6 5,6 21,6"></polyline>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
            </svg>
            Delete
          </button>
        </div>
      </div>

      <!-- Interface Section -->
      <div class="settings-section">
        <div class="section-header" @click="toggleInterfaceDropdown">
          <div class="section-info">
            <svg class="section-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
              <line x1="9" y1="9" x2="15" y2="9"></line>
              <line x1="9" y1="15" x2="15" y2="15"></line>
            </svg>
            <span class="section-title">Interface</span>
          </div>
          <svg class="dropdown-arrow" :class="{ 'rotated': interfaceDropdownOpen }" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="6,9 12,15 18,9"></polyline>
          </svg>
        </div>
        
        <div v-show="interfaceDropdownOpen" class="dropdown-content">
          <div class="dropdown-item theme-item" @click="showThemeOptions">
            <div class="theme-info">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="5"></circle>
                <line x1="12" y1="1" x2="12" y2="3"></line>
                <line x1="12" y1="21" x2="12" y2="23"></line>
                <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                <line x1="1" y1="12" x2="3" y2="12"></line>
                <line x1="21" y1="12" x2="23" y2="12"></line>
                <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
              </svg>
              <span>Theme</span>
            </div>
            <div v-show="themeSelectorOpen" class="theme-selector">
              <button 
                v-for="theme in themes" 
                :key="theme.value"
                @click="selectTheme(theme.value)"
                :class="['theme-option', { 'active': currentTheme === theme.value }]"
              >
                <div class="theme-preview" :style="{ background: theme.preview }"></div>
                <span>{{ theme.name }}</span>
              </button>
            </div>
          </div>
          
          <div class="dropdown-item font-item">
            <div class="font-info">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="4,7 4,3 20,3 20,7"></polyline>
                <line x1="9" y1="20" x2="15" y2="20"></line>
                <line x1="12" y1="4" x2="12" y2="20"></line>
              </svg>
              <span>Font Size</span>
            </div>
            <div class="font-slider">
              <input 
                type="range" 
                min="12" 
                max="20" 
                v-model="fontSize"
                @input="updateFontSize"
                class="slider"
              />
              <span class="font-size-value">{{ fontSize }}px</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Edit User Modal (Teleport) -->
    <Teleport to="body">
      <div v-if="editModalOpen" class="modal-overlay" @click="closeEditModal">
        <div class="modal-content" @click.stop>
          <div class="modal-header">
            <h2>Edit Profile</h2>
            <button @click="closeEditModal" class="modal-close">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label for="userName">Name</label>
              <input 
                id="userName"
                v-model="editUserName"
                type="text"
                placeholder="Enter your name"
                class="form-input"
              />
            </div>
          </div>
          <div class="modal-footer">
            <button @click="closeEditModal" class="btn btn-secondary">Cancel</button>
            <button @click="saveUserEdit" class="btn btn-primary">Save</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Sessions Modal -->
    <Teleport to="body">
      <div v-if="sessionsModalOpen" class="modal-overlay" @click="closeSessionsModal">
        <div class="modal-content" @click.stop>
          <div class="modal-header">
            <h2>Active Sessions</h2>
            <button @click="closeSessionsModal" class="modal-close">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
          </div>
          <div class="modal-body">
            <div class="sessions-list">
              <div v-for="session in activeSessions" :key="session.id" class="session-item">
                <div class="session-info">
                  <div class="session-device">{{ session.device }}</div>
                  <div class="session-time">{{ session.lastActive }}</div>
                </div>
                <button @click="removeSession(session.id)" class="session-remove">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                  </svg>
                </button>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button @click="closeSessionsModal" class="btn btn-primary">Close</button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'

const emit = defineEmits<{
  close: []
}>()

// Dropdown states
const accountDropdownOpen = ref(false)
const interfaceDropdownOpen = ref(false)

// Modal states
const editModalOpen = ref(false)
const sessionsModalOpen = ref(false)
const themeSelectorOpen = ref(false)

// User data
const editUserName = ref('John Doe')

// Settings data
const fontSize = ref(14)
const currentTheme = ref('light')

const themes = reactive([
  { name: 'Light', value: 'light', preview: 'linear-gradient(135deg, #ffffff, #f5f5f5)' },
  { name: 'Dark', value: 'dark', preview: 'linear-gradient(135deg, #1a1a1a, #2d2d2d)' },
  { name: 'Blue', value: 'blue', preview: 'linear-gradient(135deg, #e3f2fd, #bbdefb)' },
  { name: 'Purple', value: 'purple', preview: 'linear-gradient(135deg, #f3e5f5, #e1bee7)' }
])

const activeSessions = reactive([
  { id: 1, device: 'Chrome on Windows', lastActive: '2 minutes ago', current: true },
  { id: 2, device: 'Safari on iPhone', lastActive: '1 hour ago', current: false },
  { id: 3, device: 'Firefox on Mac', lastActive: '3 days ago', current: false }
])

// Methods
const toggleAccountDropdown = () => {
  accountDropdownOpen.value = !accountDropdownOpen.value
  interfaceDropdownOpen.value = false
}

const toggleInterfaceDropdown = () => {
  interfaceDropdownOpen.value = !interfaceDropdownOpen.value
  accountDropdownOpen.value = false
}

const openEditModal = () => {
  editModalOpen.value = true
  accountDropdownOpen.value = false
  interfaceDropdownOpen.value = false
}

const closeEditModal = () => {
  editModalOpen.value = false
}

const saveUserEdit = () => {
  console.log('Saving user name:', editUserName.value)
  editModalOpen.value = false
}

const showSessions = () => {
  sessionsModalOpen.value = true
  accountDropdownOpen.value = false
  interfaceDropdownOpen.value = false
}

const closeSessionsModal = () => {
  sessionsModalOpen.value = false
}

const removeSession = (sessionId: number) => {
  const index = activeSessions.findIndex(s => s.id === sessionId)
  if (index !== -1) {
    activeSessions.splice(index, 1)
  }
}

const showThemeOptions = () => {
  themeSelectorOpen.value = !themeSelectorOpen.value
}

const selectTheme = (theme: string) => {
  currentTheme.value = theme
  console.log('Selected theme:', theme)
}

const updateFontSize = () => {
  document.documentElement.style.fontSize = fontSize.value + 'px'
}

const handleLogout = () => {
  if (confirm('Are you sure you want to logout?')) {
    console.log('Logging out...')
    accountDropdownOpen.value = false
  }
}

const handleDelete = () => {
  if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
    console.log('Deleting account...')
    accountDropdownOpen.value = false
  }
}
</script>

<style scoped>
.settings-screen {
  height: 100vh;
  background: white;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  display: flex;
  flex-direction: column;
}

.settings-header {
  background: linear-gradient(135deg, #2196f3, #1976d2);
  color: white;
  padding: 16px 20px;
  display: flex;
  align-items: center;
  gap: 16px;
  box-shadow: 0 2px 8px rgba(33, 150, 243, 0.1);
}

.back-btn {
  background: transparent;
  border: none;
  padding: 8px;
  border-radius: 8px;
  cursor: pointer;
  color: white;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.back-btn:hover {
  background: rgba(255, 255, 255, 0.1);
}

.back-btn svg {
  width: 20px;
  height: 20px;
  flex-shrink: 0;
}

.settings-title {
  font-size: 20px;
  font-weight: 600;
  margin: 0;
}

.settings-content {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
}

.settings-section {
  margin-bottom: 16px;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  border: 1px solid #e3f2fd;
  background: white;
  overflow: hidden;
}

.section-header {
  background: linear-gradient(135deg, #f8f9fa, #ffffff);
  padding: 16px 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  cursor: pointer;
  transition: all 0.3s ease;
  border: none;
}

.section-header:hover {
  background: linear-gradient(135deg, #e3f2fd, #f8f9fa);
}

.section-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.section-icon {
  width: 18px;
  height: 18px;
  color: #2196f3;
  flex-shrink: 0;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  color: #1565c0;
}

.dropdown-arrow {
  width: 18px;
  height: 18px;
  color: #2196f3;
  transition: transform 0.3s ease;
  flex-shrink: 0;
}

.dropdown-arrow.rotated {
  transform: rotate(180deg);
}

.dropdown-content {
  background: white;
  border-top: 1px solid #e3f2fd;
}

.dropdown-item {
  width: 100%;
  padding: 16px 20px;
  border: none;
  background: transparent;
  display: flex;
  align-items: center;
  gap: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 14px;
  color: #333;
  text-align: left;
  border-bottom: 1px solid #f0f0f0;
}

.dropdown-item svg {
  width: 16px;
  height: 16px;
  flex-shrink: 0;
}

.dropdown-item:hover {
  background: #f5f5f5;
}

.dropdown-item:last-child {
  border-bottom: none;
}

.delete-item:hover {
  background: #ffebee;
  color: #d32f2f;
}

.theme-item,
.font-item {
  flex-direction: column;
  align-items: flex-start;
  gap: 8px;
}

.theme-info,
.font-info {
  display: flex;
  align-items: center;
  gap: 12px;
  width: 100%;
}

.theme-info svg,
.font-info svg {
  width: 16px;
  height: 16px;
  flex-shrink: 0;
}

.theme-selector {
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 8px;
}

.theme-option {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  border-radius: 8px;
  border: 2px solid transparent;
  cursor: pointer;
  transition: all 0.3s ease;
}

.theme-option:hover {
  background: #f5f5f5;
}

.theme-option.active {
  border-color: #2196f3;
  background: #e3f2fd;
}

.theme-preview {
  width: 20px;
  height: 20px;
  border-radius: 4px;
  border: 1px solid #ddd;
}

.font-slider {
  display: flex;
  align-items: center;
  gap: 12px;
  width: 100%;
}

.slider {
  flex: 1;
  height: 8px;
  border-radius: 4px;
  background: #e3f2fd;
  outline: none;
  cursor: pointer;
  -webkit-appearance: none;
  appearance: none;
  transition: opacity 0.2s ease;
}

.slider:hover {
  opacity: 0.8;
}

.slider::-webkit-slider-thumb {
  appearance: none;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: #2196f3;
  cursor: pointer;
  box-shadow: 0 2px 4px rgba(33, 150, 243, 0.2);
  transition: transform 0.2s ease;
}

.slider::-webkit-slider-thumb:hover {
  transform: scale(1.1);
}

.slider::-moz-range-thumb {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: #2196f3;
  cursor: pointer;
  box-shadow: 0 2px 4px rgba(33, 150, 243, 0.2);
  border: none;
  transition: transform 0.2s ease;
}

.slider::-moz-range-thumb:hover {
  transform: scale(1.1);
}

.font-size-value {
  min-width: 45px;
  text-align: center;
  font-weight: 600;
  color: #2196f3;
}

/* Modal Styles */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 16px;
  width: 90%;
  max-width: 500px;
  max-height: 80vh;
  overflow: hidden;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
}

.modal-header {
  background: linear-gradient(135deg, #2196f3, #1976d2);
  color: white;
  padding: 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.modal-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.modal-close {
  background: transparent;
  border: none;
  padding: 8px;
  border-radius: 8px;
  cursor: pointer;
  color: white;
  transition: all 0.3s ease;
}

.modal-close:hover {
  background: rgba(255, 255, 255, 0.1);
}

.modal-close svg {
  width: 18px;
  height: 18px;
  flex-shrink: 0;
}

.modal-body {
  padding: 20px;
  max-height: 400px;
  overflow-y: auto;
}

.form-group {
  margin-bottom: 16px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  font-weight: 600;
  color: #1565c0;
}

.form-input {
  width: 100%;
  padding: 12px 16px;
  border: 2px solid #e3f2fd;
  border-radius: 8px;
  font-size: 14px;
  outline: none;
  transition: all 0.3s ease;
}

.form-input:focus {
  border-color: #2196f3;
  box-shadow: 0 0 0 3px rgba(33, 150, 243, 0.1);
}

.modal-footer {
  padding: 20px;
  border-top: 1px solid #e3f2fd;
  display: flex;
  gap: 12px;
  justify-content: flex-end;
}

.btn {
  padding: 10px 20px;
  border-radius: 8px;
  border: none;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 14px;
}

.btn-primary {
  background: linear-gradient(135deg, #2196f3, #1976d2);
  color: white;
}

.btn-primary:hover {
  background: linear-gradient(135deg, #1976d2, #1565c0);
  transform: translateY(-1px);
}

.btn-secondary {
  background: #f5f5f5;
  color: #666;
}

.btn-secondary:hover {
  background: #e0e0e0;
}

/* Sessions Styles */
.sessions-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.session-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px;
  border: 1px solid #e3f2fd;
  border-radius: 8px;
  background: #f8f9fa;
}

.session-info {
  flex: 1;
}

.session-device {
  font-weight: 600;
  color: #1565c0;
  margin-bottom: 4px;
}

.session-time {
  font-size: 12px;
  color: #666;
}

.session-remove {
  background: transparent;
  border: none;
  padding: 8px;
  border-radius: 6px;
  cursor: pointer;
  color: #666;
  transition: all 0.3s ease;
}

.session-remove:hover {
  background: #ffebee;
  color: #d32f2f;
}

.session-remove svg {
  width: 14px;
  height: 14px;
  flex-shrink: 0;
}

/* Responsive Design */
@media (max-width: 768px) {
  .settings-header {
    padding: 12px 16px;
  }
  
  .settings-content {
    padding: 16px;
  }
  
  .section-header {
    padding: 14px 16px;
  }
  
  .dropdown-item {
    padding: 14px 16px;
  }
  
  .modal-content {
    width: 95%;
    margin: 20px;
  }
  
  .modal-header,
  .modal-body,
  .modal-footer {
    padding: 16px;
  }
}
</style>
