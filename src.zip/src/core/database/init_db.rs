use crate::utils::app_error::AppError;
use sqlx::SqlitePool;
use sqlx::Row;
use sqlx::sqlite::SqliteRow;

pub async fn init_db(pool: &SqlitePool) -> Result<(), AppError> {
     
     let row: SqliteRow = sqlx::query("PRAGMA user_version")
     .fetch_one(pool)
     .await?;

    let version: i32 = row.get(0);
      
    if version == 0 {
   
     let _ = sqlx::query(" CREATE TABLE IF NOT EXISTS account (
       id INTEGER PRIMARY KEY,
       username TEXT NOT NULL,
       name TEXT NOT NULL,
       pub_key TEXT NOT NULL,
       private_key TEXT NOT NULL,
       installation_id TEXT NOT NULL,
       last_key TEXT NOT NULL,
       last_seen TEXT NOT NULL,
       device_name TEXT NOT NULL,
       password TEXT NOT NULL
        )").execute(pool).await;


        let _ = sqlx::query("  CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY,
        payload TEXT,
        attachment_name TEXT,
        attachment_type TEXT,
        caption TEXT,
        recipient TEXT NOT NULL,
        sender TEXT NOT NULL,
        seen BOOL,
        pub_key TEXT NOT NULL,
        locale TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        deleted_at TEXT
            )").execute(pool).await;

       let _ = sqlx::query("  CREATE TABLE IF NOT EXISTS unsent_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        payload TEXT,
        attachment_name TEXT,
        attachment_type TEXT,
        caption TEXT,
        recipient TEXT NOT NULL,
        sender TEXT NOT NULL,
        seen BOOL,
        pub_key TEXT NOT NULL,
        locale TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        deleted_at TEXT
            )").execute(pool).await;


      let _ = sqlx::query("  CREATE TABLE IF NOT EXISTS edited_messages (
      id INTEGER  PRIMARY KEY,
      message_id INTEGER NOT NULL,
      time TEXT NOT NULL,
       FOREIGN KEY (message_id) REFERENCES messages(id)
     )").execute(pool).await;

     let _ = sqlx::query("  CREATE TABLE IF NOT EXISTS deleted_messages (
      id INTEGER PRIMARY KEY,
      message_id INTEGER NOT NULL,
      time TEXT NOT NULL,
       FOREIGN KEY (message_id) REFERENCES messages(id)
     )").execute(pool).await;

    let _ = sqlx::query("  CREATE TABLE IF NOT EXISTS seen_messages (
       id INTEGER PRIMARY KEY,
       message_id INTEGER NOT NULL,
       time TEXT NOT NULL,
       FOREIGN KEY (message_id) REFERENCES messages(id)
     )").execute(pool).await;

     let _ = sqlx::query("CREATE TABLE IF NOT EXISTS sent_messages (
       id INTEGER PRIMARY KEY,
       message_id INTEGER NOT NULL,
       payload TEXT,
       caption TEXT,
       attachment_name TEXT,
       attachment_type TEXT,
       FOREIGN KEY (message_id) REFERENCES messages(id)
     )").execute(pool).await;

      let _ = sqlx::query("CREATE TABLE IF NOT EXISTS unsent_messages (
       id INTEGER PRIMARY KEY AUTOINCREMENT,
       message_id INTEGER NOT NULL,
       payload TEXT,
       caption TEXT,
       attachment_name TEXT,
       attachment_type TEXT,
       FOREIGN KEY (message_id) REFERENCES messages(id)
     )").execute(pool).await;

    }
      
    Ok(())
}

