use sqlx::{SqlitePool, sqlite::SqlitePoolOptions};

use crate::utils::app_error::AppError;


pub async fn create_conn(path: &str) -> Result<SqlitePool, AppError> {
    
     #[cfg(debug_assertions)] {
          let option = SqlitePoolOptions::new();
     return Ok(option.connect("sqlite::memory:").await?);
     } 
     
      #[cfg(not(debug_assertions))]
     {
      let db_url = format!("sqlite://{}", path);

     Ok(SqlitePool::connect(&db_url).await?)
     }
    
}