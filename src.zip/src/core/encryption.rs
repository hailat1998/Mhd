pub mod decrypt;
pub mod encrypt;

use rand_core_compat::rand_core_0_6::OsRng;
use x25519_dalek::{PublicKey, StaticSecret, EphemeralSecret};
use sha2::Sha256;

use hkdf::Hkdf;

pub struct KeyPair {
    pub private: StaticSecret,
    pub public: PublicKey,
}

fn derive_key(shared: &[u8]) -> [u8; 64] {
    let hk = Hkdf::<Sha256>::new(None, shared);
    let mut key = [0u8; 64];
    hk.expand(b"aes-siv key", &mut key).unwrap();
    key
}

pub fn generate_keypair() -> KeyPair {
    let private = StaticSecret::random_from_rng(OsRng);
    let public = PublicKey::from(&private);
    KeyPair { private, public }
}



