use serde::{Deserialize, Serialize};
use sqlx::FromRow;


#[derive(Serialize, Deserialize, FromRow, Debug, Clone)]
pub struct Account {
    pub id: i64,
    pub username: String,
    pub name: String,
    pub pub_key: String,
    pub private_key: String,
    pub installation_id: String,
    pub last_key: String, 
    pub last_seen: String,
    pub device_name: String,
    pub password: String,
    pub is_active: bool
}


