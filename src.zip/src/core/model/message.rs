use serde::{Deserialize, Serialize};

use sqlx::{prelude::FromRow };
use time::OffsetDateTime;
use super::FileType;

#[derive(Serialize, Deserialize, FromRow, Debug, Clone)]
pub struct Message {
    pub id: Option<i64>,
    pub payload: Option<String>,
    pub attachment_name: Option<String>,
    pub attachment_type: Option<String>,
    pub caption: Option<String>, 
    pub recipient: String,
    pub sender: String,
    pub seen: bool,
    pub pub_key: String,
    pub locale: Option<String>,
    pub created_at: OffsetDateTime,
    pub updated_at: OffsetDateTime,
    pub deleted_at: Option<OffsetDateTime>
}

impl Message {
    pub fn new(id: Option<i64>, payload: Option<String>, attachment_name: Option<String>, attachment_type: Option<String>, caption: Option<String>, recipient: String, sender: String, seen: bool, pub_key: String, locale: Option<String>, created_at: OffsetDateTime, updated_at: OffsetDateTime, deleted_at: Option<OffsetDateTime>) -> Self {
        Self { id, payload, attachment_name, attachment_type, caption, recipient, sender, seen, pub_key, locale, created_at, updated_at, deleted_at }
    }
}


#[derive(Serialize, Deserialize, FromRow, Debug, Clone)]
pub struct LocalMessage {
    pub id: i64,
    pub payload: Option<String>,
    pub caption: Option<String>, 
    pub recipient: String,
    pub sender: String,
    pub seen: Option<bool>,
    pub pub_key: String,
    pub locale: Option<String>,
    pub created_at: String,
    pub updated_at: String,
    pub deleted_at: Option<String>
}


#[derive(Serialize, Deserialize, FromRow, Debug, Clone)]
pub struct UnsentLocalMessage {
    pub id: Option<i64>,
    pub payload: Option<String>,
    pub caption: Option<String>, 
    pub recipient: String,
    pub sender: String,
    pub seen: Option<bool>,
    pub pub_key: String,
    pub locale: Option<String>,
    pub created_at: String,
    pub updated_at: String,
    pub deleted_at: Option<String>
}


#[derive(Serialize, Deserialize, FromRow, Debug, Clone)]
pub struct SeenMessage {
    pub id: i64,
    pub message_id: i64,
    pub time: String
}


#[derive(Serialize, Deserialize, FromRow, Debug, Clone)]
pub struct EditMessage {
    pub id: i64,
    pub message_id: i64,
    pub time: String
}


#[derive(Serialize, Deserialize, FromRow, Debug, Clone)]
pub struct DeleteMessage {
    pub id: i64,
    pub message_id: i64,
    pub time: String
}

#[derive(Serialize, Deserialize, FromRow, Debug, Clone)]
pub struct Attachment {
    pub id: i64,
    pub message_id: i64,
    pub time: String,
    pub name: String,
    pub type_file: String
}

#[derive(Serialize, Deserialize, FromRow, Debug, Clone)]
pub struct UnsentAttachment {
    pub id: Option<i64>,
    pub message_id: i64,
    pub time: String,
    pub name: String,
    pub type_file: String
}

#[derive(Serialize, Deserialize, FromRow, Debug, Clone)]
pub struct SentMessage {
    pub id: i64,
    pub message_id: i64,
    pub payload: Option<String>,
    pub attachment_name: Option<String>,
    pub attachment_type: Option<String>,
    pub caption: Option<String>
}

impl SentMessage {
    pub fn new(id: i64, message_id: i64, payload: Option<String>, attachment_name: Option<String>, attachment_type: Option<String>, caption: Option<String>) -> Self {
        Self { id, message_id, payload, attachment_name, attachment_type, caption }
    }
}


#[derive(Serialize, Deserialize, FromRow, Debug, Clone)]
pub struct UnsentMessage {
    pub id: Option<i64>,
    pub message_id: i64,
    pub payload: Option<String>,
    pub attachment_name: Option<String>,
    pub attachment_type: Option<String>,
    pub caption: Option<String>
}


