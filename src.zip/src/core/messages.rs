pub mod user_messages;
pub mod server_messages;


use serde::{Deserialize, Serialize};
pub use server_messages::ServerMessage;
pub use user_messages::UserMessage;


#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum ComposeMessage {
    ServerMessageCompose { key: String, username: String, server_message: String, tracker: u64 },
    UserMessageCompose { key: String, username: String, installation_id: String, user_message: String, tracker: u64 },
    ServerMessage {server_message: ServerMessage, tracker: u64},
    UserMessage{user_message: UserMessage, tracker: u64},
    Error {
        msg: String,
        tracker: u64
    }
}