use std::time::Instant;

use tokio_tungstenite::connect_async;
use futures_util::{ StreamExt, SinkExt};
use url::Url;
use std::time::Duration;
use tokio_tungstenite::tungstenite::Message;
use tauri::{AppHandle, async_runtime};
use tokio::sync::mpsc::{Sender, Receiver};
use crate::core::messages::{ComposeMessage, ServerMessage};
use tauri::Manager;
use crate::app_state::{AppState, DisconnetTx, NetState};
use crate::utils::encryption_utils::{base64_to_array, bytes_to_base64, decrypt_string, encrypt_string, generate_12_bytes};

pub async fn client(
    app_handle: AppHandle,
    sender: Sender<ComposeMessage>,
    mut receiver: Receiver<ComposeMessage>,
    net_state_updater: DisconnetTx,
) {
    let url = Url::parse("http://localhost:3000/live").unwrap();

    loop {
        println!("Connecting...");

        let (ws_stream, _) = match connect_async(url.clone()).await {
            Ok(v) => v,
            Err(_) => {
                tokio::time::sleep(Duration::from_secs(2)).await;
                continue;
            }
        };

        let (mut write, mut read) = ws_stream.split();

        net_state_updater.send_replace(NetState::Connected);

        let app_handle_clone1 = app_handle.clone();
        let app_handle_clone2 = app_handle.clone();

        let mut initialized = false;

        let result = tokio::select! {

            // 📤 SEND LOOP
            _ = async {
                while let Some(msg) = receiver.recv().await {

                    match msg {
                        ComposeMessage::UserMessage{user_message, tracker} => {
                            let string_form = serde_json::to_string(&user_message).unwrap();

                            let state = app_handle_clone1.try_state::<AppState>().unwrap();
                            let username = state.username.borrow().clone();
                            let key = state.key.borrow().clone();
                            let installation_id = state.installation_id.borrow().clone();

                            let nonce = generate_12_bytes();
                            let encrypted = encrypt_string(&key, &string_form, &nonce).unwrap();

                            let message = ComposeMessage::UserMessageCompose {
                                key: bytes_to_base64(&nonce),
                                username,
                                installation_id,
                                user_message: encrypted,
                                tracker,
                            };

                            let string_form = serde_json::to_string(&message).unwrap();

                            if write.send(string_form.into()).await.is_err() {
                                break; // 🔥 triggers reconnect
                            }
                        }

                        _ => {}
                    }
                }
            } => "send ended",

            // 📥 RECEIVE LOOP
            _ = async {
                while let Some(msg) = read.next().await {

                    let msg = match msg {
                        Ok(m) => m,
                        Err(_) => break,
                    };

                    if !initialized {
                        initialized = true;
                        net_state_updater.send_replace(NetState::Connected);
                    }

                    if let Message::Text(text) = msg {
                        let parsed: ComposeMessage = serde_json::from_str(&text).unwrap();

                        if let ComposeMessage::ServerMessageCompose { key, server_message, tracker, .. } = parsed {

                            if server_message == "pong" {
                                continue;
                            }

                            let state = app_handle_clone2.try_state::<AppState>().unwrap();
                            let key_dec = state.key.borrow().clone();

                            let nonce = base64_to_array(&key).unwrap();
                            let decrypted = decrypt_string(&key_dec, &server_message, &nonce).unwrap();

                            let parsed_msg: ServerMessage = serde_json::from_str(&decrypted).unwrap();

                            let _ = sender.send(
                                ComposeMessage::ServerMessage {
                                    server_message: parsed_msg,
                                    tracker,
                                }
                            ).await;
                        }
                    }
                }
            } => "receive ended",
        };

        println!("Connection lost: {}", result);

        net_state_updater.send_replace(
            NetState::Disconnected(Instant::now())
        );

        tokio::time::sleep(Duration::from_secs(2)).await;
    }
}