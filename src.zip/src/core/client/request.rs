use serde::{Deserialize, Serialize};


#[derive(Serialize, Deserialize)]
pub struct LoginUser {
    pub username: String,
    pub password: String,
    pub device_id: String
}

#[derive(Serialize, Deserialize)]
pub struct CreateUser {
    pub username: String,
    pub password: String,
    pub pub_key: String,
    pub device_id: String,
    pub name: String
}

#[derive(Serialize, Deserialize)]
pub struct UserResponse {
    pub installation_id: String,
    pub base_64_string: String, // last_key
    pub name: String
}
