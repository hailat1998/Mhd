use crate::{core::client::{CreateUser, LoginUser, UserResponse}, utils::app_error::AppError};


pub async fn login(user_login: &LoginUser) -> Result<UserResponse, AppError> {
  let client = reqwest::Client::new();

   let res = client
        .post("")
        .json(&user_login)
        .send()
        .await?
        .json::<UserResponse>()
        .await?;

        Ok(res)
}

pub async fn signup(create_user: &CreateUser) -> Result<UserResponse, AppError> {
  let client = reqwest::Client::new();

   let res = client
        .post("")
        .json(&create_user)
        .send()
        .await?
        .json::<UserResponse>()
        .await?;

    Ok(res)

}