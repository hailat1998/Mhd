use reqwest::{Client, header::{HeaderMap, HeaderValue}};
use tokio::fs::File;
use tokio_util::io::ReaderStream;
use crate::utils::app_error::AppError;
use tokio::fs::{ create_dir_all};
use tokio::io::AsyncWriteExt;
use std::path::{Path, PathBuf};
use tokio::sync::mpsc::Sender;
use futures_util::StreamExt;
use tokio_util::bytes::Bytes;
use futures_util::stream::BoxStream;


pub async fn upload_file(
    base_url: &str,
    endpoint: &str,
    file_path: &str,
    session_key_enc: &str,
    installation_id: &str,
    progress_tx: Sender<u64>
) -> Result<(), AppError> {
    let client = Client::new();

    let url = format!("{}/{}", base_url.trim_end_matches('/'), endpoint);

    let file = File::open(file_path).await?;

    let mut stream = ReaderStream::new(file);

    let tx = progress_tx.clone();

    let progress_stream: BoxStream<'static, Result<Bytes, std::io::Error>> =
    async_stream::stream! {
        let mut uploaded: u64 = 0;

        while let Some(chunk) = stream.next().await {
            let chunk = chunk?;
            uploaded += chunk.len() as u64;

            let _ = tx.send(uploaded).await;

            yield Ok(chunk);
        }
    }
    .boxed();

    let body = reqwest::Body::wrap_stream(progress_stream);

    let mut headers = HeaderMap::new();
    headers.insert("unique_key", HeaderValue::from_str(session_key_enc).unwrap());
    headers.insert("installation_id", HeaderValue::from_str(installation_id).unwrap());
    headers.insert(
        "content-type",
        HeaderValue::from_static("application/octet-stream"),
    );

    client
        .post(url)
        .headers(headers)
        .body(body)
        .send()
        .await?
        .error_for_status()?;

    Ok(())
}


pub async fn download_file(
    base_url: &str,
    endpoint: &str,
    output_dir: &str,
    file_name: &str,
    session_key_enc: &str,
    installation_id: &str,
    progress_tx: Sender<f64>, // percent: 0.0 -> 100.0
) -> Result<PathBuf, AppError> {
    let client = Client::new();

    let url = format!("{}/{}", base_url.trim_end_matches('/'), endpoint);

    let mut headers = HeaderMap::new();
    headers.insert("unique_key", HeaderValue::from_str(session_key_enc).unwrap());
    headers.insert("installation_id", HeaderValue::from_str(installation_id).unwrap());

    let mut res = client
        .get(url)
        .headers(headers)
        .send()
        .await?
        .error_for_status()?;

    let total_size = res.content_length().unwrap_or(0);

    create_dir_all(output_dir).await?;

    let file_path = Path::new(output_dir).join(file_name);

    let mut file = File::create(&file_path).await?;

    let mut downloaded: u64 = 0;

    while let Some(chunk) = res.chunk().await? {
        file.write_all(&chunk).await?;

        downloaded += chunk.len() as u64;

        let progress = if total_size > 0 {
            (downloaded as f64 / total_size as f64) * 100.0
        } else {
            0.0
        };

        let _ = progress_tx.send(progress).await;
    }

    file.flush().await?;

    let _ = progress_tx.send(100.0).await;

    Ok(file_path)
}

pub async fn delete_resource(
    base_url: &str,
    endpoint: &str,
    session_key_enc: &str,
    installation_id: &str,
) -> Result<(), AppError> {
    let client = Client::new();

   
    let url = format!("{}/{}", base_url.trim_end_matches('/'), endpoint);

    
    let mut headers = HeaderMap::new();
    headers.insert("unique_key", HeaderValue::from_str(session_key_enc).unwrap());
    headers.insert("installation_id", HeaderValue::from_str(installation_id).unwrap());

   
    client
        .delete(url)
        .headers(headers)
        .send()
        .await?
        .error_for_status()?;

    Ok(())
}
