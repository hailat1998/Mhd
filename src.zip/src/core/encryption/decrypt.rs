use aes_gcm::aead::Aead;
use x25519_dalek::{PublicKey, StaticSecret};
use aes_siv::aead::generic_array::GenericArray;
use aes_siv::Aes256SivAead;
use arrayref::array_ref;
use aes_siv::KeyInit;
use base64::{engine::general_purpose::STANDARD, Engine};
use super::*;

pub fn decrypt(receiver_private: &StaticSecret, data_base64: &str) -> Vec<u8> {
    let data = STANDARD.decode(data_base64).unwrap();
    let eph_pub_bytes = &data[..32];
    let ciphertext = &data[32..];

    let eph_public = PublicKey::from(*array_ref![eph_pub_bytes, 0, 32]);

    let shared = receiver_private.diffie_hellman(&eph_public);

    let key = derive_key(shared.as_bytes());
    let cipher = Aes256SivAead::new_from_slice(&key).unwrap();

    let nonce = GenericArray::from_slice(&[0u8; 16]);

    cipher.decrypt(nonce, ciphertext).unwrap()
}
