use aes_gcm::aead::Aead;
use x25519_dalek::{ PublicKey };
use aes_siv::aead::generic_array::GenericArray;
use aes_siv::Aes256SivAead;
use aes_siv::KeyInit;
use base64::{engine::general_purpose::STANDARD, Engine};
use super::*;


pub fn encrypt(receiver_public: &PublicKey, plaintext: &[u8]) -> String {
    let eph_private = EphemeralSecret::random_from_rng(OsRng);
    let eph_public = PublicKey::from(&eph_private);

    let shared = eph_private.diffie_hellman(receiver_public);

    let key = derive_key(shared.as_bytes());
    let cipher = Aes256SivAead::new_from_slice(&key).unwrap();

    let nonce = GenericArray::from_slice(&[0u8; 16]);

    let mut ciphertext = cipher.encrypt(nonce, plaintext).unwrap();

    let mut result = eph_public.as_bytes().to_vec();
    result.append(&mut ciphertext);

    STANDARD.encode(&result)
}