pub mod message;
pub mod account;

use serde::{Deserialize, Serialize};

use sqlx::{ Type };

#[derive(Debug, Type, Serialize, Deserialize, Clone)]
#[sqlx(type_name = "file_type")] 
pub struct FileType {
    pub name: String,
    pub type_of_file: String,
}
