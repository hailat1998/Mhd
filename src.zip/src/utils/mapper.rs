use x25519_dalek::{ StaticSecret};

use crate::commands::ui_data::MessageUI;
use crate::core::encryption::decrypt::decrypt;
use crate::core::encryption::encrypt::encrypt;
use crate::core::model::message::{ Message, SentMessage };

use crate::app_state::AppState;
use tauri::State;
use crate::utils::encryption_utils::string_to_public_key;


pub async fn message_ui_to_message(message_ui: &MessageUI) -> Message {
   
    let public_key = string_to_public_key(&message_ui.pub_key);

    let payload_enc = match &message_ui.payload_dec {
      Some(p) => { 
         Some(encrypt(&public_key, p.as_bytes()))
      },
      _ => None
    };

    let attachment_name_enc = match &message_ui.attachment_name {
      Some(a) => {
          Some(encrypt(&public_key, a.as_bytes()))
      },
      _ => None
    };

    let attachment_type_enc = match &message_ui.attachment_type {
      Some(a) => {
          Some(encrypt(&public_key, a.as_bytes()))
      },
      _ => None
    };

    let caption_enc = match &message_ui.caption_dec {
        Some(c) => {
          Some(encrypt(&public_key, c.as_bytes()))
      },
      _ => None
    };

   Message::new(message_ui.id.clone(), payload_enc, attachment_name_enc, attachment_type_enc, caption_enc, message_ui.recipient.clone(), message_ui.sender.clone(), message_ui.seen, message_ui.pub_key.clone(), message_ui.locale.clone(), message_ui.created_at, message_ui.updated_at, None)
}


pub async fn message_to_message_ui_owned(message: &Message, sent_message: &SentMessage, state: &State<'_, AppState>) -> MessageUI {
  

   let key: [u8; 32] = state.private_key.borrow().clone();


   let secret = StaticSecret::from(key);
     
   let payload_dec = match &sent_message.payload {
      Some(p) => { 
         let d = decrypt(&secret, &p) ;
         Some(String::from_utf8_lossy(&d).to_string())
      },
      _ => None
   };

   let attachment_name_dec = match &sent_message.attachment_name {
      Some(a) => {
          let d = decrypt(&secret, &a) ;
         Some(String::from_utf8_lossy(&d).to_string())
         },
      _ => None
   };

   let attachment_type_dec = match &sent_message.attachment_type {
      Some(a) => {
          let d = decrypt(&secret, &a) ;
         Some(String::from_utf8_lossy(&d).to_string())
      },
      _ => None
   };
   
   let caption_dec = match &sent_message.caption {
      Some(c) => {  
         let d = decrypt(&secret, &c) ;
         Some(String::from_utf8_lossy(&d).to_string())
       },
      _ => None
   };

   MessageUI::new(message.id, payload_dec, caption_dec, message.recipient.clone(), message.sender.clone(), message.seen, message.pub_key.clone(), message.locale.clone(), message.created_at, message.updated_at, attachment_name_dec, attachment_type_dec, false, false)
}



pub async fn message_to_message_ui_unowned(message: &Message, state: &State<'_, AppState>) -> MessageUI {
  

   let key: [u8; 32] = state.private_key.borrow().clone();


   let secret = StaticSecret::from(key);
     
   let payload_dec = match &message.payload {
      Some(p) => { 
         let d = decrypt(&secret, &p) ;
         Some(String::from_utf8_lossy(&d).to_string())
      },
      _ => None
   };

   let attachment_name_dec = match &message.attachment_name {
      Some(a) => {
          let d = decrypt(&secret, &a) ;
         Some(String::from_utf8_lossy(&d).to_string())
         },
      _ => None
   };

   let attachment_type_dec = match &message.attachment_type {
      Some(a) => {
          let d = decrypt(&secret, &a) ;
         Some(String::from_utf8_lossy(&d).to_string())
      },
      _ => None
   };
   
   let caption_dec = match &message.caption {
      Some(c) => {  
         let d = decrypt(&secret, &c) ;
         Some(String::from_utf8_lossy(&d).to_string())
       },
      _ => None
   };

   MessageUI::new(message.id, payload_dec, caption_dec, message.recipient.clone(), message.sender.clone(), message.seen, message.pub_key.clone(), message.locale.clone(), message.created_at, message.updated_at, attachment_name_dec, attachment_type_dec, false, false)
}


pub async fn message_ui_to_sent_message(message_ui: &MessageUI, state: &State<'_, AppState>) -> SentMessage {
    let key = string_to_public_key(&state.public_key.borrow().clone());

    let payload_enc = match &message_ui.payload_dec {
     Some(p) => {
      Some(encrypt(&key, p.as_bytes()))
     },
     _ => None
    };

    let attachment_name_enc = match &message_ui.attachment_name {
      Some(p) => {
      Some(encrypt(&key, p.as_bytes()))
     },
     _ => None
    };

       let attachment_type_enc = match &message_ui.attachment_name {
      Some(a) => {
      Some(encrypt(&key, a.as_bytes()))
     },
     _ => None
    };

       let caption_enc = match &message_ui.attachment_name {
      Some(c) => {
      Some(encrypt(&key, c.as_bytes()))
     },
     _ => None
    };

    SentMessage::new(0, message_ui.id.unwrap_or_default(), payload_enc, attachment_name_enc, attachment_type_enc, caption_enc)
}





