use std::fs;
use crate::utils::app_error::AppError;

fn read(path: &str) -> Option<String> {
    fs::read_to_string(path).ok().map(|s| s.trim().to_string())
}

pub fn get_device_name() -> Result<String, AppError> {
    #[cfg(target_os = "linux")]
    {
      
        if let Some(name) = read("/sys/class/dmi/id/product_name") {
            if !name.is_empty() {
                return Ok(name);
            }
        }

        if let Some(name) = read("/etc/hostname") {
            return Ok(name);
        }

        return Err(AppError::Custom("Failed to read Linux device name".into()));
    }

    #[cfg(target_os = "windows")]
    {
        use std::env;

       
        if let Ok(name) = env::var("COMPUTERNAME") {
            return Ok(name);
        }

        return Err(AppError::Custom("Failed to read Windows device name".into()));
    }

    #[cfg(target_os = "macos")]
    {
        use std::process::Command;

       
        let output = Command::new("scutil")
            .arg("--get")
            .arg("ComputerName")
            .output()?;

        let name = String::from_utf8_lossy(&output.stdout).trim().to_string();

        if !name.is_empty() {
            return Ok(name);
        }

        return Err(AppError::Custom("Failed to read macOS device name".into()));
    }

    #[cfg(target_os = "android")]
    {
        use std::process::Command;

       
        let output = Command::new("getprop")
            .arg("ro.product.model")
            .output()?;

        let name = String::from_utf8_lossy(&output.stdout).trim().to_string();

        if !name.is_empty() {
            return Ok(name);
        }

        return Err(AppError::Custom("Failed to read Android device name".into()));
    }

    #[cfg(not(any(
        target_os = "linux",
        target_os = "windows",
        target_os = "macos",
        target_os = "android"
    )))]
    {
        Err(AppError::Custom("Unsupported OS".into()))
    }
}