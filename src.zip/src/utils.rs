pub mod device_id;
pub mod encryption_utils;
pub mod app_error;
pub mod mapper;

use sha2::{Sha512, Digest, Sha256};
use serde::{Deserialize, Serialize};
use tauri::{AppHandle, path::BaseDirectory};
use std::path::PathBuf;
use tauri::Manager;
use base64::{Engine, engine::general_purpose::STANDARD};
use std::fs;
use directories::ProjectDirs;

pub fn hash_string(input: &str) -> String {
    let mut hasher = Sha512::new(); 
    hasher.update(input.as_bytes());

    let result = hasher.finalize();

   STANDARD.encode(result)
}

pub fn hash_url(url: &str) -> String {
    let mut hasher = Sha256::new();
     hasher.update(url);
     format!("{:x}", hasher.finalize())
}

#[derive(Serialize, Deserialize, Default)]
pub struct Settings {
    pub user_hash: String,
    pub user_dir: String,
    pub active_user: String
}


pub fn get_settings_path(app: &AppHandle) -> PathBuf {
     let mut path = app
        .path()
        .resolve("state.txt", BaseDirectory::AppConfig)
        .map_err(|e| e.to_string());

    path.as_mut().unwrap().push("settings.json");
    path.unwrap()
}


pub fn load_settings(app: &AppHandle) -> Settings {
    let path = get_settings_path(app);

    if let Ok(data) = fs::read_to_string(path) {
        serde_json::from_str(&data).unwrap_or_default()
    } else {
        Settings::default()
    }
}

pub fn save_settings(app: &AppHandle, settings: &Settings) {
    let path = get_settings_path(app);

    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).ok();
    }

    let json = serde_json::to_string_pretty(settings).unwrap();
    std::fs::write(path, json).expect("failed to write settings");
}

pub fn get_db_path(db_file: &str) -> PathBuf {
   let proj_dirs = ProjectDirs::from("com", "mako_frontend", "app")
        .expect("Could not determine project directories");

      let data_dir = proj_dirs.data_dir();

      fs::create_dir_all(data_dir).expect("Failed to create data directory");

      data_dir.join(format!("{}.db", db_file))
}
