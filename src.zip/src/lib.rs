
// Learn more about Tauri commands at https://tauri.app/develop/calling-rust/
pub mod core;
pub mod utils;
pub mod commands;
pub mod app_state;

use std::{collections::HashSet, time::Instant };

use tauri::Manager;
use tauri::Emitter;
use tokio::sync::oneshot;
use tauri::AppHandle;
use tokio::sync::watch;
use crate::app_state::DisconnetTx;
use crate::app_state::DisconnetRx;

use crate::utils::hash_string;
use crate::{app_state::{AppState, NetState}, commands::command_client_manager, core::{client::client_live::client, database::connection::create_conn }, utils::{encryption_utils::base64_to_array, load_settings}};
use crate::core::messages::ServerMessage;
use crate::core::messages::ComposeMessage;
use time::{OffsetDateTime, format_description::well_known::Rfc3339};
use tokio::sync::RwLock;
use crate::core::model::account::Account;
use tokio::sync::mpsc;


#[tauri::command]
fn greet(name: &str) -> String {
    format!("Hello, {}! You've been greeted from Rust!", name)
}

type RequestReceiver = mpsc::Receiver<(ComposeMessage, oneshot::Sender<ServerMessage>)>;
type ServerMessageTx = mpsc::Sender<ComposeMessage>;
type ServerMessageRx = mpsc::Receiver<ComposeMessage>;
type MessageClientTx =  mpsc::Sender<ComposeMessage>;
type MessageClientRx = mpsc::Receiver<ComposeMessage>;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
       .setup(|app| {
    let (request_sender, request_receiver) =
        tokio::sync::mpsc::channel(10);

    let (server_message_sen, server_message_rec) =
        tokio::sync::mpsc::channel(10);

    let (server_message_to_client, server_message_from_client) =
        tokio::sync::mpsc::channel(10);

    let (net_state_setter, net_state_receiver) =
        tokio::sync::watch::channel(NetState::Connecting);

    let (key_tx, key_rx) = watch::channel([0u8; 32]);

    let (username_tx, username_rx) = watch::channel("".to_string());

    let (installation_id_tx, installation_id_rx) = watch::channel("".to_string());

    let (last_seen_tx, last_seen_rx) = watch::channel(OffsetDateTime::now_utc());

    let (session_key_tx, session_key_rx) = watch::channel("".to_string());

    let (public_key_tx, public_key_rx) = watch::channel("".to_string());

    let (private_key_tx, private_key_rx) = watch::channel([0u8; 32]);   
    

    let state = AppState::new(
        key_rx, 
        username_rx, 
        installation_id_rx,
        net_state_receiver.clone(),
        last_seen_rx, 
        request_sender,
        RwLock::new(None),
        RwLock::new(None), 
         session_key_rx,
        public_key_rx,
        private_key_rx, 
       "".to_string(),
         "".to_string(), 
      RwLock::new(HashSet::new()), 
         key_tx, 
        username_tx, 
        installation_id_tx, 
          last_seen_tx, 
         session_key_tx, 
         public_key_tx, 
         private_key_tx);

    app.manage(state);


    let handle_1 = app.handle().clone();

    let net_state_receiver_clone_2 = net_state_receiver.clone();

    update_last_seen(handle_1, net_state_receiver_clone_2);

    // 🚀 spawn async initializer
    let handle_2 = app.handle().clone();
    tauri::async_runtime::spawn(async move {
        initialize_app(
            handle_2,
            request_receiver,
            server_message_rec,
            server_message_to_client,
            server_message_from_client,
            server_message_sen,
            net_state_setter,
        ).await;
    });

    Ok(())
})
        .plugin(tauri_plugin_opener::init())
        .invoke_handler(tauri::generate_handler![greet])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}


pub fn update_last_seen(app: tauri::AppHandle, mut rx: DisconnetRx) {
    let app_clone = app.clone();

    tauri::async_runtime::spawn(async move {
        while rx.changed().await.is_ok() {
            let value = rx.borrow().clone();

            match value {
                NetState::Connected => {
                    let _ = app_clone.emit("connectivity://status", "Connected");
                }

                NetState::Connecting => {
                    let _ = app_clone.emit("connectivity://status", "Connecting");
                }

                NetState::Disconnected(instant) => {
                    let _ = app_clone.emit("connectivity://status", "Disconnected");

                    let now_instant = Instant::now();
                    let base_time = OffsetDateTime::now_utc();

                    let elapsed = now_instant.duration_since(instant);
                    let estimated_time = base_time + elapsed;

                    let state = app_clone.try_state::<AppState>().unwrap();

                    state.last_seen_sender.send_replace( estimated_time);

                    let formatted = estimated_time.format(&Rfc3339).unwrap();

                    let _ = sqlx::query!(
                        r#"UPDATE account SET last_seen = $1 WHERE is_active = $2"#,
                         formatted,
                         true
                    ).execute(state.account_pool.read().await.as_ref().unwrap()).await;

                }
            }
        }
    });
}

async fn initialize_app(
    app: AppHandle,
    request_receiver: RequestReceiver,
    server_message_rec: ServerMessageRx,
    server_message_to_client: MessageClientTx,
    server_message_from_client: MessageClientRx,
    server_message_sen: ServerMessageTx,
    net_state_setter: DisconnetTx,
) {    
    let pool :Option<sqlx::Pool<sqlx::Sqlite>>;

    let acount_db = "mock_account.db";

    let account_pool = create_conn(acount_db).await.expect("Failed to find DB");

    {
        let state = app.state::<AppState>();

        *state.account_pool.write().await = Some(account_pool.clone());
    }

    let active_acount: Option<Account> = sqlx::query_as!(
        Account,
       r#"SELECT * FROM account WHERE is_active = $1"#,
       true
    ).fetch_optional(&account_pool).await.unwrap();

    if let Some(account) = active_acount {        

        pool = Some(create_conn(&hash_string(&account.username)).await.unwrap());

        let state = app.state::<AppState>();

        state.private_key_sender.send_replace( base64_to_array::<32>(&account.private_key).unwrap());       

        state.public_key_sender.send_replace( account.pub_key);

        state.last_seen_sender.send_replace(   OffsetDateTime::parse(&account.last_seen, &Rfc3339).unwrap());

        *state.pool.write().await = pool.clone();
    } else {
       let _ = app.emit("login", "no active user");
    }
   
    spawn_services(
        app,
        request_receiver,
        server_message_rec,
        server_message_to_client,
        server_message_from_client,
        server_message_sen,
        net_state_setter,
    );
}

fn spawn_services(
    app: AppHandle,
    request_receiver: RequestReceiver,
    server_message_rec: ServerMessageRx,
    server_message_to_client: MessageClientTx,
    server_message_from_client: MessageClientRx,
    server_message_sen:ServerMessageTx,
    net_state_setter: DisconnetTx,
) {
    let handle1 = app.clone();
    tauri::async_runtime::spawn(async move {
        command_client_manager(
            handle1,
            request_receiver,
            server_message_rec,
            server_message_to_client,
        ).await;
    });

    let handle2 = app.clone();
    tauri::async_runtime::spawn(async move {
        client(
            handle2,
            server_message_sen,
            server_message_from_client,
            net_state_setter,
        ).await;
    });
}