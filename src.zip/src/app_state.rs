use std::collections::HashSet;
use std::time::Instant;

use sqlx::SqlitePool;
use time::OffsetDateTime;
use tokio::sync::watch;
use tokio::sync::{mpsc::Sender, oneshot};

use crate::core::messages::ServerMessage;

use crate::core::messages::ComposeMessage;
use tokio::sync::RwLock;

pub struct AppState {
    pub key: KeyRx,   // Key used to encrypt and decrypt incoming and out going messages
    pub username: UsernameRx,
    pub installation_id: InstallationIdRx,
    pub net_state: DisconnetRx,
    pub last_seen: LastSeenRx,
    pub request_sender: Sender<(ComposeMessage, oneshot::Sender<ServerMessage>)>,
    pub pool: RwLock<Option<SqlitePool>>,
    pub account_pool: RwLock<Option<SqlitePool>>,
    pub session_key: SessionKeyRx,
    pub public_key: PublicKeyRx,
    pub private_key: PrivateKeyRx,
    pub ob_store_url: String,
    pub user_dir: String,
    pub online_friends: RwLock<HashSet<String>>,
    pub key_sender: KeyTx,
    pub username_sender: UsernameTx,
    pub installation_id_sender: InstallationIdTx,
    pub last_seen_sender: LastSeenTx,
    pub session_key_sender: SessionKeyTx,
    pub public_key_sender: PublicKeyTx,
    pub private_key_sender: PrivateKeyTx
}

impl AppState {
    pub fn new(key: KeyRx, username: UsernameRx, installation_id: InstallationIdRx, net_state: DisconnetRx, last_seen: LastSeenRx, request_sender: Sender<(ComposeMessage, oneshot::Sender<ServerMessage>)>, pool: RwLock<Option<SqlitePool>>, account_pool: RwLock<Option<SqlitePool>>, session_key: SessionKeyRx, public_key: PublicKeyRx, private_key: PrivateKeyRx, ob_store_url: String, user_dir: String, online_friends: RwLock<HashSet<String>>, key_sender: KeyTx, username_sender: UsernameTx, installation_id_sender: InstallationIdTx, last_seen_sender: LastSeenTx, session_key_sender: SessionKeyTx, public_key_sender: PublicKeyTx, private_key_sender: PrivateKeyTx) -> Self {
        Self { key, username, installation_id, net_state, last_seen, request_sender, pool, account_pool, session_key, public_key, private_key, ob_store_url, user_dir, online_friends, key_sender, username_sender, installation_id_sender, last_seen_sender, session_key_sender, public_key_sender, private_key_sender }
    }
}

#[derive(Clone, PartialEq)]
pub enum NetState {
    Connecting,
    Connected,
    Disconnected(Instant)
}


pub type DisconnetTx = watch::Sender<NetState>;
pub type DisconnetRx = watch::Receiver<NetState>;
pub type PrivateKeyTx = watch::Sender<[u8; 32]>;
pub type PrivateKeyRx = watch::Receiver<[u8; 32]>;
pub type PublicKeyTx =  watch::Sender<String>;
pub type PublicKeyRx = watch::Receiver<String>;
pub type LastSeenTx = watch::Sender<OffsetDateTime>;
pub type LastSeenRx = watch::Receiver<OffsetDateTime>;
pub type UsernameTx = watch::Sender<String>;
pub type UsernameRx = watch::Receiver<String>;
pub type InstallationIdTx = watch::Sender<String>;
pub type InstallationIdRx = watch::Receiver<String>;
pub type SessionKeyTx = watch::Sender<String>;
pub type SessionKeyRx = watch::Receiver<String>;
pub type KeyTx = watch::Sender<[u8; 32]>;
pub type KeyRx = watch::Receiver<[u8; 32]>;
