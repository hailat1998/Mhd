use crate::app_state::AppState;
use crate::core::messages::{ComposeMessage, ServerMessage };
use crate::core::model::FileType;
use crate::core::model::message::{Attachment, LocalMessage, SentMessage, UnsentLocalMessage};
use crate::utils::app_error::AppError;
use crate::utils::mapper::{};
use tauri::AppHandle;
use tauri::Manager;
use tauri::State;
use std::collections::{HashMap, HashSet};
use time::format_description::well_known::Rfc3339;
use tokio::sync::oneshot;
use crate::core::messages::UserMessage;
use rand_core_compat::rand_core_0_6;
use crate::core::model::message::Message;
use rand_core_compat::rand_core_0_6::RngCore;


pub async fn join_command(app: AppHandle) -> Result<(), AppError> {

  let state = app.try_state::<AppState>().unwrap();

  let mut rng = rand_core_0_6::OsRng;
  
  let last_seen = state.last_seen.borrow().clone();

  let formatted = last_seen.format(&Rfc3339).unwrap();

  let username = state.username.borrow().clone();

  let session_key = state.session_key.borrow().clone();

  let (tx, _) = oneshot::channel::<ServerMessage>();

  let time = formatted.clone();

  let unsent_messages: Vec<Message> = sqlx::query_as!( 
      Message,          
         r#"
          SELECT 
          *
          FROM unsent_messages
          WHERE updated_at > $1 
          "#,
       last_seen
        )       
        .fetch_all(state.pool.read().await.as_ref().unwrap())
        .await?;

     let unsent_messages_id: Vec<i64> = unsent_messages.iter().filter_map(|m| m.id).collect();  
     
     let mut query = String::from("SELECT * FROM unsent_message_attachments WHERE message_id IN (");
      let mut count = 0;
     for m in &unsent_messages_id {
      if count != 0 {
       query.push_str(",")
      }     
       query.push('?');
       count += 1;
     }
     query.push(')');

     let mut q = sqlx::query_as::<_, Attachment>(&query);

     for m in &unsent_messages_id {
      q = q.bind(m);
     }

     let attachment = q.fetch_all(state.pool.read().await.as_ref().unwrap()).await?;

     let mut attachment_map = HashMap::new();

     for a in attachment {
      attachment_map.insert(a.id.clone(), a);
     }
    
     let row1: Vec<(i64,)> = sqlx::query_as(      
      "SELECT message_id FROM edited_messages WHERE time <= $1"      
     )
     .bind(&formatted)
     .fetch_all(state.pool.read().await.as_ref().unwrap())
          .await?;

   let edited_messages: HashSet<i64> = row1.into_iter().map(|id| id.0).collect();
     
    let row2: Vec<(i64,)> = sqlx::query_as(       
      "SELECT message_id FROM deleted_messages WHERE time <= $1"      
     )
     .bind(&formatted )
      .fetch_all(state.pool.read().await.as_ref().unwrap())
          .await?;

    let deleted_message_id: Vec<i64> = row2.into_iter().map(|id| id.0).collect();

    let rows3: Vec<(i64,)> = sqlx::query_as(
      "SELECT message_id FROM seen_messages WHERE time <= $1"      
     )
     .bind(&formatted )
      .fetch_all(state.pool.read().await.as_ref().unwrap())
          .await?;

    let seen_message_id: Vec<i64> = rows3.into_iter().map(|id| id.0).collect();

    let mut new = vec![];

    for message in &unsent_messages {
     
        let mut sent_message: Option<SentMessage> = None;
        if message.sender == username.clone() {
         let id = message.id.unwrap();
           let sent_message_here = sqlx::query_as!(
            SentMessage,
            r#"SELECT * FROM unsent_user_messages WHERE message_id = $1"#,
            id
          ).fetch_optional(state.pool.read().await.as_ref().unwrap()).await?;

          if sent_message_here.is_some() {            
            sent_message = sent_message_here; 
          }
        }  
        new.push((message.clone(), sent_message));
     
    }
   
    let mut query_2 = String::from("SELECT * FROM messages WHERE id IN (");
    
    for m in &edited_messages {
      if count != 0 {
       query_2.push_str(",")
      }     
       query_2.push('?');
       count += 1;
     }
     query_2.push(')');   

   let mut q_2: sqlx::query::QueryAs<'_, _, Message, _> = sqlx::query_as::<_, Message>(&query_2);
      let mut co = 0;
    for m in &edited_messages {
      if co != 0 {
       q_2 = q_2.bind(m);
      }
      co += 1;
     }

   let edit_messages_local = q_2.fetch_all(state.pool.read().await.as_ref().unwrap()).await.unwrap();   

   let mut query_3 = String::from("SELECT * FROM sent_user_messages WHERE message_id IN (");

   let mut q_3 =  sqlx::query_as::<_, SentMessage>(&query_3);
    let mut c = 0;
    for m in &edited_messages {
      if c != 0 {
       q_3 = q_3.bind(m);
      }
      c += 1;
     }

   let sent_messages_edit = q_3.fetch_all(state.pool.read().await.as_ref().unwrap()).await.unwrap();   

   let user_message = UserMessage:: Join { delete: deleted_message_id, edit: edit_messages_local, seen_message: seen_message_id,  new: new, last_seen: last_seen.unix_timestamp(), username: username.clone(), unique_key: session_key.clone(), sent_message_edit: sent_messages_edit };  


   let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx)).await;

    Ok(())

  }

pub async fn join_finisher(state_outer: State<'_, AppState>, server_message_result: Result<ServerMessage, ()>) -> Result<(), AppError> { 
  
     let state = state_outer;

      let mut rng = rand_core_0_6::OsRng;

     if let Ok(ServerMessage::JoinReplay { delete, edit, new,  new_message_replay, new_sent_replay }) = server_message_result {
       
        let mut tx = state.pool.read().await.as_ref().unwrap().begin().await?;

        for id in &delete { 
         sqlx::query("DELETE FROM _messages WHERE id = $1")
         .bind(*id)
        .execute(&mut *tx)
        .await?;
        }

     
       for m in &edit {
       let _ = sqlx::query("INSERT OR REPLACE INTO messages (id, payload, attachment_name, attachment_type, caption, recipient, sender, seen, pub_key, locale, created_at, updated_at, deleted_at) 
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)")
        .bind(m.id)
        .bind(&m.payload)
        .bind(&m.attachment_name)
        .bind(&m.attachment_type)
        .bind(&m.caption)
        .bind(&m.recipient)
        .bind(&m.sender)
        .bind(&m.seen)
        .bind(&m.pub_key)
        .bind(&m.locale)
        .bind(m.created_at)
        .bind(m.updated_at)
        .bind(match m.deleted_at {
          Some(v) => { Some(v) },
          None => None
        }).execute(&mut *tx).await;

       }
       
       for m in &new {

      let _ =  sqlx::query("INSERT OR REPLACE INTO messages (id, payload, attachment_name, attachment_type, caption, recipient, sender, seen, pub_key, locale, created_at, updated_at, deleted_at) 
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)")
        .bind(m.id)
        .bind(&m.payload)
        .bind(&m.attachment_name)
        .bind(&m.attachment_type)
        .bind(&m.caption)
        .bind(&m.recipient)
        .bind(&m.sender)
        .bind(&m.seen)
        .bind(&m.pub_key)
        .bind(&m.locale)
        .bind(&m.created_at.format(&Rfc3339).unwrap())
        .bind(&m.updated_at.format(&Rfc3339).unwrap())
        .bind(match m.deleted_at {
          Some(v) => { Some(v.format(&Rfc3339).unwrap()) },
          None => None
        }).execute(&mut *tx).await; 
       }

       for s in new_sent_replay { 
          let _ = sqlx::query("INSERT OR REPLACE INTO sent_user_messages (id, message_id, payload, caption, attachment_name, attachment_type)
          VALUES ($1, $2, $3, $4, $5, $6)")
          .bind(s.id)
          .bind(s.message_id)
          .bind(s.payload)
          .bind(s.caption)
          .bind(s.attachment_name)
          .bind(s.attachment_type)
          .execute(&mut *tx).await;
        }

      for m in &new_message_replay {
         let _ =  sqlx::query("INSERT OR REPLACE INTO messages (id, payload, attachment_name, attachment_type, caption, recipient, sender, seen, pub_key, locale, created_at, updated_at, deleted_at) 
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)")
        .bind(m.id)
        .bind(&m.payload)
        .bind(&m.attachment_name)
        .bind(&m.attachment_type)
        .bind(&m.caption)
        .bind(&m.recipient)
        .bind(&m.sender)
        .bind(&m.seen)
        .bind(&m.pub_key)
        .bind(&m.locale)
        .bind(&m.created_at.format(&Rfc3339).unwrap())
        .bind(&m.updated_at.format(&Rfc3339).unwrap())
        .bind(match m.deleted_at {
          Some(v) => { Some(v.format(&Rfc3339).unwrap()) },
          None => None
        }).execute(&mut *tx).await; 
      }

       let _ = tx.commit();
    }

    Ok(())
}