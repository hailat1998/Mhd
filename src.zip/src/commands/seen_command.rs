use tauri::{AppHandle, ipc::Channel} ;
use super::ResultOp;
use serde::{Deserialize, Serialize};
use crate::app_state::NetState;
use crate::utils::app_error::AppError;
use crate::core::messages::ServerMessage;
use tauri::Manager;
use tokio::sync::oneshot;
use crate::app_state::AppState;
use crate::core::messages::UserMessage;
use crate::core::messages::ComposeMessage;
use rand_core_compat::rand_core_0_6;
use rand_core_compat::rand_core_0_6::RngCore;

pub async fn seen(app: AppHandle, message_event: Channel<SeenEvent>, message_id: i64,) -> Result<(), AppError> {

 let (tx, rx) = oneshot::channel::<ServerMessage>();

 let state = app.try_state::<AppState>().unwrap();

 if state.net_state.borrow().clone() == NetState::Connected {

 let mut rng = rand_core_0_6::OsRng;

 let user_message = UserMessage::Seen { message_id: message_id.clone(), username:  state.username.borrow().clone(), unique_key: state.session_key.borrow().clone() };

 let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx)).await;

 let _ = rx.await;

 let _ = sqlx::query("UPDATE local_messages SET seen = TRUE WHERE id = $1").bind(message_id).execute(state.pool.read().await.as_ref().unwrap()).await;

 let _ = message_event.send(SeenEvent::Result { r: ResultOp::Ok });
 
}
 
 Ok(())
}


pub async fn seen_receive(app: AppHandle, message_id: i64) {
    let state = app.try_state::<AppState>().unwrap(); 

    //emit here to UI

     let _ = sqlx::query("UPDATE local_messages SET seen = TRUE WHERE id = $1").bind(message_id).execute(state.pool.read().await.as_ref().unwrap()).await;
} 


#[derive(Serialize, Deserialize)]
pub enum SeenEvent {
    Result { r: ResultOp }
}