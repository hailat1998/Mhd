use tauri::{AppHandle, ipc::Channel} ;
use super::ResultOp;
use serde::{Deserialize, Serialize};
use crate::app_state::NetState;
use crate::core::messages::server_messages::ResultHere;
use crate::core::messages::user_messages::ProfilePicAction;
use crate::utils::app_error::AppError;
use crate::core::messages::ServerMessage;
use tauri::Manager;
use tokio::sync::oneshot;
use crate::app_state::AppState;
use crate::core::messages::UserMessage;
use crate::core::messages::ComposeMessage;
use rand_core_compat::rand_core_0_6;
use rand_core_compat::rand_core_0_6::RngCore;


pub async fn profile_pic(app: AppHandle, message_event: Channel<ProfilePicEvent>, profile_pic_action: ProfilePicAction ) -> Result<(), AppError> {
 

 let state = app.try_state::<AppState>().unwrap(); 

 let mut rng = rand_core_0_6::OsRng;

 if state.net_state.borrow().clone() == NetState::Connected {

 let (tx, rx) = oneshot::channel::<ServerMessage>();

 let user_message = UserMessage::ProfilePic { action: profile_pic_action, username: state.username.borrow().clone(), unique_key: state.session_key.borrow().clone() };

 let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx)).await;

 let server_message = rx.await;

 if let Ok(ServerMessage::ProfilePicReplay { result }) = server_message {
    if let ResultHere::Ok = result {
     let _ = message_event.send(ProfilePicEvent::ResultProfilePic { r: ResultOp::Ok });
    } else {
     let _ = message_event.send(ProfilePicEvent::ResultProfilePic { r: ResultOp::Error });
    }    
 } else {
    let _ = message_event.send(ProfilePicEvent::ResultProfilePic { r: ResultOp::Error });
 }
} else {
    let _ = message_event.send(ProfilePicEvent::ResultProfilePic { r: ResultOp::Error });
}

    Ok(())
}




#[derive(Serialize, Deserialize)]
pub enum ProfilePicEvent {
    ResultProfilePic { r: ResultOp }
}