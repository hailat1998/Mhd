use tauri::{AppHandle, ipc::Channel} ;
use time::OffsetDateTime;
use time::format_description::well_known::Rfc3339;
use super::ResultOp;
use serde::{Deserialize, Serialize};
use crate::app_state::NetState;
use crate::core::messages::server_messages::ResultHere;
use crate::utils::app_error::AppError;
use crate::core::messages::ServerMessage;
use tauri::Manager;
use tokio::sync::oneshot;
use crate::app_state::AppState;
use crate::core::messages::UserMessage;
use crate::core::messages::ComposeMessage;
use rand_core_compat::rand_core_0_6;
use rand_core_compat::rand_core_0_6::RngCore;

pub async fn delete(app: AppHandle, message_event: Channel<DeleteEvent>, id: i64, other_username: String) -> Result<(), AppError> {
 


 let state = app.try_state::<AppState>().unwrap(); 

 let username = state.username.borrow().clone();

 let mut rng = rand_core_0_6::OsRng;

 if state.net_state.borrow().clone() == NetState::Connected {

 let (tx, rx) = oneshot::channel::<ServerMessage>();

 let session_key = state.session_key.borrow().clone();

 let user_message = UserMessage::Delete { message_id: id, username: username, other_username: other_username, unique_key: session_key };

 let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx)).await;

 let server_message = rx.await;

 if let Ok(ServerMessage::DeleteReplay { message_id, result }) = server_message {
     if let ResultHere::Ok = result {

     let online = sqlx::query("DELETE FROM messages WHERE id = $1").bind(message_id.clone()).execute(state.pool.read().await.as_ref().unwrap()).await;
      if online.is_ok() {
    let _ = sqlx::query(
        "INSERT INTO deleted_messages (id, message_id, time) VALUES ($1, $2, $3)"
    )
    .bind(rng.next_u64() as i64)  
    .bind(message_id.clone())  
    .bind(OffsetDateTime::now_utc().format(&Rfc3339).unwrap())
    .execute(state.pool.read().await.as_ref().unwrap()).await;
      } else {
        let _ = sqlx::query("DELETE FROM unsent_messages WHERE id = $1").bind(message_id.clone()).execute(state.pool.read().await.as_ref().unwrap()).await;
      }  

     let _ = message_event.send(DeleteEvent::ResultDelete { r: ResultOp::Ok });
     } else {
      let _ = message_event.send(DeleteEvent::ResultDelete { r: ResultOp::Error });
     }
 }
} else {
    let _ = sqlx::query("DELETE FROM messages WHERE id = $1").bind(id).execute(state.pool.read().await.as_ref().unwrap()).await;
    let _ = sqlx::query(
        "INSERT INTO deleted_messages (id, message_id, time) VALUES ($1, $2, $3)"
    )
    .bind(rng.next_u64() as i64)  
    .bind(id.clone())  
    .bind(OffsetDateTime::now_utc().format(&Rfc3339).unwrap())
    .execute(state.pool.read().await.as_ref().unwrap()).await;

    let _ = message_event.send(DeleteEvent::ResultDelete { r: ResultOp::Ok });

}

    Ok(())
}


#[derive(Serialize, Deserialize)]
pub enum DeleteEvent {
    ResultDelete { r: ResultOp }
}