use tauri::async_runtime;
use tauri::{AppHandle, ipc::Channel} ;
use tokio::fs::File;
use tokio::sync::mpsc;
use super::ResultOp;
use serde::{Deserialize, Serialize};
use crate::utils::app_error::AppError;
use crate::utils::encryption_utils::bytes_to_base64;
use crate::utils::encryption_utils::encrypt_string;
use crate::utils::{hash_string, hash_url};
use tauri::Manager;
use directories::ProjectDirs;
use crate::app_state::AppState;
use crate::core::client::file::{delete_resource, download_file, upload_file};
use crate::utils::encryption_utils::generate_12_bytes;
use sqlx::Row;
use std::path::PathBuf;

pub async fn file(app: AppHandle, message_event: Channel<FileEvent>, arg: FileArg) -> Result<(), AppError> { 

 let state = app.try_state::<AppState>().unwrap();
  
  match arg {
    FileArg::Delete{ dest, file_name } => {
    let key = state.key.borrow().clone();
    let nonce = generate_12_bytes();   
    let unique_key_enc = encrypt_string(&key, &state.session_key.borrow().clone(), &nonce).unwrap();
    let end_point = format!("{}/{}/{}/{}", hash_string(&state.username.borrow().clone()), dest, file_name, bytes_to_base64(&nonce));
         
    let r =  delete_resource(
        &state.ob_store_url.clone(), 
        &end_point, 
        &unique_key_enc,
         &state.installation_id.borrow().clone()
        ).await;

        match r {
            Ok(()) => {let _ = message_event.send(FileEvent::Delete { r: ResultOp::Ok }); },
            Err(_) => {let _ = message_event.send(FileEvent::Delete { r: ResultOp::Error }); }
        }

    },
    FileArg::Download{ username, dest, file_name } => {
    let (tx, mut rx) = mpsc::channel::<f64>(100);
    let key = state.key.borrow().clone();
    let nonce = generate_12_bytes();   
    let unique_key_enc = encrypt_string(&key, &state.session_key.borrow().clone(), &nonce).unwrap();
    let end_point = format!("{}/{}/{}/{}", hash_string(&username), dest, file_name.clone(), bytes_to_base64(&nonce));
    let installation_id = state.installation_id.borrow().clone();
    let ob_url = state.ob_store_url.clone();

    let proj_dirs = ProjectDirs::from("com", "mako_frontend", "app")
        .expect("Could not determine project directories");

    let cache = PathBuf::from(proj_dirs.cache_dir());

    let id = hash_url(&end_point);

    let path = sqlx::query(
      "SELECT local_path FROM files WHERE id = ?"
    )
    .bind(id.clone())
    .fetch_optional(state.pool.read().await.as_ref().unwrap()).await.unwrap();

    if path.is_some() {
          let _ = message_event.send(FileEvent::LocalPath { path: path.as_ref().unwrap().get::<String, usize>(0).into() });
    } else {    
     let end_point_clone = end_point.clone();
   let download_task = async_runtime::spawn(async move {
       let path = download_file(
     &ob_url,
     &end_point_clone,
            &cache.to_str().unwrap(),
            &file_name,
          &unique_key_enc,
             &installation_id,
             tx
    ).await;

    path
   });

   tokio::select! {
    res = download_task => {
      let value = res.unwrap().unwrap();
     let _ = sqlx::query(
      "INSERT INTO files (id, url, local_path) VALUES ($1, $2, $3)"
    )
    .bind(id)
    .bind(end_point)
    .bind(value.to_str())
    .execute(state.pool.read().await.as_ref().unwrap()).await;

    let _ = message_event.send(FileEvent::LocalPath { path: value.to_string_lossy().to_string().into() });

    }
    _ = { async { 
     while let Some(p) = rx.recv().await {
     let _ = message_event.send(FileEvent::Download { progress: p, finished: false });
    }  
    let _ =  message_event.send(FileEvent::Download { progress: 100.0, finished: true }); 

     tokio::time::sleep(tokio::time::Duration::from_secs(2)).await;
  }
    } => {}
   } 

  }
    },
    FileArg::Upload {path, dest }=> {

    let (tx, mut rx) = mpsc::channel::<u64>(100);

    let key =  state.key.borrow().clone();

    let nonce = generate_12_bytes();   

    let unique_key_enc = encrypt_string(&key, &state.session_key.borrow().clone(), &nonce).unwrap();

    let file = match File::open(&path).await {
      Ok(f) => { f },
      Err(e) => { 
        let _ = message_event.send(FileEvent::Error { m: "Failed to Open".to_string() });
        return Err(AppError::Custom("Failed to Open".to_string() ));
      }
    };

    let file_name = path.file_name().unwrap().to_str().unwrap();

    let end_point = format!("{}/{}/{}/{}", hash_string(&state.username.borrow().clone()), dest, file_name, bytes_to_base64(&nonce));
   
    let installation_id = state.installation_id.borrow().clone();
    let ob_url = state.ob_store_url.clone();

     let upload_task = async_runtime::spawn(async move {
          let _ = upload_file(  
            &ob_url,
            &end_point,
            &path.to_str().unwrap(),
            &unique_key_enc,
            &installation_id.clone(),
            tx
             ).await;
     });

   
   let meta_data = file.metadata().await;

   let length = meta_data.unwrap().len();
   
   let progress_task = async_runtime::spawn(async move {
        if length > 0 {        
      while let Some(p) = rx.recv().await  {
        let _ = message_event.send(FileEvent::Upload { progress:(p as f64)/ (length as f64) * 100.0, finished: false });
      }
       let _ = message_event.send(FileEvent::Upload { progress:100.0, finished: true });
     }
     });

     let _ = upload_task.await;
     let _ = progress_task.await;
    }
  }

  Ok(())
}


#[derive(Serialize, Deserialize)]
pub enum FileEvent {
    Delete { r: ResultOp },
    Upload {
       progress: f64,
       finished: bool 
    },
    Download {
        progress: f64,
        finished: bool
    },
    LocalPath { path: PathBuf },
    Error { m: String }
}

#[derive(Serialize, Deserialize)]
pub enum FileArg {
    Upload { path: PathBuf, dest: String },
    Download{ username: String, dest: String, file_name: String},
    Delete { dest: String, file_name: String }
}