use tauri::{AppHandle, ipc::Channel} ;
use super::ResultOp;
use serde::{Deserialize, Serialize};
use crate::app_state::NetState;
use crate::utils::app_error::AppError;
use crate::core::messages::ServerMessage;
use tauri::Manager;
use tokio::sync::oneshot;
use crate::app_state::AppState;
use crate::core::messages::UserMessage;
use crate::core::messages::ComposeMessage;
use rand_core_compat::rand_core_0_6;
use rand_core_compat::rand_core_0_6::RngCore;


pub async fn profile(app: AppHandle, message_event: Channel<ProfileEvent>, other_username: String) -> Result<(), AppError> {
 
 let (tx, rx) = oneshot::channel::<ServerMessage>();

 let state = app.try_state::<AppState>().unwrap();

 let mut rng = rand_core_0_6::OsRng;

 if state.net_state.borrow().clone() == NetState::Connected {
 
 let user_message = UserMessage::Profile { username: state.username.borrow().clone(), other_username: other_username, unique_key: state.session_key.borrow().clone() };

 let (tx, rx) = oneshot::channel::<ServerMessage>();
 
 let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx)).await;

 let server_message = rx.await;

 if let Ok(ServerMessage::ProfileReplay { pics, username, name, last_seen }) = server_message {
   
    let profile_data = ProfileData {
        pics: pics,
        username: username,
        name: name,
        last_seen: last_seen
    };

    let _ = message_event.send(ProfileEvent::ResultProfile { r: ResultOp::Ok, data: Some(profile_data) });
 } else {
    let _ = message_event.send(ProfileEvent::ResultProfile { r: ResultOp::Error, data: None });
 } 
} else {
    let _ = message_event.send(ProfileEvent::ResultProfile { r: ResultOp::Error, data: None });
}

 Ok(())
} 




#[derive(Serialize, Deserialize)]
pub enum ProfileEvent {
    ResultProfile { r: ResultOp, data: Option<ProfileData>}
}

#[derive(Serialize, Deserialize)]
pub struct ProfileData {
    pub pics: Vec<String>, 
    pub username: String,
    pub name: String,
    pub last_seen: i64
}