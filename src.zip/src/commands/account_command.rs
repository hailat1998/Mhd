use crate::commands::ResultOp;
use crate::utils::app_error::AppError;
use tauri::Manager;
use tauri::{AppHandle, ipc::Channel};
use serde::{Deserialize, Serialize};
use crate::AppState;


use crate::Account;

pub async fn list_accounts_command(app: AppHandle, message_event: Channel<AccountListEvent>) -> Result<(), AppError> {
       
   let state = app.state::<AppState>();

   let accounts = sqlx::query_as!(
    Account, 
    r#"SELECT * FROM account"#
   ).fetch_all(state.account_pool.read().await.as_ref().unwrap()).await.unwrap();

   let accounts_list = accounts.into_iter().map(|a| AccountUser::new(a.name.clone(), a.username.clone(), a.is_active.clone())).collect();

   let _ = message_event.send(AccountListEvent::ResultAccountList { r: ResultOp::Ok, m: accounts_list });

   Ok(())
} 

pub async fn switch_account_command(app: AppHandle, username: String,  message_event: Channel<AccountSwitchEvent>) -> Result<(), AppError> {
    
    
    let state = app.state::<AppState>();

    let mut tx = state.account_pool.read().await.as_ref().unwrap().begin().await?;

    let current_username = state.username.borrow().clone();

    let _ = sqlx::query!(
        r#"UPDATE account SET is_active = $1 WHERE username = $2"#,
        false,
        current_username
    ).execute(&mut *tx).await;
  

    let _ = sqlx::query!(
        r#"UPDATE account SET is_active = $1 WHERE username = $2"#,
        true,
        username
    ).execute(&mut *tx).await;
      
    match tx.commit().await {
        Ok(_) => {
         let _ = message_event.send(AccountSwitchEvent::ResultAccountSwitch { r: ResultOp::Ok });
         app.restart();
        },
        Err(_) => {
        let _ = message_event.send(AccountSwitchEvent::ResultAccountSwitch { r: ResultOp::Error });
        return Err(AppError::Custom("Failed to switch user".to_string()));
        }
    }
}


#[derive(Serialize, Deserialize)]
pub enum AccountListEvent {
    ResultAccountList { r: ResultOp, m: Vec<AccountUser>}
}


#[derive(Serialize, Deserialize)]
pub enum AccountSwitchEvent {
    ResultAccountSwitch { r: ResultOp }
}

#[derive(Serialize, Deserialize)]
pub struct AccountUser {
    pub name: String,
    pub username: String,
    pub is_active: bool
}

impl AccountUser {
    pub fn new(name: String, username: String, is_active: bool) -> Self {
        Self { name, username, is_active }
    }
}
