use crate::commands::ResultOp;
use crate::core::client::CreateUser;
use crate::core::client::LoginUser;
use crate::core::client::auth::login;
use crate::core::client::auth::signup;
use crate::core::database::connection::create_conn;
use crate::core::messages::UserMessage;
use crate::core::messages::server_messages::ResultHere;
use crate::utils::app_error::AppError;
use crate::utils::device_id;
use crate::utils::encryption_utils::base64_to_array;
use crate::utils::encryption_utils::bytes_to_base64;
use crate::utils::hash_string;
use crate::utils::load_settings;
use crate::utils::save_settings;
use tauri::Manager;
use crate::ComposeMessage;
use tauri::{AppHandle, ipc::Channel};
use x25519_dalek::PublicKey;
use x25519_dalek::StaticSecret;
use crate::app_state::AppState;
use time::OffsetDateTime;
use time::format_description::well_known::Rfc3339;
use serde::{Deserialize, Serialize};
use rand_core_compat::rand_core_0_6::{self, RngCore};
use aes_gcm::aead::OsRng;
use tokio::sync::oneshot;
use crate::ServerMessage;
use std::fs;
use std::path::PathBuf;
use crate::utils::get_db_path;


pub async fn login_command(app: AppHandle, username: String, password: String, private_key_base64: String, message_event: Channel<AuthEvent>) -> Result<(), AppError> {

    let device_id = device_id::get_device_name().unwrap();

    let state = app.try_state::<AppState>().unwrap();   

    let user_login = LoginUser {
       username: username.clone(),
       password: password.clone(),
       device_id: device_id.clone()
    };

    let res = login(&user_login).await;

   match res {
    Ok(r) => {

        let hash_username = hash_string(&username);

        let path = get_db_path(&hash_username);

      if let Ok(db) = create_conn(&path.to_string_lossy()).await {

        let mut settings = load_settings(&app);

        settings.user_hash = hash_username;

        save_settings(&app, &settings);       

     //   let _ = init_db::init_db(&db).await; 

        { 
       
        let mut q = state.pool.write().await;

        state.pool.write().await.as_mut().unwrap().close().await;

        *q = Some(db);  
        }

        let _ = sqlx::migrate!("./migrations")
        .run(state.pool.read().await.as_ref().unwrap())
        .await;
        
        let rng = rand_core_0_6::OsRng.next_u64() as i64; 

        let bytes_result =base64_to_array::<32>(&private_key_base64);   

       let bytes = match bytes_result {
        Ok(b) => { b },
        Err(_) => {
          return Err(AppError::Custom("Wrong private key".to_string()));
        } 
       };

        let secret = StaticSecret::from(bytes);

        let key = secret.as_bytes().clone();

        let public_key = PublicKey::from(&secret).as_bytes().clone();      

        { 
        
        let _ = state.public_key_sender.send_replace(bytes_to_base64(&public_key));        

        let _ = state.private_key_sender.send_replace(key.clone());      

        }

        let t = OffsetDateTime::now_utc().format(&Rfc3339).unwrap();
        let n = r.name.clone();
        let b = r.base_64_string.clone();
        let i = r.installation_id.clone();
        let u = username.clone();
        let pa = password.clone();
        let de = device_id.clone();

        let p = bytes_to_base64(&public_key);

        let pr = bytes_to_base64(&key);

        let _ = sqlx::query!(r#"DELETE FROM account"#).execute(state.pool.read().await.as_ref().unwrap()).await;
       
        let _ = sqlx::query!(
            r#"
         INSERT OR REPLACE INTO account (id, username, name, pub_key, private_key, installation_id, last_key, last_seen, device_name, password, is_active)
         VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
         "#,
         rng,
         u,
         n,
         p,
         pr,
         i,
         b,
         t,
         de,
         pa,
         true
        )
        .execute(state.account_pool.read().await.as_ref().unwrap()).await;

        let  _ = state.installation_id_sender.send_replace(r.installation_id.clone());
       
        let  _ = state.key_sender.send_replace(base64_to_array(&r.base_64_string).unwrap()); 
       
        let _ = state.username_sender.send_replace(username.clone());       
        
        let _ = message_event.send(AuthEvent::ResultAuth { r: ResultOp::Ok, m: "".to_string() });
    }
    },
    Err(e) => {
       let _ = message_event.send(AuthEvent::ResultAuth { r: ResultOp::Error, m: e.to_string() });
    }
   }

   Ok(())  
}


pub async fn signup_command(app: AppHandle, username: String, password: String, name: String, message_event: Channel<AuthEvent>) -> Result<(), AppError> {

     let device_id = device_id::get_device_name().unwrap();

     let secret = StaticSecret::random_from_rng(OsRng);

     let key = secret.as_bytes().clone();

     let public_key = PublicKey::from(&secret).as_bytes().clone();

     let private_key = secret.as_bytes();

     let state = app.try_state::<AppState>().unwrap();
    
     let create_user = CreateUser {
         username: username.clone(),
         password: password.clone(),
         pub_key: bytes_to_base64(&public_key),
         name: name,
         device_id: device_id.clone()
        };

     let res = signup(&create_user).await;

     match res {
        Ok(r) => {

      let hash_username = hash_string(&username);

      let path = get_db_path(&hash_username);

      if let Ok(db) = create_conn(&path.to_string_lossy()).await {

        let mut settings = load_settings(&app);

        settings.user_hash = hash_username;

        save_settings(&app, &settings); 

       // let _ = init_db::init_db(&db).await; 

        let rng = rand_core_0_6::OsRng.next_u64() as i64; 

        { 

        let mut q = state.pool.write().await;

        state.pool.write().await.as_mut().unwrap().close().await;

        *q = Some(db);  
        }

        let _ = sqlx::migrate!("./migrations")
        .run(state.pool.read().await.as_ref().unwrap())
        .await;        
        
       let _ = state.public_key_sender.send_replace(bytes_to_base64(&public_key)); 
       let _ = state.private_key_sender.send_replace(key.clone());           

        let t = OffsetDateTime::now_utc().format(&Rfc3339).unwrap();
        let n = r.name.clone();
        let b = r.base_64_string.clone();
        let i = r.installation_id.clone();
        let u = username.clone();
        let pa = password.clone();
        let de = device_id.clone();

        let p = bytes_to_base64(&public_key);

        let pr = bytes_to_base64(private_key.as_slice());

        let _ = sqlx::query!(r#"DELETE FROM account"#).execute(state.pool.read().await.as_ref().unwrap()).await;
       
        let _ = sqlx::query!(
            r#"
         INSERT OR REPLACE INTO account (id, username, name, pub_key, private_key, installation_id, last_key, last_seen, device_name, password)
         VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
         "#,
         rng,
         u,
         n,
         p,
         pr,
         i,
         b,
         t,
         de,
         pa
        )
        .execute(state.account_pool.read().await.as_ref().unwrap()).await;

        let _ = state.installation_id_sender.send_replace(r.installation_id.clone());
       
        let _ = state.key_sender.send_replace(base64_to_array(&r.base_64_string).unwrap()); 
       
        let  _ = state.username_sender.send_replace(username.clone());   
        

        let _ = message_event.send(AuthEvent::ResultAuth { r: ResultOp::Ok, m: "".to_string() });
         }
        },
        Err(e) => {

        let _ = message_event.send(AuthEvent::ResultAuth { r: ResultOp::Error, m: e.to_string() });
         
        }
     }

     Ok(()) 
}


pub async fn logout_command(app: AppHandle, message_event: Channel<AuthEvent>) -> Result<(), AppError> {
   
    let state = app.try_state::<AppState>().unwrap();

    let username = state.username.borrow().clone();

    let (tx, rx) = oneshot::channel::<ServerMessage>();

    let mut rng = rand_core_0_6::OsRng;

    let user_message = UserMessage::Logout { username:  state.username.borrow().clone(), unique_key: state.session_key.borrow().clone() };

    let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx)).await;

    let server_message = rx.await;

    if let Ok(ServerMessage::LogoutReplay { result }) = server_message {
      if let ResultHere::Ok = result {   

      let _ = sqlx::query!(
         r#"UPDATE account SET private_key = '' WHERE username = $1"#,
         username
      ).execute(state.pool.read().await.as_ref().unwrap()).await ;

      let _ = message_event.send(AuthEvent::ResultAuth { r: ResultOp::Ok, m: "".to_string() });
      } else {
      let _ = message_event.send(AuthEvent::ResultAuth { r: ResultOp::Error, m: "".to_string() });
      }     
    } else {
      let _ = message_event.send(AuthEvent::ResultAuth { r: ResultOp::Error, m: "".to_string() });
    }
    Ok(())
}

pub async fn delete_account_command(app: AppHandle, message_event: Channel<AuthEvent>) -> Result<(), AppError> {
  
    let state = app.try_state::<AppState>().unwrap();

    let (tx, rx) = oneshot::channel::<ServerMessage>();

    let mut rng = rand_core_0_6::OsRng;

    let user_message = UserMessage::DeleteAccount  { username: state.username.borrow().clone(), unique_key: state.session_key.borrow().clone() };

    let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx)).await;

    let server_message = rx.await;

    if let Ok(ServerMessage::DeleteAccountReplay { result }) = server_message {
      if let ResultHere::Ok = result {
       
      state.pool.write().await.as_mut().unwrap().close().await;

      let db_path: PathBuf = get_db_path(&hash_string(&state.username.borrow().clone()));

      let mut q = state.pool.write().await;

        *q = None; 

      if db_path.exists() {
         fs::remove_file(&db_path)?;         
      }
      let _ = message_event.send(AuthEvent::ResultAuth { r: ResultOp::Ok, m: "".to_string() });
      } else {
      let _ = message_event.send(AuthEvent::ResultAuth { r: ResultOp::Error, m: "".to_string() });
      }     
    } else {
      let _ = message_event.send(AuthEvent::ResultAuth { r: ResultOp::Error, m: "".to_string() });
    }

    Ok(())
}

#[derive(Serialize, Deserialize)]
pub enum AuthEvent {
    ResultAuth { r: ResultOp, m: String}
}





