use tauri::{AppHandle, ipc::Channel} ;
use x25519_dalek::PublicKey;
use x25519_dalek::StaticSecret;
use super::ResultOp;
use serde::{Deserialize, Serialize};
use crate::utils::app_error::AppError;
use crate::utils::encryption_utils::base64_to_array;
use crate::utils::encryption_utils::bytes_to_base64;
use tauri::Manager;
use crate::app_state::AppState;




pub async fn get_key(app: AppHandle, message_event: Channel<KeyEvent>) -> Result<(), AppError> {
   
   let state = app.try_state::<AppState>().unwrap();

   let key = state.private_key.borrow().clone();

   let _ = message_event.send(KeyEvent::Key { key: bytes_to_base64(&key) });

   Ok(())
}

pub async fn restore_key(app: AppHandle, message_event: Channel<KeyEvent>, key_base64: String) -> Result<(), AppError> {

    let state = app.try_state::<AppState>().unwrap();

    let secret = match base64_to_array(&key_base64) {
        Ok(v) => { v },
        Err(_) => { 
           let _ = message_event.send(KeyEvent::ResultKey { r: ResultOp::Error });
            return Err(AppError::Custom("Invalid input!".to_string()));
        }
    };

    if secret.len() != 32 {
       let _ = message_event.send(KeyEvent::ResultKey { r: ResultOp::Error });
       return Err(AppError::Custom("Invalid input!".to_string()));
    }

    let static_secret = StaticSecret::from(secret);

    let public = bytes_to_base64(PublicKey::from(&static_secret).as_bytes());
        
    let mut private_key = state.private_key_sender.send_replace(secret.clone());

    let mut public_key = state.public_key_sender.send_replace(public.clone());
    
    let _ = sqlx::query("UPDATE account SET private_key = $1 , pub_key = $1 WHERE username = $3")
        .bind(key_base64)
        .bind(public)
        .bind(state.username.borrow().clone())
        .execute(state.pool.read().await.as_ref().unwrap()).await;

    let _ = message_event.send(KeyEvent::ResultKey { r: ResultOp::Ok });

    Ok(())
}

#[derive(Serialize, Deserialize)]
pub enum KeyEvent {
    ResultKey { r: ResultOp },
    Key { key: String }
}
