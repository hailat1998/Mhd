use tauri::{ ipc::Channel, AppHandle};
use serde::{Deserialize, Serialize};
use crate::core::messages::server_messages::ResultHere;
use crate::core::model::message::{Message, UnsentLocalMessage};
use crate::utils::app_error::AppError;
use crate::core::messages::{ComposeMessage, ServerMessage, UserMessage};
use crate::commands::ui_data::MessageUI;
use crate::utils::mapper::{message_ui_to_message, message_ui_to_sent_message};
use super::ResultOp;
use crate::app_state::{AppState, NetState};
use tokio::sync::oneshot;
use tauri::Manager;
use rand_core_compat::{ rand_core_0_6};
use rand_core_compat::rand_core_0_6::RngCore;


pub async fn send(app: AppHandle, message_event: Channel<SendEvent>, message_ui: MessageUI) -> Result<(), AppError> {


 let state = app.try_state::<AppState>().unwrap();

 let message = message_ui_to_message(&message_ui).await;

 let mut rng = rand_core_0_6::OsRng;

 let username = state.username.borrow().clone();

 let session_key = state.session_key.borrow().clone();

 let sent_message = message_ui_to_sent_message(&message_ui, &state).await;

 if state.net_state.borrow().clone() == NetState::Connected {

 let (tx, rx) = oneshot::channel::<ServerMessage>();

 let user_message = UserMessage::Send { message: message, sent_message: sent_message.clone(), username: username.clone(), unique_key: session_key.clone() };

 let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx)).await;

 let server_message = rx.await;

 if let Ok(ServerMessage::SendReplay { message, sent_message, result }) = server_message {
     if let ResultHere::Ok = result {

      let sent_message = sent_message.unwrap();
     
       sqlx::query(
          r#"INSERT INTO messages (id, payload, caption, recipient, sender, seen, pub_key, locale, created_at, updated_at)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)"#         
        )
        .bind(&message.id)
        .bind(&message.payload)
        .bind(&message.attachment_name)
        .bind(&message.attachment_type)
        .bind(&message.caption)
        .bind(&message.recipient)
        .bind(&message.sender)
        .bind(&message.seen)
        .bind(&message.pub_key)
        .bind(&message.locale)
        .bind(&message.created_at)
        .bind(&message.updated_at)
        .bind(&message.deleted_at)
        .execute(state.pool.read().await.as_ref().unwrap()).await?;

        let mut rng = rand_core_0_6::OsRng;        
             
        let _ = sqlx::query(
          "INSERT INTO sent_user_messages (id, message_id, payload, attachment_name, attachment_type, caption)
          VALUES ($1, $2, $3, $4, $5, $6)"
        )
        .bind(rng.next_u64() as i64)
        .bind(message.id.unwrap())
        .bind(sent_message.payload)
        .bind(sent_message.attachment_name)
        .bind(sent_message.attachment_type)
        .bind(sent_message.caption)
        .execute(state.pool.read().await.as_ref().unwrap()).await;
       
       let _ = message_event.send(SendEvent::ResultSend { r: ResultOp::Ok, id: message.id });
        
     } else {
               let _ = message_event.send(SendEvent::ResultSend { r: ResultOp::Error, id: None });
     }
 }
 } else {

    let mess = message.clone();

    let unsent_local_message: Message = sqlx::query_as!(
           Message,
          r#"INSERT INTO unsent_messages (payload, attachment_name, attachment_type, caption, recipient, sender, seen, pub_key, locale, created_at, updated_at)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
            RETURNING id, payload, attachment_name, attachment_type, caption, recipient, sender, seen, pub_key, locale, created_at, updated_at, deleted_at"#,
            mess.payload,
            mess.attachment_name,
            mess.attachment_type,
            mess.caption,
            mess.recipient,
            mess.sender,
            mess.seen,
            mess.pub_key,
            mess.locale,
            mess.created_at,
            mess.updated_at
        )
        .fetch_one(state.pool.read().await.as_ref().unwrap()).await?;     

       let _ = sqlx::query(
        "INSER INTO unsent_user_messages (message_id, payload, caption, attachment_name, attachment_type)
        VALUES ($1, $2, $3, $4, $5)")
        .bind(unsent_local_message.id.unwrap())
        .bind(sent_message.payload)
        .bind(sent_message.caption)
        .bind(sent_message.attachment_name)
        .bind(sent_message.attachment_type)
        .execute(state.pool.read().await.as_ref().unwrap()).await;

       let _ = message_event.send(SendEvent::ResultSend { r: ResultOp::Ok, id: None });
 }

  Ok(())
}

#[derive(Serialize, Deserialize)]
pub enum SendEvent {   
   ResultSend {r: ResultOp, id: Option<i64>}
}