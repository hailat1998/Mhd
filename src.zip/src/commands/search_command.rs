use tauri::{AppHandle, ipc::Channel} ;
use super::ResultOp;
use serde::{Deserialize, Serialize};
use crate::app_state::NetState;
use crate::commands::ui_data::MessageUI;
use crate::core::messages::user_messages::SearchKind;
use crate::utils::app_error::AppError;
use crate::core::messages::ServerMessage;
use tauri::Manager;
use tokio::sync::oneshot;
use crate::app_state::AppState;
use crate::core::messages::UserMessage;
use crate::core::messages::ComposeMessage;
use crate::core::messages::server_messages::UserSearch;
use rand_core_compat::rand_core_0_6;
use rand_core_compat::rand_core_0_6::RngCore;
use crate::core::messages::server_messages::ResultHere;
use crate::core::model::message::SentMessage;
use crate::utils::mapper::{message_to_message_ui_owned, message_to_message_ui_unowned};

pub async fn search(app: AppHandle, message_event: Channel<SearchEvent>, search_term: SearchKind, page: i32) -> Result<(), AppError> {

  let _ = message_event.send(SearchEvent::Searching);

  let mut rng = rand_core_0_6::OsRng;

  let state = app.try_state::<AppState>().unwrap();

  let username = state.username.borrow().clone();

  let session_key = state.session_key.borrow().clone();

  if state.net_state.borrow().clone() == NetState::Connected {  

  let (tx, rx) = oneshot::channel::<ServerMessage>();

  match search_term {
    SearchKind::OtherUser { key_term } => {

    let search_kind = SearchKind::OtherUser { key_term: key_term };   

    let user_message = UserMessage::Search { search_kind: search_kind, username: username.clone(), unique_key: session_key.clone(), page: 1 };

    let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx)).await;

    let server_message = rx.await;

    if let Ok(ServerMessage::SearchReplay { result }) = server_message {
      
      let _ = message_event.send(SearchEvent::ResultSearch { r: ResultOp::Ok, data: SearchData::Users { users:  result.users } });
        
    }

    },

    SearchKind::MessageSet { key_term } => {
    
    let search_kind = SearchKind::MessageSet { key_term: key_term.clone() };   

    let user_message = UserMessage::Search { search_kind: search_kind, username: username.clone(), unique_key: session_key.clone(), page: page };

    let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx)).await;

    let server_message = rx.await;

    if let Ok(ServerMessage::SearchReplay { result }) = server_message {
        let mut message_uis = vec![];

        for m in &result.messages {

       if m.sender == username.clone() {
        
          let id = m.id.unwrap();

          let id_c = m.id.unwrap();

         let sent_message_local: Option<SentMessage> = sqlx::query_as!(
            SentMessage,
            r#"SELECT * FROM sent_user_messages WHERE message_id = $1"#,
             id_c
             )            
            .fetch_optional(state.pool.read().await.as_ref().unwrap()).await.unwrap();

          if sent_message_local.is_none() {
            let (tx, rx) = oneshot::channel::<ServerMessage>();

            let user_message = UserMessage::SentMessage { message_id: id.clone(), username: username.clone(), unique_key: session_key.clone() };

            let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx)).await;

            let server_message = rx.await;

           if let Ok(ServerMessage::SentMessageReplay { result, sent_message }) = server_message {
            if let ResultHere::Ok = result {
              let sent_message = sent_message.unwrap();
              let there_is_att = sent_message.attachment_name.is_some();
              let there_is_cap = sent_message.caption.is_some();

              let _ = sqlx::query(
              "INSERT INTO sent_messages (id, message_id, payload, attachment_name, attachment_type, caption)
              VALUES ($1, $2, $3, $4, $5, $6)"
            )
            .bind(rng.next_u64() as i64)
            .bind(id.clone())
            .bind(sent_message.payload.clone())
            .bind(sent_message.attachment_name.clone())
            .bind(sent_message.attachment_type.clone())
            .bind(sent_message.caption.clone())
            .execute(state.pool.read().await.as_ref().unwrap()).await;


              message_uis.push(message_to_message_ui_owned(m, &sent_message, &state).await);

            }
          }
        }
        } else {
           message_uis.push(message_to_message_ui_unowned(m, &state).await);
        }  
        }
         let _ = message_event.send(SearchEvent::ResultSearch { r: ResultOp::Ok, data: SearchData::Messages { messages: message_uis } });
     }
    }

  }
  } else {
    let _ = message_event.send(SearchEvent::ResultSearch { r: ResultOp::Error, data: SearchData::Empty });
  }

    Ok(())
}

#[derive(Serialize, Deserialize)]
pub enum SearchEvent {
    ResultSearch { r: ResultOp, data: SearchData },
    Searching
}

#[derive(Serialize, Deserialize)]
pub enum SearchData {
    Messages { messages: Vec<MessageUI> },
    Users { users: Vec<UserSearch>},
    Empty
} 
