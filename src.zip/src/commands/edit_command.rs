use tauri::{AppHandle, ipc::Channel} ;
use super::ResultOp;
use serde::{Deserialize, Serialize};
use crate::app_state::NetState;
use crate::commands::ui_data::MessageUI;
use crate::core::messages::server_messages::ResultHere;
use crate::utils::app_error::AppError;
use crate::core::messages::ServerMessage;
use tauri::Manager;
use tokio::sync::oneshot;
use crate::app_state::AppState;
use crate::core::messages::UserMessage;
use crate::core::messages::ComposeMessage;
use crate::utils::mapper::{ message_ui_to_sent_message, message_ui_to_message};
use rand_core_compat::{ rand_core_0_6};
use rand_core_compat::rand_core_0_6::RngCore;
use crate::core::model::message::SentMessage;



pub async fn edit(app: AppHandle, message_event: Channel<EditEvent>, message_ui: MessageUI) ->  Result<(), AppError> {
 

 let state = app.try_state::<AppState>().unwrap();

 let message = message_ui_to_message(&message_ui).await;

 let mut sent_message =message_ui_to_sent_message(&message_ui, &state).await;

 let mut rng = rand_core_0_6::OsRng;

 if state.net_state.borrow().clone() == NetState::Connected { 

 let username = state.username.borrow().clone();

 let session_key = state.session_key.borrow().clone();

 let (tx, rx) = oneshot::channel::<ServerMessage>();

 let user_message = UserMessage::Edit { message: message, username: username.clone(), unique_key: session_key.clone() };

 let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx)).await;

 let server_message = rx.await;

 if let Ok(ServerMessage::EditReplay { message, result }) = server_message {
  if let ResultHere::Ok = result { 

       sqlx::query(
          r#"INSERT INTO messages (id, payload, attachment_name, attachment_type, caption, recipient, sender, seen, pub_key, locale, created_at, updated_at)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)"#         
        )
        .bind(&message.id)
        .bind(&message.payload)
        .bind(&message.attachment_name)
        .bind(&message.attachment_type)
        .bind(&message.caption)
        .bind(&message.recipient)
        .bind(&message.sender)
        .bind(&message.seen)
        .bind(&message.pub_key)
        .bind(&message.locale)
        .bind(&message.created_at)
        .bind(&message.updated_at)
        .bind(&message.deleted_at)
        .execute(state.pool.read().await.as_ref().unwrap()).await?;
        

        let id = message.id.unwrap();

         let mut sent_message_local: Option<SentMessage> = sqlx::query_as!(
            SentMessage,
            r#"SELECT * FROM sent_user_messages WHERE message_id = $1"#,
            id
        )            
            .fetch_optional(state.pool.read().await.as_ref().unwrap()).await.unwrap();

        
          if sent_message_local.is_none() {

            let (tx, rx) = oneshot::channel::<ServerMessage>();

            let user_message = UserMessage::SentMessage { message_id: id.clone(), username: username.clone(), unique_key: session_key.clone() };

            let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message, tracker: rng.next_u64()}, tx)).await;

            let server_message = rx.await;

            if let Ok(ServerMessage::SentMessageReplay { result, sent_message }) = server_message {
                 if let ResultHere::Ok = result {
                   sent_message_local = sent_message;
                 }
              }
           }

        let _ = sqlx::query(
          "INSERT INTO sent_user_messages (id, message_id, payload, attachment_name, attachment_type, caption)
          VALUES ($1, $2, $3, $4, $5, $6)"
        )
        .bind(sent_message_local.as_ref().unwrap().id)
        .bind(message.id)
        .bind(sent_message.payload.clone())
        .bind(sent_message.attachment_name.clone())
        .bind(sent_message.attachment_type.clone())
        .bind(sent_message.caption.clone())
        .execute(state.pool.read().await.as_ref().unwrap()).await;

        sent_message.id = sent_message_local.as_ref().unwrap().id;
        sent_message.message_id = message.id.unwrap();

         let (tx, rx) = oneshot::channel::<ServerMessage>();

         let user_message = UserMessage::SentMessageData { sent_message: sent_message, username: username.clone(), unique_key: session_key.clone() };

         let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx));
       
       let _ = message_event.send(EditEvent::ResultEdit { r: ResultOp::Ok });
        
     } else {
               let _ = message_event.send(EditEvent::ResultEdit { r: ResultOp::Error  });
     }  

 }
} else {

    sqlx::query(
          r#"INSERT INTO unsent_messages (payload, caption, attachment_name, attachment_type, recipient, sender, seen, pub_key, locale, created_at, updated_at)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)"#         
        )
        .bind(&message.payload)
        .bind(&message.attachment_name)
        .bind(&message.attachment_type)
        .bind(&message.caption)
        .bind(&message.recipient)
        .bind(&message.sender)
        .bind(&message.seen)
        .bind(&message.pub_key)
        .bind(&message.locale)
        .bind(&message.created_at)
        .bind(&message.updated_at)
        .bind(&message.deleted_at)
        .execute(state.pool.read().await.as_ref().unwrap()).await?;

     
       let _ = message_event.send(EditEvent::ResultEdit { r: ResultOp::Ok });
}

 Ok(())
}


#[derive(Serialize, Deserialize)]
pub enum EditEvent {
    ResultEdit { r: ResultOp }
}