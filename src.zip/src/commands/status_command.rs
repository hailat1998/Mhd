use tauri::{AppHandle, ipc::Channel} ;
use super::ResultOp;
use serde::{Deserialize, Serialize};
use crate::app_state::NetState;
use crate::utils::app_error::AppError;
use crate::core::messages::ServerMessage;
use tauri::Manager;
use tokio::sync::oneshot;
use crate::app_state::AppState;
use crate::core::messages::UserMessage;
use crate::core::messages::ComposeMessage;
use crate::core::messages::server_messages::StatusNow;
use rand_core_compat::rand_core_0_6;
use rand_core_compat::rand_core_0_6::RngCore;

pub async fn status(app: AppHandle, message_event: Channel<StatusEvent>, other_username: String) -> Result<(), AppError> {


 let state = app.try_state::<AppState>().unwrap(); 

 let mut rng = rand_core_0_6::OsRng;

 if state.net_state.borrow().clone() == NetState::Connected {

 let (tx, rx) = oneshot::channel::<ServerMessage>();

 let user_message = UserMessage::Status { username: state.username.borrow().clone(), other_username: other_username, unique_key: state.session_key.borrow().clone() };

 let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx)).await;

 let server_message = rx.await;

 if let Ok(ServerMessage::StatusReplay { name, username, status, pub_key }) = server_message {
    let _ = message_event.send(StatusEvent::ResultStatus { r: ResultOp::Ok, data: Some(StatusData{ status, name: name, username: username, pub_key: pub_key })});
 } else {

 }
} else {
    let _ = message_event.send(StatusEvent::ResultStatus { r: ResultOp::Error, data: None });
}

  Ok(())
} 

#[derive(Serialize, Deserialize)]
pub enum StatusEvent {
    ResultStatus { r: ResultOp,  data: Option<StatusData> }
}


#[derive(Serialize, Deserialize)]
pub struct StatusData {
    pub status: StatusNow,
    pub name: String,
    pub username: String,
    pub pub_key: String
}


