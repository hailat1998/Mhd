use time::{Duration, OffsetDateTime};

use crate::commands::ui_data::MessageUI;
use crate::core::messages::server_messages::ResultHere;
use crate::core::model::FileType;
use crate::core::model::message::{Attachment, Message};
use crate::utils::mapper::{message_to_message_ui_owned, message_to_message_ui_unowned, message_ui_to_message};
use crate::{commands::ResultOp, utils::app_error::AppError};

use tauri::{AppHandle, ipc::Channel} ;
use serde::{Deserialize, Serialize, ser};
use crate::core::messages::ServerMessage;
use tauri::Manager;
use tokio::sync::oneshot;
use crate::app_state::AppState;
use crate::core::messages::UserMessage;
use crate::core::messages::ComposeMessage;
use rand_core_compat::rand_core_0_6;
use rand_core_compat::rand_core_0_6::RngCore;
use time::format_description::well_known::Rfc3339;
use crate::core::model::message::LocalMessage;
use crate::core::model::message::SentMessage;


pub async fn new_message(app: AppHandle, page: i64, message_event: Channel<NextMessageEvent>) -> Result<(), AppError>  {
   
   let starting_from = OffsetDateTime::now_utc().saturating_sub(Duration::hours(3 * page * 30));

   let formatted = starting_from.format(&Rfc3339).unwrap();

   let state = app.try_state::<AppState>().unwrap();

   let mut rng = rand_core_0_6::OsRng;
   
   let local_messages: Vec<Message> = sqlx::query_as!(
    Message, 
    r#"SELECT * FROM messages WHERE created_at > $1"#,
    formatted
   ).fetch_all(state.pool.read().await.as_ref().unwrap()).await?;
    

   let mut messages_ui = vec![];

   let username = state.username.borrow().clone();
   let session_key = state.session_key.borrow().clone();

   for m in &local_messages {    

      if m.sender == username.clone() {
        
          let id = m.id.clone();

          let id_c = m.id.clone();

         let sent_message_local: Option<SentMessage> = sqlx::query_as!(
            SentMessage,
            r#"SELECT * FROM sent_user_messages WHERE message_id = $1"#,
             id_c
             )            
            .fetch_optional(state.pool.read().await.as_ref().unwrap()).await.unwrap();

          if sent_message_local.is_none() {
            let (tx, rx) = oneshot::channel::<ServerMessage>();

            let user_message = UserMessage::SentMessage { message_id: id.unwrap().clone(), username: username.clone(), unique_key: session_key.clone() };

            let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx)).await;

            let server_message = rx.await;

           if let Ok(ServerMessage::SentMessageReplay { result, sent_message }) = server_message {
            if let ResultHere::Ok = result {
              let sent_message = sent_message.unwrap();
              let there_is_att = sent_message.attachment_name.is_some();
              let there_is_cap = sent_message.caption.is_some();

              let _ = sqlx::query(
              "INSERT INTO sent_messages (id, message_id, payload, attachment_name, attachment_type, caption)
              VALUES ($1, $2, $3, $4, $5, $6)"
             )
            .bind(rng.next_u64() as i64)
            .bind(id.clone())
            .bind(sent_message.payload.clone())
            .bind(sent_message.attachment_name.clone())
            .bind(sent_message.attachment_type.clone())
            .bind(sent_message.caption.clone())
            .execute(state.pool.read().await.as_ref().unwrap()).await;

              messages_ui.push(message_to_message_ui_owned(&m, &sent_message, &state).await);

            }
          }
        } else {

         let sent_message = sent_message_local.unwrap();


              messages_ui.push(message_to_message_ui_owned(&m, &sent_message, &state).await);
        }
        } else {
           let message_ui = message_to_message_ui_unowned(m, &state).await;
           messages_ui.push(message_ui);
        }
   }

   let _ = message_event.send(NextMessageEvent::Get { r: ResultOp::Ok, messages: messages_ui });

   Ok(())
}


pub async fn next_messages(app: AppHandle, message_event: Channel<NextMessageEvent>, starting_from: OffsetDateTime) -> Result<(), AppError> {

 let (tx, rx) = oneshot::channel::<ServerMessage>();

 let state = app.try_state::<AppState>().unwrap();

 let mut rng = rand_core_0_6::OsRng;

 let username = state.username.borrow().clone();

 let session_key = state.session_key.borrow().clone();
 
 let user_message = UserMessage::NextMessages { starting_from: starting_from, username: username.clone(), unique_key: session_key.clone() };

 let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx)).await;

 let server_message = rx.await;

 if let Ok(ServerMessage::NextMessagesReplay { messages }) = server_message {
  
   let mut rng = rand_core_0_6::OsRng;

   let mut messages_ui = vec![];   

   for m in &messages {
       let _ = sqlx::query("INSERT OR REPLACE INTO messages (id, payload, attachment_name, attachment_type, caption, recipient, sender, seen, pub_key, locale, created_at, updated_at, deleted_at) 
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)")
        .bind(m.id)
        .bind(&m.payload)
        .bind(&m.attachment_name)
        .bind(&m.attachment_type)
        .bind(&m.caption)
        .bind(&m.recipient)
        .bind(&m.sender)
        .bind(&m.seen)
        .bind(&m.pub_key)
        .bind(&m.locale)
        .bind(m.created_at.format(&Rfc3339).unwrap())
        .bind(m.updated_at.format(&Rfc3339).unwrap())
        .bind(match m.deleted_at {
          Some(v) => { Some(v.format(&Rfc3339).unwrap()) },
          _ => None
        }).execute(state.pool.read().await.as_ref().unwrap()).await;
      

        if m.sender == username.clone() {
        
          let id = m.id.unwrap();

          let id_c = m.id.unwrap();

         let sent_message_local: Option<SentMessage> = sqlx::query_as!(
            SentMessage,
            r#"SELECT * FROM sent_user_messages WHERE message_id = $1"#,
             id_c
             )            
            .fetch_optional(state.pool.read().await.as_ref().unwrap()).await.unwrap();

          if sent_message_local.is_none() {
            let (tx, rx) = oneshot::channel::<ServerMessage>();

            let user_message = UserMessage::SentMessage { message_id: id.clone(), username: username.clone(), unique_key: session_key.clone() };

            let _ = state.request_sender.send((ComposeMessage::UserMessage{user_message: user_message, tracker: rng.next_u64()}, tx)).await;

            let server_message = rx.await;

           if let Ok(ServerMessage::SentMessageReplay { result, sent_message }) = server_message {
            if let ResultHere::Ok = result {
              let sent_message = sent_message.unwrap();
              let there_is_att = sent_message.attachment_name.is_some();
              let there_is_cap = sent_message.caption.is_some();

              let _ = sqlx::query(
              "INSERT INTO sent_messages (id, message_id, payload, attachment_name, attachment_type, caption)
              VALUES ($1, $2, $3, $4, $5, $6)"
            )
            .bind(rng.next_u64() as i64)
            .bind(id.clone())
            .bind(sent_message.payload.clone())
            .bind(sent_message.attachment_name.clone())
            .bind(sent_message.attachment_type.clone())
            .bind(sent_message.caption.clone())
            .execute(state.pool.read().await.as_ref().unwrap()).await;


              messages_ui.push(message_to_message_ui_owned(m, &sent_message, &state).await);

            }
          }
        }
        } else {
           messages_ui.push(message_to_message_ui_unowned(m, &state).await);
        }   
 
       }
        let _ = message_event.send(NextMessageEvent::Get { r: ResultOp::Ok, messages: messages_ui });
 }

   Ok(()) 
}



#[derive(Serialize, Deserialize)]
pub enum NextMessageEvent {
    Get { r: ResultOp, messages: Vec<MessageUI> }
}

