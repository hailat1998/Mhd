use time::OffsetDateTime;
use serde::{Deserialize, Serialize};


#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct MessageUI {
    pub id: Option<i64>,
    pub payload_dec: Option<String>,
    pub caption_dec: Option<String>, 
    pub recipient: String,
    pub sender: String,
    pub seen: bool,
    pub pub_key: String,
    pub locale: Option<String>,
    pub created_at: OffsetDateTime,
    pub updated_at: OffsetDateTime,
    pub attachment_name: Option<String>,
    pub attachment_type: Option<String>,
    pub new: bool,
    pub edit: bool
}

impl MessageUI {
    pub fn new(id: Option<i64>, payload_dec: Option<String>, caption_dec: Option<String>, recipient: String, sender: String, seen: bool, pub_key: String, locale: Option<String>, created_at: OffsetDateTime, updated_at: OffsetDateTime, attachment_name: Option<String>, attachment_type: Option<String>, new: bool, edit: bool) -> Self {
        Self { id, payload_dec, caption_dec, recipient, sender, seen, pub_key, locale, created_at, updated_at, attachment_name, attachment_type, new, edit }
    }
}

