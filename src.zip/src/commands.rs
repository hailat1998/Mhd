pub mod join_command;
pub mod search_command;
pub mod seen_command;
pub mod send_command;
pub mod edit_command;
pub mod status_command;
pub mod profile_command;
pub mod profile_pic_command;
pub mod delete_command;
pub mod auth_command;
pub mod ui_data;
pub mod file_command;
pub mod migrations_command;
pub mod next_messages_command;
pub mod account_command;

use std::collections::HashMap;
use std::time::Duration;
use tauri::{AppHandle, Emitter, Manager};
use tauri::State;
use serde::{Deserialize, Serialize};
use tokio::sync::mpsc::{Receiver, Sender};
use tokio::sync::{oneshot, watch};
use crate::app_state::AppState;
use crate::commands::join_command::join_finisher;
use crate::commands::seen_command::seen_receive;
use crate::core::model::message::Message;
use crate::utils::app_error::AppError;
use crate::utils::encryption_utils::base64_to_array;
use crate::utils::mapper::message_to_message_ui_unowned;
use crate::{core::messages::{ComposeMessage, ServerMessage, UserMessage::{self}}};
use time::OffsetDateTime;

#[derive(Serialize, Deserialize)]
pub enum ResultOp {
    Ok,
    Error
}

pub async fn command_client_manager(
       app: AppHandle,
      mut request_receiver: Receiver<(ComposeMessage, oneshot::Sender<ServerMessage>)>,
      mut server_message_rec: Receiver<ComposeMessage>, 
      server_message_send: Sender<ComposeMessage>
) {
       
     let mut sent_request = HashMap::new();
     
     let app_clone = app.clone();
     
    loop {
    
      tokio::select! {  
    Some((ComposeMessage::UserMessage{user_message, tracker}, sender_back)) = request_receiver.recv() => {
      
      match user_message {
       UserMessage::Join { delete, edit, seen_message, new, last_seen, username, unique_key, sent_message_edit } => {
            let user_message = UserMessage::Join { delete: delete, edit: edit, seen_message: seen_message, new: new, last_seen: last_seen, username: username, unique_key: unique_key, sent_message_edit: sent_message_edit };
            let _ = server_message_send.send(ComposeMessage::UserMessage{user_message, tracker}).await;
        },
         UserMessage::Status { username, other_username, unique_key } => {
            let user_message = UserMessage::Status { username: username, other_username: other_username, unique_key: unique_key };
            sent_request.insert(ServerReplayData::StatusData{tracker}, sender_back);
            let _ = server_message_send.send(ComposeMessage::UserMessage{user_message, tracker}).await;
        },
         UserMessage::Seen { message_id, username, unique_key } => {
            let user_message = UserMessage::Seen { message_id: message_id, username: username, unique_key: unique_key };
            let _ = server_message_send.send(ComposeMessage::UserMessage{user_message, tracker}).await;
        },
         UserMessage::Ping { username, unique_key } => {

        },
         UserMessage::Send { message, sent_message, username, unique_key } => {
          let user_message = UserMessage::Send { message: message, sent_message: sent_message, username: username, unique_key: unique_key };
          sent_request.insert(ServerReplayData::SendData{tracker}, sender_back);
            let _ = server_message_send.send(ComposeMessage::UserMessage{user_message, tracker}).await;
        },
         UserMessage::Edit { message, username, unique_key } => {
         let user_message = UserMessage::Edit { message: message, username: username, unique_key: unique_key };
         sent_request.insert(ServerReplayData::EditData{tracker}, sender_back);
         let _ = server_message_send.send(ComposeMessage::UserMessage{user_message, tracker}).await;
        },
         UserMessage::Delete { message_id, username, other_username, unique_key } => {
         let user_message = UserMessage::Delete { message_id: message_id, username: username, other_username: other_username, unique_key: unique_key };
         sent_request.insert(ServerReplayData::DeleteData{tracker}, sender_back);
         let _ = server_message_send.send(ComposeMessage::UserMessage{user_message, tracker}).await;
        },
         UserMessage::Profile { username, other_username, unique_key } => {
         let user_message = UserMessage::Profile { username: username, other_username: other_username, unique_key: unique_key };
         sent_request.insert(ServerReplayData::ProfileData{tracker}, sender_back);
         let _ = server_message_send.send(ComposeMessage::UserMessage{user_message, tracker}).await;
        },
         UserMessage::ProfilePic { action, username, unique_key } => {
         let user_message = UserMessage::ProfilePic { action: action, username: username, unique_key: unique_key };
         sent_request.insert(ServerReplayData::ProfilePicData{tracker}, sender_back);
         let _ = server_message_send.send(ComposeMessage::UserMessage{user_message, tracker}).await;
        },
         UserMessage::Search { search_kind, username, unique_key, page } => {
         let user_message = UserMessage::Search { search_kind: search_kind, username: username, unique_key: unique_key, page: page };
         sent_request.insert(ServerReplayData::SearchData{tracker}, sender_back);
         let _ = server_message_send.send(ComposeMessage::UserMessage{user_message, tracker}).await;
        },
        UserMessage::NextMessages { starting_from, username, unique_key } => {
          let user_message = UserMessage::NextMessages { starting_from: starting_from, username: username, unique_key: unique_key };
          sent_request.insert(ServerReplayData::NextMessagesData{tracker}, sender_back);
          let _ = server_message_send.send(ComposeMessage::UserMessage{user_message, tracker}).await;
        },
        UserMessage::SentMessage { message_id , username, unique_key} => {
           let user_message = UserMessage::SentMessage { message_id: message_id, username: username, unique_key: unique_key };
           sent_request.insert(ServerReplayData::SentMessageData{tracker}, sender_back);
           let _ = server_message_send.send(ComposeMessage::UserMessage{user_message, tracker}).await;
        },
        UserMessage::SentMessageData { sent_message, username, unique_key } => {
           let user_message = UserMessage::SentMessageData { sent_message: sent_message, username: username, unique_key: unique_key };
           sent_request.insert(ServerReplayData::SentMessageDataHereData{tracker}, sender_back);
           let _ = server_message_send.send(ComposeMessage::UserMessage{user_message, tracker}).await;
        },
        UserMessage::DeleteAccount { username, unique_key} => {
         let user_message = UserMessage::DeleteAccount { username: username, unique_key: unique_key};
         sent_request.insert(ServerReplayData::SentMessageDataHereData{tracker}, sender_back);
         let _ = server_message_send.send(ComposeMessage::UserMessage{user_message, tracker}).await;
        },
        UserMessage::Logout { username, unique_key } => {
         let user_message = UserMessage::Logout { username: username, unique_key: unique_key};
         sent_request.insert(ServerReplayData::SentMessageDataHereData{tracker}, sender_back);
         let _ = server_message_send.send(ComposeMessage::UserMessage{user_message, tracker}).await;
        },
        UserMessage::Sessions  { username, unique_key } => {
         let user_message = UserMessage::Sessions { username: username, unique_key: unique_key};
         sent_request.insert(ServerReplayData::SentMessageDataHereData{tracker}, sender_back);
         let _ = server_message_send.send(ComposeMessage::UserMessage{user_message, tracker}).await;
        }
    }
    }
   
     Some(ComposeMessage::ServerMessage{ server_message, tracker }) = server_message_rec.recv() => {
        match server_message { 
           ServerMessage::Welcome { unique_key, base_64_string } => {
            let state = &app_clone.try_state::<AppState>().unwrap();           
           let _ = state.session_key_sender.send_replace(unique_key);          
           let mut k = state.key_sender.send_replace(base64_to_array(&base_64_string).unwrap());
           
           },
           ServerMessage::JoinReplay { delete, edit, new, new_message_replay, new_sent_replay} => {
            let server_message = ServerMessage::JoinReplay { delete: delete, edit: edit, new: new, new_message_replay: new_message_replay, new_sent_replay: new_sent_replay };
           
            let state: State<'_, AppState> = app.try_state::<AppState>().unwrap();
           
           let _ = join_finisher(state, Ok(server_message)).await;
           },
           ServerMessage::EditReplay { message, result } => {
            if tracker == 3 {
             
            }else if let Some(sender) = sent_request.remove(&ServerReplayData::EditData{tracker}) {
                let server_message = ServerMessage::EditReplay { message: message, result: result };
                let _ = sender.send(server_message);
            } 
           },
           ServerMessage::DeleteReplay { message_id, result } => {
             if tracker == 3 {
             
            }else if let Some(sender) = sent_request.remove(&ServerReplayData::DeleteData{tracker}) {
               let server_message = ServerMessage::DeleteReplay { message_id: message_id, result: result };
               let _ = sender.send(server_message);
            }
           },
           ServerMessage::ProfilePicReplay { result } => {
            if let Some(sender) = sent_request.remove(&ServerReplayData::ProfilePicData{tracker}) {
               let server_message = ServerMessage::ProfilePicReplay { result: result };
               let _ = sender.send(server_message);
            }
           },
           ServerMessage::ProfileReplay { pics, username, name, last_seen } => {
            if let Some(sender) = sent_request.remove(&ServerReplayData::ProfileData{tracker}) {
                let server_message = ServerMessage::ProfileReplay { pics: pics, username: username, name: name, last_seen: last_seen };
                let _ = sender.send(server_message);
            }
           },
           ServerMessage::SearchReplay { result } => {
            if let Some(sender) = sent_request.remove(&ServerReplayData::SearchData{tracker}) {
                let server_message = ServerMessage::SearchReplay { result: result };
                let _ = sender.send(server_message);
            }
           },
           ServerMessage::SendReplay { message, sent_message, result } => {
            if tracker == 3 {
             
            } else if let Some(sender) = sent_request.remove(&ServerReplayData::SendData{tracker}) {
                let server_message = ServerMessage::SendReplay { message: message, sent_message: sent_message, result: result };
                let _ = sender.send(server_message);
            }
           },
           ServerMessage::StatusReplay { name, username, status, pub_key } => {
            if let Some(sender) = sent_request.remove(&ServerReplayData::StatusData{tracker}) {
                let server_message = ServerMessage::StatusReplay { name: name, username: username, status: status, pub_key: pub_key };
                let _ = sender.send(server_message);
            }
           },
           ServerMessage::Pong => {},
           ServerMessage::Joined { username } => {
            let state = app_clone.try_state::<AppState>().unwrap(); 
            state.online_friends.write().await.insert(username);
           },
           ServerMessage::Left { username } => {
             let state = &app_clone.try_state::<AppState>().unwrap();  
            state.online_friends.write().await.remove(&username);
           },
           ServerMessage::Error { message } => {

           },
          ServerMessage::NextMessagesReplay { messages } => {
           if let Some(sender) = sent_request.remove(&ServerReplayData::NextMessagesData{tracker}) {
              let server_message = ServerMessage::NextMessagesReplay { messages: messages };
              let _ = sender.send(server_message);
            }
          },
         ServerMessage::SeenReplay { message_id } => {
            seen_receive(app.clone(), message_id).await;
         },
         ServerMessage::SentMessageReplay { result, sent_message } => {
           if let Some(sender) = sent_request.remove(&ServerReplayData::SentMessageData{tracker}) {
            let server_message = ServerMessage::SentMessageReplay { result: result, sent_message: sent_message };
            let _ = sender.send(server_message);
           }
         },
         ServerMessage::SentMessageDataReplay { result } => {
            if let Some(sender) = sent_request.remove(&ServerReplayData::SentMessageDataHereData{tracker}) {
                let server_message = ServerMessage::SentMessageDataReplay { result: result };
                let _ = sender.send(server_message);
            }
         },
        ServerMessage::DeleteAccountReplay { result } => {
            if let Some(sender) = sent_request.remove(&ServerReplayData::DeleteAccountData{tracker}) {
                let server_message = ServerMessage::DeleteAccountReplay { result };
                let _ = sender.send(server_message);
            }
            },
        ServerMessage::LogoutReplay { result } => {
            if let Some(sender) = sent_request.remove(&ServerReplayData::LogoutData{tracker}) {
                let server_message = ServerMessage::LogoutReplay { result: result }; 
                let _ = sender.send(server_message);
            }
        },
        ServerMessage::SessionsReplay { sessions } => {
            if let Some(sender) = sent_request.remove(&ServerReplayData::SessionsData{tracker}) {
                let server_message =  ServerMessage::SessionsReplay { sessions: sessions };
                let _ = sender.send(server_message);
            }
        },
        }
    }
    else => { break; }
       }
    }
}


#[derive(PartialEq, Eq, Hash)]
enum ServerReplayData {
    EditData{tracker: u64},
    DeleteData{tracker: u64},
    ProfilePicData{tracker: u64},
    ProfileData{tracker: u64},
    SearchData{tracker: u64},
    SendData{tracker: u64},
    StatusData{tracker: u64},
    NextMessagesData{tracker: u64},
    SentMessageData{tracker: u64},
    SentMessageDataHereData{tracker: u64},
    DeleteAccountData{tracker: u64},
    LogoutData{tracker: u64},
    SessionsData{tracker: u64}
}


async fn send_replay_handler(app: AppHandle, message: Message) -> Result<(), AppError> {
  
   let state = app.state::<AppState>();
   
   let _ = sqlx::query!(
   r#"INSERT INTO messages (id, payload, attachment_name, attachment_type, caption, recipient, sender, seen, pub_key, locale, created_at, updated_at)
   VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)"#,
   message.id,
   message.payload,
   message.attachment_name,
   message.attachment_type,
   message.caption,
   message.recipient,
   message.sender,
   message.seen,
   message.pub_key,
   message.locale,
   message.created_at,
   message.updated_at
   ).execute(state.pool.read().await.as_ref().unwrap()).await;

   let message_ui = message_to_message_ui_unowned(&message, &state).await;

   app.emit("new_message", message_ui);

   Ok(())
}

async fn delete_replay_handler(app: AppHandle, message_id: i64) -> Result<(), AppError> {
  
    let state = app.state::<AppState>();

    let _ = sqlx::query!(
        r#"DELETE FROM messages WHERE id = $1"#, 
        message_id
    ).execute(state.pool.read().await.as_ref().unwrap()).await?;

    app.emit("message_deleted", message_id);

    Ok(())
}

async fn edit_replay_handler(app: AppHandle, message: Message) -> Result<(), AppError> {
    
    let state = app.state::<AppState>();

    let _ = sqlx::query!(
   r#"INSERT OR REPLACE INTO messages (id, payload, attachment_name, attachment_type, caption, recipient, sender, seen, pub_key, locale, created_at, updated_at)
   VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)"#,
   message.id,
   message.payload,
   message.attachment_name,
   message.attachment_type,
   message.caption,
   message.recipient,
   message.sender,
   message.seen,
   message.pub_key,
   message.locale,
   message.created_at,
   message.updated_at
   ).execute(state.pool.read().await.as_ref().unwrap()).await?;

    let message_ui = message_to_message_ui_unowned(&message, &state).await;

   app.emit("edit_message", message_ui);

   Ok(())
}

