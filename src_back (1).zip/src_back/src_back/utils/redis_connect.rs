use redis::{Client as RedisClient, aio::MultiplexedConnection};
use crate::utils::error::AppError;

pub async fn get_redis_conn(
    client: &RedisClient,
) -> Result<MultiplexedConnection, AppError> {
    let conn = client
        .get_multiplexed_async_connection()
        .await?; 

    Ok(conn)
}