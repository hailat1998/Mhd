use std::num::NonZeroUsize;
use std::time::{Duration, Instant};

use lru::LruCache;
use tokio::sync::mpsc::Receiver;
use tokio::time;



pub struct TimeAwareLru {
    cache: LruCache<String, Instant>,
    rx: Receiver<String>,
    ttl: Duration,
    tick_interval: Duration,
}

impl TimeAwareLru {
    pub fn new(
        rx: Receiver<String>,
        ttl_secs: u64,
        interval_millis: u64,
    ) -> Self {
        Self {
            cache: LruCache::new(NonZeroUsize::new(1_000_000).unwrap()),
            rx,
            ttl: Duration::from_secs(ttl_secs),
            tick_interval: Duration::from_millis(interval_millis),
        }
    }

   pub async fn run<F, Fut>(mut self, mut on_evict: F)
where
    F: FnMut(String) -> Fut + Send,
    Fut: std::future::Future<Output = ()> + Send,
    {
        let mut ticker = time::interval(self.tick_interval);

        loop {
            ticker.tick().await;

            let now = Instant::now();

            
            while let Ok(key) = self.rx.try_recv() {
                self.cache.put(key, now);
            }

           
            while let Some((_, &timestamp)) = self.cache.peek_lru() {
                if now.duration_since(timestamp) > self.ttl {
                    let (key, _) = self.cache.pop_lru().unwrap();
                    on_evict(key).await; 
                } else {
                    break;
                }
            }
        }
    }
}