use aes_gcm::{
    aead::{Aead, KeyInit},
    Aes256Gcm, Nonce
};
use aes_gcm::aead::generic_array::GenericArray;
use base64::{Engine as _, engine::general_purpose};
use rand_core_compat::rand_core_0_6::{OsRng, RngCore};


pub fn decrypt_string(
    key: &[u8; 32], 
    encrypted_base64: &str, 
    nonce: &[u8; 12]
) -> Result<String, String> {
    let key = GenericArray::from_slice(key);
    let cipher = Aes256Gcm::new(key);
    let nonce = Nonce::from_slice(nonce);

    
    let encrypted_data = general_purpose::STANDARD
        .decode(encrypted_base64)
        .map_err(|e| format!("Base64 decode error: {}", e))?;

    cipher
        .decrypt(nonce, encrypted_data.as_ref())
        .map_err(|e| format!("Decryption error: {}", e))
        .and_then(|decrypted| {
            String::from_utf8(decrypted)
                .map_err(|e| format!("UTF-8 conversion error: {}", e))
        })
}

pub fn encrypt_string(
    key: &[u8; 32],
    plaintext: &str,
    nonce: &[u8; 12],
) -> Result<String, String> {  
    let key = GenericArray::from_slice(key);
    let cipher = Aes256Gcm::new(key);
    let nonce = Nonce::from_slice(nonce);

    cipher
        .encrypt(nonce, plaintext.as_bytes())
        .map(|encrypted| general_purpose::STANDARD.encode(encrypted))
        .map_err(|e| format!("Encryption error: {}", e))
}


pub fn generate_32_bytes() -> [u8; 32] {
    let mut bytes = [0u8; 32];
  
    let mut rng = OsRng;

    rng.fill_bytes(&mut bytes);
    bytes
}

pub fn generate_12_bytes() -> [u8; 12] {
    let mut bytes = [0u8; 12];
  
    let mut rng = OsRng;

    rng.fill_bytes(&mut bytes);
    bytes
}


pub fn bytes_to_base64(bytes: &[u8]) -> String {
    general_purpose::STANDARD.encode(bytes)
}

pub fn base64_to_array<const N: usize>(
    s: &str,
) -> Result<[u8; N], Box<dyn std::error::Error>> {
    let bytes = general_purpose::STANDARD.decode(s)?;
    let arr: [u8; N] = bytes.try_into()
        .map_err(|_| "Invalid length for array")?;
    Ok(arr)
}
