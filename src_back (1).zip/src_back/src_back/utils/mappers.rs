use crate::model::{ modified_message::ModifiedMessage, message::Message };

pub fn map_event_to_message(events: &Vec<ModifiedMessage>) -> Vec<Message> {
  let mut messages = vec![];

  for e in events {
    let m = Message {
         id : Some(e.message_id),
         payload: e.payload.clone(),
         attachment_name: e.attachment_name.clone(),
         attachment_type: e.attachment_type.clone(),
         caption: e.caption.clone(),
         recipient: e.event_receiver.clone(),
         sender: e.event_owner.clone(),
         seen: false, 
         pub_key: e.pub_key.clone(),
         locale: None, 
         created_at: e.created_at,
         updated_at: e.updated_at,
         deleted_at: None
    };
    messages.push(m);
  }

messages
}