use crate::messages::{ ComposeMessage, UserMessage, ServerMessage };
use crate::{AppState, app_state};
use crate::sessions::Session;
use crate::utils::AppError;
use tokio::sync::mpsc::Sender;
use std::sync::Arc;

async fn seen_handler(tx: Sender<ComposeMessage>, state: Arc<AppState>, message_user: UserMessage) -> Result<(), AppError> {
   
   if let UserMessage::Seen { message_id, username, unique_key } = message_user {
     if let Ok(user_session) = state.users_session_online.get_session(&username).await {

      if unique_key != *user_session.get_unique_key() {
        let _ = tx.send(ComposeMessage::Error { msg: "wrong key".to_string(), tracker: 1 }).await;
        return Err(AppError::Unauthorized("wrong key".to_string()));
       }   
     
     let _ = state.message_seen_tracker.push_r(&app_state::MESSAGE_SEEN_TRACKER.to_string()
       , &message_id).await;
    } 
    }

    Ok(())
}