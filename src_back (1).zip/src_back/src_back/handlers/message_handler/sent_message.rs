use crate::{messages::{ ComposeMessage, server_massages::ServerMessage, user_messages::UserMessage}, model::{Message, FileType} , sessions::Session, utils::hash_to_0_9};
use crate::app_state::AppState;
use crate::utils::AppError;
use tokio::sync::mpsc::Sender;
use crate::model::message::SentMessage;
use std::sync::Arc;
use crate::model::EventType;
use crate::model::ModifiedMessage;


pub async fn sent_message_handler(tx: Sender<ComposeMessage>, state: Arc<AppState>, message_user: UserMessage, tracker: u64) -> Result<(), AppError> {
    if let UserMessage::SentMessage { message_id, username, unique_key } = message_user {
     if let Ok(user_session) = state.users_session_online.get_session(&username).await {

      if unique_key != *user_session.get_unique_key() {
        let _ = tx.send(ComposeMessage::Error { msg: "wrong key".to_string(), tracker: 1 }).await;
        return Err(AppError::Unauthorized("wrong key".to_string()));
       }   

       let mut original_message = sqlx::query_as!(
        Message, 
        r#"SELECT * FROM messages WHERE id = $1 AND sender = $2"#,
        message_id,
        username.clone()
       ).fetch_optional(&state.pgpool).await.unwrap();

        
      if original_message.is_none() {

        let mut mod_message =  sqlx::query_as!(
         ModifiedMessage,
         r#"SELECT   id,
          modification_type as "event_type: EventType" ,
          payload,
          attachment_name,
          attachment_type,
          caption, 
          event_owner, 
          is_delivered,
          message_id, event_receiver, 
          created_at, updated_at, pub_key  FROM modified_messages WHERE message_id = $1 AND event_owner = $2"#,
          message_id,
          username.clone()
        ).fetch_optional(&state.pgpool).await.unwrap();

        if mod_message.is_none() || mod_message.is_some_and(|m| m.event_type == EventType::Delete){
            let _ = tx.send(ComposeMessage::ServerMessage { server_message: ServerMessage::Error { message: "Message Not Found".to_string() }, tracker: tracker }).await;
             return Err(AppError::NotFound("Message Not Found".to_string()));
        }
      }

      let sent_message_here = sqlx::query_as!(
        SentMessage, 
        r#"SELECT * FROM sent_messages WHERE message_id = $1"#,
        message_id,
      ).fetch_one(&state.pgpool).await;

      match sent_message_here {
        Ok(s) => {
          let _ = tx.send(ComposeMessage::ServerMessage { server_message: ServerMessage::SentMessageReplay { result: crate::messages::server_massages::ResultHere::Ok, sent_message: Some(s) }, tracker: tracker }).await;
        },
        Err(_) => {
          let _ = tx.send(ComposeMessage::ServerMessage { server_message: ServerMessage::Error { message: "Message Not Found".to_string() }, tracker: tracker }).await;
          return Err(AppError::NotFound("Message Not Found".to_string()));
        }
      }

    }
    }

    Ok(())
}