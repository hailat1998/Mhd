use crate::{messages::{ ComposeMessage, server_massages::ServerMessage, user_messages::UserMessage}, model::{Message, FileType} , sessions::Session, utils::hash_to_0_9};
use crate::app_state::AppState;
use crate::utils::AppError;
use tokio::sync::mpsc::Sender;
use crate::model::message::SentMessage;
use std::sync::Arc;

pub async fn send_handler(tx: Sender<ComposeMessage>, state: Arc<AppState>, message_user: UserMessage, tracker: u64) -> Result<(), AppError> {
   if let UserMessage::Send { message, username, unique_key, sent_message } = message_user {
     if let Ok(user_session) = state.users_session_online.get_session(&username).await {

      if unique_key != *user_session.get_unique_key() {
        let _ = tx.send(ComposeMessage::Error { msg: "wrong key".to_string(), tracker: 1 }).await;
        return Err(AppError::Unauthorized("wrong key".to_string()));
       }   
           
    let message_here =  sqlx::query_as!(
      Message,
       r#"INSERT INTO messages (payload, attachment_name, attachment_type, recipient, sender, seen, locale, created_at, updated_at, pub_key)
        VALUES ($1,$2, $3, $4, $5, $6, $7, $8, $9, $10)
        RETURNING id, payload, attachment_name, attachment_type, caption, recipient, sender, seen, locale, 
        created_at, updated_at, deleted_at, pub_key"#,
        message.payload.clone(),
        message.attachment_name.clone(),
        message.attachment_type.clone(),
        message.recipient.clone(),
        message.sender.clone(),
        message.seen.clone(),
        message.locale.clone(),
        message.created_at,
        message.updated_at,
        message.pub_key.clone()
     )
     .fetch_one(&state.pgpool).await;

    match message_here {    
      Ok(message_here_) => { 
       if let Ok(_) = state.users_session_online.get_session(&message.recipient).await {
      match state.online_channels[hash_to_0_9(&message.recipient.clone()) as usize].get(&message.recipient.clone()) {
      Some(ch_sender) => { 
        let _ = ch_sender.send(ComposeMessage::ServerMessage{server_message: ServerMessage::SendReplay { message: message_here_.clone(), result: crate::messages::server_massages::ResultHere::Ok, sent_message : None }, tracker: 3}).await; 
          ()
        },
       None => {}
        }
      }
      let sent_message_here = sqlx::query_as!(
        SentMessage,
        r#"INSERT INTO sent_messages (message_id, payload, attachment_name, attachment_type, caption)
        VALUES ($1, $2, $3, $4, $5)
        RETURNING id, message_id, payload, attachment_name, attachment_type, caption"#,
        message_here_.id.unwrap(),
        sent_message.payload,
        sent_message.attachment_name,
        sent_message.attachment_type,
        sent_message.caption
      ).fetch_one(&state.pgpool).await.unwrap();

     let _ = tx.send(ComposeMessage::ServerMessage{server_message: ServerMessage::SendReplay { message: message_here_, result: crate::messages::server_massages::ResultHere::Ok, sent_message: Some(sent_message_here) }, tracker: tracker}).await; 
    },
     _ =>  {}
    }


   }
   } else {
      let _ = tx.send(ComposeMessage::ServerMessage { server_message: ServerMessage::Error { message: "Something went wrong".to_string() }, tracker: tracker }).await;
   }
   Ok(())
}