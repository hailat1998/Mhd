use tokio::sync::mpsc::Sender;
use std::sync::Arc;
use time::OffsetDateTime;

use crate::{app_state::AppState, messages::{ ComposeMessage, ServerMessage, UserMessage, user_messages::ProfilePicAction::{ Delete, SetFirst, Update }}, sessions::{Session, user_session::UserSession}, utils::AppError, model::{User, LastKeys} };



pub async fn profile_pic_handler(tx: Sender<ComposeMessage>, state: Arc<AppState>, message_user: UserMessage, tracker: u64) -> Result<(), AppError> {

    if let UserMessage::ProfilePic { action, username , unique_key} = message_user {
     if let Ok(user_session) = state.users_session_online.get_session(&username).await {
    
       if unique_key != *user_session.get_unique_key() {
        let _ = tx.send(ComposeMessage::Error { msg: "wrong key".to_string(), tracker: 1 }).await;
        return Err(AppError::Unauthorized("wrong key".to_string()));
         }   

     match action {
        Delete { pic_id } => {

        let pics = user_session.get_profile_pics();

        let mut new_pics = vec![];
             
            for p in pics {
               if *p == pic_id {
                continue;
               }
               new_pics.push(p.to_string());
            }

           let user: User = sqlx::query_as!(
            User, 
           r#"UPDATE users SET profile_pics = $1, updated_at = $2 WHERE username = $3
           RETURNING id, username, password_hash, pub_key, profile_pics, created_at, updated_at, name, last_key as "last_key: LastKeys", chats, deleted_at
           "#,
           &new_pics, 
           OffsetDateTime::now_utc(),
           &username
           )
           .fetch_one(&state.pgpool)
           .await.unwrap();
         
         let new_session = UserSession {
            installation_id: user_session.get_installation_id().to_string(),
            username: user_session.get_username().to_string(),
            pub_key: user_session.get_pub_key().to_string(),
            unique_key: user_session.get_unique_key().to_string(),
            connected_at: user_session.get_time(),
            name: user_session.get_name().to_string(),
            profile_pics: new_pics,
            last_key: user_session.get_last_key().to_string(),
            chats: user.chats
                 };

           let _ = state.users_session_online.save_session(&new_session).await;

         let _ = tx.send(ComposeMessage::ServerMessage{server_message: ServerMessage::ProfilePicReplay { result: crate::messages::server_massages::ResultHere::Ok }, tracker: tracker}).await;
         
        },
        SetFirst { pic_id } => {
         
          let pics = user_session.get_profile_pics();

          let mut new_pics = vec![];

          let mut first = String::new();
             
            for p in pics {
               if *p == pic_id {
                first.push_str(p.as_str());
                continue;
               }
               new_pics.push(p.to_string());
            }

            new_pics.insert(0, first);

            let user: User = sqlx::query_as!(
            User, 
           r#"UPDATE users SET profile_pics = $1, updated_at = $2 WHERE username = $3
           RETURNING id, username, password_hash, pub_key, profile_pics, created_at, updated_at, name, last_key as "last_key: LastKeys", chats, deleted_at
           "#,
           &new_pics, 
           OffsetDateTime::now_utc(),
           &username
           )
           .fetch_one(&state.pgpool)
           .await.unwrap();
         
         let new_session = UserSession {
            installation_id: user_session.get_installation_id().to_string(),
            username: user_session.get_username().to_string(),
            pub_key: user_session.get_pub_key().to_string(),
            unique_key: user_session.get_unique_key().to_string(),
            connected_at: user_session.get_time(),
            name: user_session.get_name().to_string(),
            profile_pics: new_pics,
            last_key: user_session.get_last_key().to_string(),
            chats: user.chats
                 };

           let _ = state.users_session_online.save_session(&new_session).await;

         let _ = tx.send(ComposeMessage::ServerMessage{server_message: ServerMessage::ProfilePicReplay { result: crate::messages::server_massages::ResultHere::Ok }, tracker: tracker}).await;
        },
        Update { pic_id } => {
           
            let pics = user_session.get_profile_pics();

          let mut new_pics = vec![pic_id];

         let mut count = 0;
             
            for p in pics {
             count = count + 1;

             if count > 10 {
                break;
             }
               new_pics.push(p.to_string());
            }

           let user: User = sqlx::query_as!(
            User, 
           r#"UPDATE users SET profile_pics = $1, updated_at = $2 WHERE username = $3
           RETURNING id, username, password_hash, pub_key, profile_pics, created_at, updated_at, name, last_key as "last_key: LastKeys", chats, deleted_at
           "#,
           &new_pics, 
           OffsetDateTime::now_utc(),
           &username
           )
           .fetch_one(&state.pgpool)
           .await.unwrap();
         
         let new_session = UserSession {
            installation_id: user_session.get_installation_id().to_string(),
            username: user_session.get_username().to_string(),
            pub_key: user_session.get_pub_key().to_string(),
            unique_key: user_session.get_unique_key().to_string(),
            connected_at: user_session.get_time(),
            name: user_session.get_name().to_string(),
            profile_pics: new_pics,
            last_key: user_session.get_last_key().to_string(),
            chats: user.chats
                 };

           let _ = state.users_session_online.save_session(&new_session).await;

         let _ = tx.send(ComposeMessage::ServerMessage{server_message: ServerMessage::ProfilePicReplay { result: crate::messages::server_massages::ResultHere::Ok }, tracker: tracker}).await;
        }
     }

    } else {
      let _ = tx.send(ComposeMessage::ServerMessage { server_message: ServerMessage::Error { message: "Something went wrong".to_string() }, tracker: tracker }).await;
    } 

    }

    Ok(())
}
