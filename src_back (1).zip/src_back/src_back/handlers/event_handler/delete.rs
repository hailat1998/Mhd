use crate::{messages::{ ComposeMessage, server_massages::ServerMessage, user_messages::UserMessage}, model::modified_message::EventType, sessions::Session, utils::hash_to_0_9};
use crate::model::{FileType , message::Message };
use crate::app_state::AppState;
use crate::utils::AppError;
use tokio::sync::mpsc::Sender;
use std::sync::Arc;



pub async fn delete_handler(tx: Sender<ComposeMessage>, state: Arc<AppState>, message_user: UserMessage, tracker: u64) -> Result<(), AppError> {
    if let UserMessage::Delete { message_id, username, other_username, unique_key} = message_user {

      if let Ok(user_session) = state.users_session_online.get_session(&username).await { 

       if unique_key != *user_session.get_unique_key() {
        let _ = tx.send(ComposeMessage::Error { msg: "wrong key".to_string(), tracker: 1 }).await;
        return Err(AppError::Unauthorized("wrong key".to_string()));
       }   

      if let Ok(_) = state.users_session_online.get_session(&other_username).await {       

      match state.online_channels[hash_to_0_9(&other_username) as usize].get(&other_username) {
      Some(ch_sender) => { 
        let _ = ch_sender.send(ComposeMessage::ServerMessage{server_message: ServerMessage::DeleteReplay { message_id: message_id, result: crate::messages::server_massages::ResultHere::Ok }, tracker: 3}).await;           
        },
       None => ()
      }
    }    

       let deleted_message =   sqlx::query_as!(
          Message,
       r#"DELETE FROM messages WHERE id = $1
       RETURNING id, payload, attachment_name, attachment_type, caption, recipient, sender, seen, locale, 
       created_at, updated_at, deleted_at, pub_key"#,
       message_id  
       )
        .fetch_optional(&state.pgpool)
        .await;


    match deleted_message {    
    Ok(Some(deleted_message)) => {      
       let _ = sqlx::query(
    " INSERT INTO modified_messages 
         (modification_type, event_owner, delivered_to_receiver,
          message_id, event_receiver, created_at, updated_at, pub_key)
          VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)"          
        )
        .bind(EventType::Delete)
        .bind(deleted_message.sender)
        .bind(false)
        .bind(deleted_message.id)
        .bind(deleted_message.recipient)
        .bind(time::OffsetDateTime::now_utc())
        .bind(time::OffsetDateTime::now_utc())
        .bind(deleted_message.pub_key)
        .execute(&state.pgpool).await;
    },
    _ => { return Ok(()); }
      }  
      }
    } else {
      let _ = tx.send(ComposeMessage::ServerMessage { server_message: ServerMessage::Error { message: "Something went wrong".to_string() }, tracker: tracker });
   }

    Ok(())
}
