use crate::{messages::{ ComposeMessage, server_massages::ServerMessage, user_messages::UserMessage}, model::modified_message::EventType, sessions::Session, utils::hash_to_0_9};
use crate::model::{FileType , message::Message };
use crate::app_state::AppState;
use crate::utils::AppError;
use tokio::sync::mpsc::Sender;
use std::sync::Arc;


pub async fn edit_handler(tx: Sender<ComposeMessage>, state: Arc<AppState>, message_user: UserMessage, tracker: u64) -> Result<(), AppError> {
  
    if let UserMessage::Edit { message, username, unique_key } = message_user {

     if let Ok(user_session) = state.users_session_online.get_session(&username).await {  

      if unique_key != *user_session.get_unique_key() {
        let _ = tx.send(ComposeMessage::Error { msg: "wrong key".to_string(), tracker: 1 }).await;
        return Err(AppError::Unauthorized("wrong key".to_string()));
       } 

       let mut delivered = false;     

     if let Ok(_) = state.users_session_online.get_session(&message.recipient).await {

      match state.online_channels[hash_to_0_9(&message.recipient.clone()) as usize].get(&message.recipient.clone()) {
      Some(ch_sender) => { 
        delivered = true;
        let _ = ch_sender.send(ComposeMessage::ServerMessage{server_message: ServerMessage::EditReplay { message: message.clone(), result: crate::messages::server_massages::ResultHere::Ok }, tracker: 3}).await;         
        },
       None => ()
      }
     }

   let message_here =   sqlx::query_as!(
          Message,
       r#"DELETE FROM messages WHERE id = $1
       RETURNING id, payload, attachment_name, attachment_type, caption, recipient, sender, seen, locale, 
       created_at, updated_at, deleted_at, pub_key"#,
       message.id  
       )
        .fetch_optional(&state.pgpool)
        .await;

    
    match message_here {
   Ok(_message_here) => {
     let _ = sqlx::query(
      " INSERT INTO modified_messages 
           (modification_type, payload, attachments, caption, event_owner, is_delivered,
            message_id, event_receiver, created_at, updated_at, pub_key)
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)"          
          )
          .bind(EventType::Edit)
          .bind(message.payload.clone())
          .bind(message.attachment_name.clone())
          .bind(message.attachment_type.clone())
          .bind(message.caption.clone())
          .bind(message.sender.clone())
          .bind(delivered)
          .bind(message.id)
          .bind(message.recipient.clone())
          .bind(message.created_at)
          .bind(time::OffsetDateTime::now_utc())
         .bind(message.pub_key.clone())
         .execute(&state.pgpool).await;  
        let _ = tx.send(ComposeMessage::ServerMessage{server_message: ServerMessage::EditReplay { message: message.clone(), result: crate::messages::server_massages::ResultHere::Ok }, tracker: tracker}).await; 
             },
    _ => {
      let _ = tx.send(ComposeMessage::ServerMessage { server_message: ServerMessage::Error { message: "Message deleted".to_string() }, tracker: tracker });
      }
     }     
      }
    } else {
      let _ = tx.send(ComposeMessage::ServerMessage { server_message: ServerMessage::Error { message: "Something went wrong".to_string() }, tracker: tracker });
   }
    Ok(())
}