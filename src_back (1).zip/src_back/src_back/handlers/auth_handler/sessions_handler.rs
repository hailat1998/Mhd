use crate::{messages::{ ComposeMessage, server_massages::ServerMessage, user_messages::UserMessage}, model::User, sessions::Session, utils::hash_to_0_9};
use crate::model::{FileType , message::Message };
use crate::app_state::AppState;
use crate::utils::AppError;
use tokio::sync::mpsc::Sender;
use std::sync::Arc;
use crate::messages::server_massages::ActiveSession;


pub async fn sessions_handler(tx: Sender<ComposeMessage>, state: Arc<AppState>, message_user: UserMessage, tracker: u64) -> Result<(), AppError> {
  
    if let UserMessage::Sessions { username, unique_key } = message_user {
     
        if let Ok(user_session) = state.users_session_online.get_session(&username).await {
    
       if unique_key != *user_session.get_unique_key() {
        let _ = tx.send(ComposeMessage::Error { msg: "wrong key".to_string(), tracker: 1 }).await;
        return Err(AppError::Unauthorized("wrong key".to_string()));
       } 

        let active_sessions = sqlx::query_as!(
        ActiveSession,
        r#"SELECT os_name, device_id FROM sessions WHERE username = $1"#,
        username
       )
       .fetch_all(&state.pgpool).await.unwrap();

       let _ = tx.send(ComposeMessage::ServerMessage { server_message: ServerMessage::SessionsReplay { sessions: active_sessions }, tracker: tracker }).await;
     }
    }

    Ok(())
}