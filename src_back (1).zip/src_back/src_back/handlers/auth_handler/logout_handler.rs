use crate::{messages::{ ComposeMessage, server_massages::ServerMessage, user_messages::UserMessage}, sessions::Session, utils::hash_to_0_9};
use crate::model::{FileType , message::Message };
use crate::app_state::AppState;
use crate::utils::AppError;
use crate::SessionGlobal;
use tokio::sync::mpsc::Sender;
use std::sync::Arc;


pub async fn logout_handler(tx: Sender<ComposeMessage>, state: Arc<AppState>, message_user: UserMessage, tracker: u64) -> Result<(), AppError> {

   if let UserMessage::Logout {username, unique_key} = message_user {
     if let Ok(user_session) = state.users_session_online.get_session(&username).await {
    
       if unique_key != *user_session.get_unique_key() {
        let _ = tx.send(ComposeMessage::Error { msg: "wrong key".to_string(), tracker: 1 }).await;
        return Err(AppError::Unauthorized("wrong key".to_string()));
       } 

       let installation_id = user_session.get_installation_id().clone();

       let _ = sqlx::query_as!(
        SessionGlobal,
        r#"DELETE FROM sessions WHERE username = $1 AND installation_id = $2
        RETURNING id, device_id, username, seen_date, installation_id, created_at, deleted_at, os_name"#,
        username,
        installation_id
       )
       .fetch_one(&state.pgpool).await;

      tx.send(ComposeMessage::ServerMessage { server_message: ServerMessage::LogoutReplay { result: crate::messages::server_massages::ResultHere::Ok }, tracker: tracker }).await;
     }
   }

  Ok(())
}