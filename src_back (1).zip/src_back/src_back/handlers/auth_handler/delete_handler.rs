use crate::{messages::{ ComposeMessage, server_massages::ServerMessage, user_messages::UserMessage}, sessions::Session, utils::hash_to_0_9};
use crate::model::{FileType , message::Message };
use crate::app_state::AppState;
use crate::utils::AppError;
use crate::SessionGlobal;
use tokio::sync::mpsc::Sender;
use std::sync::Arc;


pub async fn delete_account_handle(tx: Sender<ComposeMessage>, state: Arc<AppState>, message_user: UserMessage, tracker: u64) -> Result<(), AppError> {
    
    if let UserMessage::DeleteAccount { username, unique_key } = message_user {
      
      if let Ok(user_session) = state.users_session_online.get_session(&username).await {
    
       if unique_key != *user_session.get_unique_key() {
        let _ = tx.send(ComposeMessage::Error { msg: "wrong key".to_string(), tracker: 1 }).await;
        return Err(AppError::Unauthorized("wrong key".to_string()));
       } 

      let all_sessions = sqlx::query_as!(
        SessionGlobal,
        r#"DELETE FROM sessions WHERE username = $1
        RETURNING id, device_id, username, seen_date, installation_id, created_at, deleted_at, os_name"#,
        username
       )
       .fetch_all(&state.pgpool).await.unwrap();       

    }
    }

    Ok(())
}