use tokio::sync::mpsc::Sender;
use std::sync::Arc;

use crate::{app_state::AppState, messages::{ ComposeMessage, ServerMessage, UserMessage }, model::{User, LastKeys}, sessions::Session, utils::AppError };


pub async fn profile_handler(tx: Sender<ComposeMessage>, state: Arc<AppState>, message_user: UserMessage, tracker: u64) -> Result<(), AppError> {
     
     if let UserMessage::Profile { username , other_username, unique_key} = message_user {
      if let Ok(user_session) = state.users_session_online.get_session(&username).await {

       if unique_key != *user_session.get_unique_key() {        
        let _ = tx.send(ComposeMessage::Error { msg: "wrong key".to_string(), tracker: 1 }).await;
        return Err(AppError::Unauthorized("wrong key".to_string()));
        }   

     if let Ok(other_user_session) = state.users_session_online.get_session(&other_username).await {

      let replay = ComposeMessage::ServerMessage{server_message: ServerMessage::ProfileReplay { pics: other_user_session.get_profile_pics().to_vec(), username: other_user_session.get_username().to_string(), name: other_user_session.get_name().to_string(), last_seen: -1 }, tracker: tracker};

      let _ = tx.send(replay).await;
     } else if let  Ok(other_user_session) = state.users_session_last_seen.get_session(&other_username).await {
       let replay = ComposeMessage::ServerMessage{server_message: ServerMessage::ProfileReplay { pics: other_user_session.get_profile_pics().clone().to_vec(), username: other_user_session.get_username().to_string(), name: other_user_session.get_name().to_string(), last_seen: other_user_session.get_time()}, tracker: tracker};

       let _ = tx.send(replay).await;
     } else {

        let user: User =  sqlx::query_as!(
        User, 
        r#"
            SELECT               
             id, username, password_hash, pub_key, profile_pics, created_at, updated_at, name, last_key as "last_key: LastKeys", chats, deleted_at
            FROM users            
            WHERE username = $1
            "#,
            other_username
        )
        .fetch_one(&state.pgpool)
        .await
        .map_err(|e| {
            AppError::database("Failed to fetch user")
        })?;
       
     
       let replay = ComposeMessage::ServerMessage{server_message: ServerMessage::ProfileReplay { pics: user.profile_pics.unwrap_or(Vec::new()), username: user.username, name: user.name, last_seen: i64::MIN }, tracker: tracker};

       let _ = tx.send(replay).await;
     } 
    }  
   } else {
      let _ = tx.send(ComposeMessage::ServerMessage { server_message: ServerMessage::Error { message: "Something went wrong".to_string() }, tracker: tracker }).await;
       }

    Ok(())
}