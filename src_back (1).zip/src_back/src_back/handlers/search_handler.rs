use tokio::sync::mpsc::Sender;
use crate::{app_state::AppState, messages::{ComposeMessage, ServerMessage, UserMessage, server_massages::{SearchResult, UserSearch }, user_messages::SearchKind::{ MessageSet, OtherUser}}, model::{ModifiedMessage, message}, sessions::Session, utils::{AppError, mappers}};
use crate::model::{ Message, FileType,EventType};
use std::sync::Arc;



pub async fn search_handler(tx: Sender<ComposeMessage>, state: Arc<AppState>, message_user: UserMessage, tracker: u64) -> Result<(), AppError> {
    
    if let UserMessage::Search { search_kind, username, unique_key, page } = message_user {
        if let Ok(user_session) = state.users_session_online.get_session(&username).await { 
 
       if unique_key != *user_session.get_unique_key() {
         let _ = tx.send(ComposeMessage::Error { msg: "wrong key".to_string(), tracker: 1 }).await;
        return Err(AppError::Unauthorized("wrong key".to_string()));
        }   

       let (start, end) = month_range(page);

        match search_kind {
        MessageSet { key_term } => {
        
          let mut messages = sqlx::query_as!(
           Message,
              r#"
          SELECT 
           id,
          payload,
          attachment_name,
          attachment_type,
          caption,
          recipient,
          sender,
          seen,
          locale,
          created_at,
          updated_at,
          deleted_at,
          pub_key
          FROM messages
          WHERE created_at >= $1
          AND created_at < $2
          AND (
          recipient ILIKE $3
          OR sender ILIKE $3
           )
          ORDER BY created_at DESC
          "#,
          start, 
          end,
          key_term
          )
         .fetch_all(&state.pgpool)
         .await;

         let events = sqlx::query_as!(
            ModifiedMessage, 
             r#"
          SELECT 
          id,
          modification_type as "event_type: EventType" ,
          payload,
          attachment_name,
          attachment_type, 
          caption, 
          event_owner,            
          message_id, 
          is_delivered,
          event_receiver, 
          created_at, updated_at, pub_key 
          FROM modified_messages
           WHERE created_at >= $1
          AND created_at < $2
          AND (
          event_owner ILIKE $3
          OR event_receiver ILIKE $3
           )
          ORDER BY created_at DESC"#,
           start, 
           end,
          key_term
         )
         .fetch_all(&state.pgpool)
         .await;
        

         let mut live_event = vec![];

         for e in events.unwrap() {
            if e.event_type == EventType::Edit {
            live_event.push(e);
            }           
         }

         let new_edit_messages: Vec<Message> = mappers::map_event_to_message(&live_event); 

         messages.as_mut().unwrap().extend(new_edit_messages.iter().cloned()); 

         let _ = tx.send(ComposeMessage::ServerMessage{server_message: ServerMessage::SearchReplay { result: SearchResult{ messages: messages.unwrap(), users: Vec::new() }}, tracker: tracker});
          
        }

        OtherUser { key_term } => {
         let user = sqlx::query_as!(
            UserSearch, 
            "SELECT username, name FROM users WHERE 
            username ILIKE '% ' || $1 || '%'
            ORDER BY 
              CASE 
               WHEN lower(username) = lower($1) THEN 0
               ELSE 1
            END               
           ",
            key_term
           )
           .fetch_all(&state.pgpool)
           .await;

         let _ = tx.send(ComposeMessage::ServerMessage{server_message: ServerMessage::SearchReplay { result: SearchResult{ messages: Vec::new(), users: user.unwrap() }}, tracker: tracker});

        }       
            
        }


        }
    }

    Ok(())
}


use time::{OffsetDateTime, Month};

fn month_range(n: i32) -> (OffsetDateTime, OffsetDateTime) {
    let now = OffsetDateTime::now_utc();

    
    let mut year = now.year();
    let mut month = now.month() as i32;

    month -= (n - 1);

    while month <= 0 {
        month += 12;
        year -= 1;
    }

    while month > 12 {
        month -= 12;
        year += 1;
    }

    let month_enum = Month::try_from(month as u8).unwrap();

   
    let start = OffsetDateTime::new_utc(
        time::Date::from_calendar_date(year, month_enum, 1).unwrap(),
        time::Time::MIDNIGHT,
    );

    
    let mut next_month = month + 1;
    let mut next_year = year;

    if next_month > 12 {
        next_month = 1;
        next_year += 1;
    }

    let next_month_enum = Month::try_from(next_month as u8).unwrap();

    let end = OffsetDateTime::new_utc(
        time::Date::from_calendar_date(next_year, next_month_enum, 1).unwrap(),
        time::Time::MIDNIGHT,
    );

    (start, end)
}