use tokio::sync::mpsc::Sender;
use crate::{app_state::AppState, messages::{ComposeMessage, ServerMessage, UserMessage, server_massages::StatusNow}, model::{User, LastKeys}, sessions::Session, utils::AppError};
use std::sync::Arc;


pub async fn status_handler(tx: Sender<ComposeMessage>, state: Arc<AppState>, message_user: UserMessage, tracker: u64) -> Result<(), AppError> {
 
 if let UserMessage::Status { username,other_username, unique_key } = message_user {

     if let Ok(user_session) = state.users_session_online.get_session(&username).await {
    
      if unique_key != *user_session.get_unique_key() {
        let _ = tx.send(ComposeMessage::Error { msg: "wrong key".to_string(), tracker: 1 }).await;
        return Err(AppError::Unauthorized("wrong key".to_string()));
       }   

     if let Ok(other_user_session) = state.users_session_online.get_session(&other_username).await {
        let _ = tx.send(ComposeMessage::ServerMessage{server_message: ServerMessage::StatusReplay { name: other_user_session.get_name().to_string(), username: other_user_session.get_username().to_string(), status: StatusNow::Online, pub_key: other_user_session.get_pub_key().to_string() }, tracker: tracker }).await;
     } else if let  Ok(other_user_session) = state.users_session_last_seen.get_session(&other_username).await {
        let _ = tx.send(ComposeMessage::ServerMessage{ server_message: ServerMessage::StatusReplay { name: other_user_session.get_name().to_string(), username: other_user_session.get_username().to_string(), status: StatusNow::Offline, pub_key: other_user_session.get_pub_key().to_string() }, tracker: tracker }).await;
     } else {

         let user_search: Option<User> =  sqlx::query_as!(
        User, 
        r#"
            SELECT 
               id, username, password_hash, pub_key, profile_pics, created_at, updated_at, name, last_key as "last_key: LastKeys", chats, deleted_at      
            FROM users 
            WHERE username = $1
            "#,
            other_username
        )
        .fetch_optional(&state.pgpool)
        .await
        .map_err(|_| {
            AppError::DatabaseError("Failed to fetch user".to_string())
        })?;

        let user: User = match user_search {
            Some(u) => { u },
            None => return Err(AppError::Unauthorized("invalid credentials".to_string()))
        }; 
        let _ = tx.send(ComposeMessage::ServerMessage{server_message: ServerMessage::StatusReplay { name: user.name, username: user.username, status: StatusNow::Offline, pub_key: user.pub_key }, tracker: tracker }).await;
     }
    }
      
 } else {
     let _ = tx.send(ComposeMessage::ServerMessage { server_message: ServerMessage::Error { message: "Something went wrong".to_string() }, tracker: tracker }).await;
   }

 Ok(())
}