use tokio::sync::mpsc::Sender;
use crate::{app_state::AppState, messages::{ServerMessage, UserMessage}, sessions::Session, utils::AppError};


pub async fn ping_handler(tx: Sender<ServerMessage>, state: AppState, message_user: UserMessage) -> Result<(), AppError> {
    
    if let UserMessage::Ping { username, unique_key} = message_user {
   
    if let Ok(user_session) = state.users_session_online.get_session(&username).await {     

       let _ = tx.send(ServerMessage::Pong).await; 
         }
      
    } else {
    let _ = tx.send(ServerMessage::Error { message: "Something went wrong".to_string() }).await;
   }

    Ok(())
}