use crate::{ app_state::AppState, messages::{ComposeMessage, server_massages::ServerMessage::{ self }, user_messages::UserMessage }, model::{message::{Message, SentMessage}, modified_message::{ EventType, ModifiedMessage} }, sessions::Session, utils::{AppError, mappers } };
use tokio::sync::mpsc::Sender;
use sqlx::QueryBuilder;
use std::sync::Arc;


pub async fn join_handler(tx: Sender<ComposeMessage>, state: Arc<AppState>, message_user: UserMessage, tracker: u64) -> Result<(), AppError> {
     
    if let UserMessage::Join { delete, edit, seen_message, last_seen, username, unique_key, sent_message_edit, new } = message_user {
      
     let state_clone = state.clone();

   if let Ok(user_session) = state_clone.users_session_online.get_session(&username.clone()).await {

    if unique_key != *user_session.get_unique_key() {
        let _ = tx.send(ComposeMessage::Error { msg: "wrong key".to_string(), tracker: 1 }).await;
        return Err(AppError::Unauthorized("wrong key".to_string()));
       }   
             
     let result_del =  tokio::spawn(async move {

     let query = format!(
        "UPDATE messages SET seen = $1, updated_at = NOW() WHERE id = ANY($2)"
    );
    
    let _ = sqlx::query(&query)
        .bind(true)
        .bind(&seen_message) 
        .execute(&state.pgpool)
        .await;

     let deleted_message: Vec<Message> = sqlx::query_as!(
          Message,
       r#"DELETE FROM messages WHERE id = ANY($1)
       RETURNING id, payload, attachment_name, attachment_type, caption, recipient, sender, seen, locale, 
       created_at, updated_at, deleted_at, pub_key"#,
       &delete  
       )
        .fetch_all(&state.pgpool)
        .await.unwrap();

        let mut qbd = QueryBuilder::new(
          "INSERT INTO modified_messages 
         (type, event_owner, is_delivered,
          message_id, event_receiver, created_at, updated_at, pub_key)"
        );
      
        qbd.push_values(deleted_message.iter(), |mut b, m| {
        b.push_bind(EventType::Delete)
        .push_bind(username.as_str())
        .push_bind(false)
        .push_bind(m.id)
        .push_bind(m.recipient.as_str())
        .push_bind(m.created_at)
        .push_bind(time::OffsetDateTime::now_utc())
        .push_bind(m.pub_key.as_str());
        });

        let _ =  qbd.build()
        .execute(&state.pgpool)
        .await;

      let edit_id: Vec<i64> = edit.iter().map(|m| m.id.unwrap_or(0)).collect();

      let _ = sqlx::query!(
      "DELETE FROM messages WHERE id = ANY($1)",
       &edit_id
     )
      .execute(&state.pgpool)
       .await;

       let mut qbe = QueryBuilder::new(
          "INSERT INTO modified_messages 
         (modification_type, payload, attachments, caption, event_owner, is_delivered,
          message_id, event_receiver, created_at, updated_at, pub_key)"
        );

        let edit_ref: Vec<&Message> = edit.iter().map(|m| m).collect();

      qbe.push_values(edit_ref.iter(), |mut b, m| {
        b.push_bind(EventType::Edit)
        .push_bind(m.payload.as_ref())
        .push_bind(m.attachment_name.as_ref())
        .push_bind(m.attachment_type.as_ref())
        .push_bind(m.caption.as_ref())
        .push_bind(username.as_str())
        .push_bind(false)
        .push_bind(m.id)
        .push_bind(m.recipient.as_str())
        .push_bind(m.created_at)
        .push_bind(time::OffsetDateTime::now_utc())
        .push_bind(m.pub_key.as_str());
        });
        
       let _ = qbe.build()
        .execute(&state.pgpool)
        .await;

      let mut qbse = QueryBuilder::new(
          "INSERT OR REPLACE INTO sent_message (id, message_id, payload, attachment_name, attachment_type, caption)"
      );

      let sent_ref: Vec<&SentMessage> = sent_message_edit.iter().map(|m| m).collect();

      qbse.push_values(sent_ref, |mut b, s| {
        b.push_bind(s.id)
        .push_bind(s.message_id)
        .push_bind(s.payload.clone())
        .push_bind(s.attachment_name.clone())
        .push_bind(s.attachment_type.clone())
        .push_bind(s.caption.clone());
      });

      let _ = qbse.build()
           .execute(&state.pgpool)
           .await;

      let mut qbn = QueryBuilder::new(
        "INSERT INTO messages (payload, attachments, caption, recipient, sender, seen, pub_key, locale, created_at, updated_at)"
      );

      let new_ref: Vec<&Message> = new.iter().map(|t| &t.0).collect();

      qbn.push_values(new_ref.iter(), |mut b, n| {
        b.push_bind(n.payload.clone())
        .push_bind(n.attachment_name.clone())
        .push_bind(n.attachment_type.clone())
        .push_bind(n.caption.clone())
        .push_bind(n.recipient.clone())
        .push_bind(n.sender.clone())
        .push_bind(n.seen.clone())
        .push_bind(n.pub_key.clone())
        .push_bind(n.locale.clone())
        .push_bind(n.created_at.clone())
        .push_bind(n.updated_at.clone());
      });

      qbn.push("RETURNING id payload, attachments, caption, recipient, sender, seen, pub_key, locale, created_at, updated_at");

      let new_messages = qbn.build_query_as::<Message>()
           .fetch_all(&state.pgpool)
           .await.unwrap();

      let mut sent_ref: Vec<Option<SentMessage>> = new.into_iter().map(|t| t.1).collect();

      for i in 0..sent_ref.len() {
        if sent_ref[i as usize].is_some() {
            sent_ref[i as usize].as_mut().unwrap().message_id = new_messages[i as usize].id.clone().unwrap();
        }
      }
    
      let mut qbs = QueryBuilder::new(
        "INSERT INTO sent_message (message_id, payload, attachment_name, attachment_type, caption)"
      );

      qbs.push_values(sent_ref.into_iter().flatten(), |mut b, s| {
        b.push_bind(s.message_id)
         .push_bind(s.payload)
         .push_bind(s.attachment_name)
         .push_bind(s.attachment_type)
         .push_bind(s.caption);
      });

      qbs.push("RETURNING id, message_id, payload, attachment_name, attachment_type, caption");

      let new_sent = qbs.build_query_as::<SentMessage>()
      .fetch_all(&state.pgpool).await.unwrap();

     let seen_query = format!(
        "UPDATE messages SET seen = $1, updated_at = NOW() WHERE id = ANY($2)"
    );
    
    let _ = sqlx::query(&seen_query)
        .bind(true)
        .bind(&seen_message) 
        .execute(&state.pgpool)
        .await;

        let new = sqlx::query_as!(
            Message,
            r#"
        SELECT
        id,
        payload,
        attachment_name,
        attachment_type,
        caption,
        recipient,
        sender,
        seen,
        locale,
        created_at,
        updated_at,
        deleted_at,
        pub_key
        FROM messages
        WHERE recipient = $1
        AND created_at >= $2
            "#,
            &username,
            time::OffsetDateTime::from_unix_timestamp(last_seen).unwrap()
          )
          .fetch_all(&state.pgpool)
          .await.unwrap();


        let new_events = sqlx::query_as!(
          ModifiedMessage, 
          r#"
          SELECT 
          id,
          modification_type as "event_type: EventType" ,
          payload,
          attachment_name,
          attachment_type,
          caption, 
          event_owner, 
          is_delivered,
          message_id, event_receiver, 
          created_at, updated_at, pub_key 
          FROM modified_messages
          WHERE event_receiver = $1 AND 
          updated_at >= $2
          "#,
         &username, 
         time::OffsetDateTime::from_unix_timestamp(last_seen).unwrap()
        )
         .fetch_all(&state.pgpool)
          .await;

         let mut delete_list = vec![];
         let mut edit_list = vec![];

         let edit_list_new = new_events.unwrap();

    for e in &edit_list_new {
      if e.event_type == EventType::Delete {
        delete_list.push(e.message_id);
      } else {
        edit_list.push(e.clone())
      }
    }

    

    let mut edit_id_update = vec![];

    for m in &edit_list_new {
      edit_id_update.push(m.id.unwrap());
    }

     let _ = sqlx::query!(
        "UPDATE modified_messages SET is_delivered = $1, updated_at = NOW() WHERE id = ANY($2)",
        true,
        &edit_id_update  
       )
        .execute(&state.pgpool);

    let new_edit_messages = mappers::map_event_to_message(&edit_list);  

    tx.send(ComposeMessage::ServerMessage { server_message: ServerMessage::JoinReplay { delete: delete_list, edit: new_edit_messages, new: new, new_message_replay: new_messages, new_sent_replay: new_sent }, tracker: tracker }).await
    }); 
  
   let _= result_del.await;
  }
    } else {
      let _ = tx.send(ComposeMessage::ServerMessage { server_message: ServerMessage::Error { message: "Something went wrong".to_string() }, tracker: tracker });
   }
    Ok(())
}



