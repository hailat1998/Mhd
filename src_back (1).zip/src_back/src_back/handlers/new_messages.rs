use time::{Duration, OffsetDateTime};
use tokio::sync::mpsc::Sender;
use crate::{app_state::AppState, messages::{ServerMessage, UserMessage}, model::modified_message, sessions::Session, utils::AppError};
use std::sync::Arc;
use crate::utils::mappers::map_event_to_message;
use crate::model::ModifiedMessage;
use crate::model::EventType;
use crate::model::Message;
use crate::ComposeMessage;

pub async fn next_messages_handler(tx: Sender<ComposeMessage>, state: Arc<AppState>, message_user: UserMessage, tracker: u64) -> Result<(), AppError> {

    if let UserMessage::NextMessages { starting_from, unique_key, username } = message_user {
        
       if let Ok(user_session) = state.users_session_online.get_session(&username).await { 

        if unique_key != *user_session.get_unique_key() {
         let _ = tx.send(ComposeMessage::Error { msg: "wrong key".to_string(), tracker: 1 }).await;
         return Err(AppError::Unauthorized("wrong key".to_string()));
         }  

        let mut  messages_earlier = sqlx::query_as!(
            Message, 
            r#"SELECT * FROM messages WHERE (sender = $1 OR recipient = $1)AND created_at >= $2 AND created_at <= $3"#,
            &username,
            &starting_from.saturating_sub(Duration::days(180)),
            &starting_from
         )
        .fetch_all(&state.pgpool)
        .await.unwrap();

        let modified_messages_earlier = sqlx::query_as!(
         ModifiedMessage,
         r#"SELECT   id,
          modification_type as "event_type: EventType" ,
          payload,
          attachment_name,
          attachment_type,
          caption, 
          event_owner, 
          is_delivered,
          message_id, event_receiver, 
          created_at, updated_at, pub_key  FROM modified_messages WHERE (event_owner = $1 OR event_receiver = $1) AND created_at >= $2 AND created_at <= $3"#,
           &username,
           &starting_from.saturating_sub(Duration::days(180)),
           &starting_from
        ).fetch_all(&state.pgpool)
        .await.unwrap();

       let mod_message = map_event_to_message(&modified_messages_earlier);

       for m in &mod_message {
         messages_earlier.push(m.clone());
       }
        
        let _ = tx.send(ComposeMessage::ServerMessage { server_message: ServerMessage::NextMessagesReplay { messages: messages_earlier }, tracker: tracker }).await;
     }
    } else {
          let _ = tx.send(ComposeMessage::ServerMessage { server_message: ServerMessage::Error { message: "Something went wrong".to_string() }, tracker: tracker });
    }

  Ok(())
}