pub mod redis_cache_manager;

use std::fmt::Display;
use serde::{ Serialize, de::DeserializeOwned };
use async_trait::async_trait;

use crate::utils::{ AppError };


#[async_trait]
pub trait CacheManager<K, V>
where
    K: Display + Send + Sync + ?Sized,
    V: Serialize + DeserializeOwned + Send + Sync,
{
   async fn save(&self, key: &K, value: &V) -> Result<(), AppError>;
   async fn get(&self, key: &K) -> Result<Option<V>, AppError>;
   async fn update(&self, key: &K, value: &V) -> Result<(), AppError>;
   async fn remove(&self, key: &K) -> Result<(), AppError>;
}



