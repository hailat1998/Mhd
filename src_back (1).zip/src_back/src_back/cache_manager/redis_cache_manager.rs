use redis::{AsyncCommands, Client as RedisClient};
use std::fmt::Display;
use serde::{Serialize, de::DeserializeOwned};
use async_trait::async_trait;
use redis::ToRedisArgs;
use redis::FromRedisValue;

use crate::cache_manager::CacheManager;

use crate::utils::{AppError, redis_connect::get_redis_conn};

pub struct RedisCacheManager<K, V>
where
    K: Display + ?Sized,  
{
    client: RedisClient,
    _marker: std::marker::PhantomData<(fn() -> K, fn() -> V)>,  
}

impl<K, V> RedisCacheManager<K, V>
where
    K: Display + ?Sized,
{
    pub fn new(client: RedisClient) -> Self {
        Self {
            client,
            _marker: std::marker::PhantomData,
        }
    }
}

#[async_trait]
impl<K, V> CacheManager<K, V> for RedisCacheManager<K, V>
where
    K: Display + Send + Sync + ?Sized,
    V: Serialize + DeserializeOwned + Send + Sync ,
{
    async fn save(&self, key: &K, value: &V) -> Result<(), AppError> {
        let mut conn = get_redis_conn(&self.client).await?;

        let redis_key = key.to_string();
        let serialized = serde_json::to_string(value)  
            .map_err(|e| AppError::SerializationError(e.to_string()))?;

        let _: () = conn.set(redis_key, serialized).await
            .map_err(|e| AppError::Redis(e))?;

        Ok(())
    }

    async fn get(&self, key: &K) -> Result<Option<V>, AppError> {
        let mut conn = get_redis_conn(&self.client).await?;

        let redis_key = key.to_string();

        let result: Option<String> = conn.get(redis_key).await
            .map_err(|e| AppError::Redis(e))?;

        match result {
            Some(data) => {
                let deserialized = serde_json::from_str(&data)
                    .map_err(|e| AppError::SerializationError(e.to_string()))?;
                Ok(Some(deserialized))
            }
            None => Ok(None),
        }
    }

    async fn update(&self, key: &K, value: &V) -> Result<(), AppError> {
        self.save(key, value).await
    }

    async fn remove(&self, key: &K) -> Result<(), AppError> {
        let mut conn = get_redis_conn(&self.client).await?;

        let redis_key = key.to_string();

        let _: () = conn.del(&redis_key).await
            .map_err(|e| AppError::Redis(e))?;

        Ok(())
    }

  
}

impl<K, V> RedisCacheManager<K, V>
where
    K: Display + Send + Sync + ?Sized,
    V: Serialize + DeserializeOwned + Send + Sync + ToRedisArgs + FromRedisValue ,
{
   pub async fn read_range(&self, key: &K) -> Result<Option<Vec<V>>, AppError> {
        let mut conn = get_redis_conn(&self.client).await?;
        
        let redis_key = key.to_string();
        
        let result: Vec<V> = conn.lrange(&redis_key, 0, -1).await?;
        
        if result.is_empty() {
            return Ok(None);
        }
            
        Ok(Some(result))
    }

  pub async fn push_r(&self, key: &K, value: &V) -> Result<(), AppError> 
    where
        V: ToRedisArgs, 
    {
        let mut conn = get_redis_conn(&self.client).await?;

        let redis_key = key.to_string();

       
        let _: isize = conn.rpush(redis_key, value).await
            .map_err(|e| AppError::Redis(e))?;

        Ok(())
    }
}