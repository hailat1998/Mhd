use crate::{app_state::AppState, model::{LastKeys, session::SessionGlobal, user::{CreateUser, User, UserResponse}}, utils::{ AppError, encryption::{generate_32_bytes, bytes_to_base64 }, password::hash_password, } };
use axum::{ extract::{ State }, Json};
use time:: { OffsetDateTime, Duration };
use std::sync::Arc;

pub async fn sign_up(
   State(state): State<Arc<AppState>>,
   axum::extract::Json(signup_credentials): axum::extract::Json<CreateUser>
) -> Result<Json<UserResponse>, AppError>{
     if signup_credentials.device_id.is_empty() || signup_credentials.password.is_empty() || signup_credentials.username.is_empty() || signup_credentials.pub_key.is_empty() || signup_credentials.name.is_empty() {
         return Err(AppError::bad_request("Unset field"));
     }
      
     let password_hash = match hash_password(signup_credentials.password.as_str()) {
        Ok(p) => { p },
        Err(_e) => {
            return Err(AppError::bad_request(""))
        }
     };   

      let installation_id = format!("{}_{}", signup_credentials.username.clone(), uuid::Uuid::new_v4().to_string());      

    let new_session = SessionGlobal {
            id:None,
            device_id: signup_credentials.device_id,
            username: signup_credentials.username.clone(),
            installation_id: installation_id.clone(),
            seen_date: OffsetDateTime::now_utc(),
            created_at: OffsetDateTime::now_utc(),
            deleted_at: None,
            os_name: signup_credentials.os_name
     }; 

     let _ = sqlx::query_as!(
        SessionGlobal,
        r#"
        INSERT INTO sessions (device_id, username, installation_id, seen_date, created_at, deleted_at, os_name)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING id, device_id, username, installation_id, seen_date, created_at, deleted_at, os_name
        "#,
        new_session.device_id,
        new_session.username,
        new_session.installation_id,
        new_session.seen_date,
        new_session.created_at,
        new_session.deleted_at,
        new_session.os_name       
    )
    .fetch_one(&state.pgpool)
    .await
    .map_err(|_| AppError::database("Failed to create session"))?;

    let byte_32: [u8; 32] = generate_32_bytes();

    let base_64_string_1 = bytes_to_base64(&byte_32);


    let base_64_string_2 = bytes_to_base64(&byte_32);

      let user = User {
        id: None,
        username: signup_credentials.username.clone(),
        password_hash: password_hash,
        pub_key: signup_credentials.pub_key,
        profile_pics: None,
        created_at: OffsetDateTime::now_utc(),
        updated_at: OffsetDateTime::now_utc(),
        name: signup_credentials.name.clone(),
        last_key: LastKeys { old: base_64_string_1, new: base_64_string_2.clone() },
        chats: Vec::new(),
        deleted_at: None
     };

    let _ = sqlx::query!(         
        "
        INSERT INTO users (username, password_hash, pub_key, created_at, updated_at, name, last_key)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING id, username, password_hash, pub_key, profile_pics, created_at, updated_at, name, last_key
        ",
     user.username,
     user.password_hash,
     user.pub_key,
     user.created_at,
     user.updated_at,
     user.name,
     user.last_key     
    )
    // .bind(user.username)
    // .bind(user.password_hash)
    // .bind(user.pub_key)
    // .bind(user.created_at)
    // .bind(user.updated_at)
    // .bind(user.name)
    // .bind(user.last_key)
    .fetch_one(&state.pgpool)
    .await
    .map_err(|_| AppError::database("Failed to create session"))?;

    Ok(Json(UserResponse { installation_id: installation_id, base_64_string: base_64_string_2, name: signup_credentials.name}))
}

        
       
       
       
