use crate::{app_state::AppState, model::{session::{ SessionGlobal }, user::{LoginUser, User, UserResponse}, LastKeys}, utils::{AppError, encryption::{ generate_32_bytes, bytes_to_base64}}, utils::password::{ verify_password }};
use axum::{ Json, extract::{ State } };
use time:: { OffsetDateTime, Duration };
use std::sync::Arc;

pub async fn login(
    State(state): State<Arc<AppState>>,
    axum::extract::Json(login_credentials):  axum::extract::Json<LoginUser>
) -> Result<Json<UserResponse>, AppError> {
    
    if login_credentials.device_id.is_empty() || login_credentials.password.is_empty() || login_credentials.username.is_empty() {
        return Err(AppError::bad_request("Unset field"));
    }
 
       let user_search: Option<User> =  sqlx::query_as!(
        User, 
        r#"
            SELECT 
              id, username, password_hash, pub_key, profile_pics, created_at, updated_at, name, last_key as "last_key: LastKeys", chats, deleted_at
            FROM users 
            WHERE username = $1
            "#,
            login_credentials.username
        )
        .fetch_optional(&state.pgpool)
        .await
        .map_err(|_| {
            AppError::database("Failed to fetch user".to_string())
        })?;

        let user: User = match user_search {
            Some(u) => { u },
            None => return Err(AppError::Unauthorized("invalid credentials".to_string()))
        };

      let password_hash = user.password_hash;

     let valid = verify_password(login_credentials.password.as_str(), &password_hash).map_err(|_| AppError::unauthorized("invalid credentials"))?;

     if !valid {
        return Err(AppError::unauthorized("invalid credentials"));
     }

     let installation_id = format!("{}_{}", login_credentials.username.clone(), uuid::Uuid::new_v4().to_string());

     let new_session = SessionGlobal {
            id:None,
            device_id: login_credentials.device_id,
            username: login_credentials.username.clone(),
            installation_id: installation_id.clone(),
            seen_date: OffsetDateTime::now_utc(),
            created_at: OffsetDateTime::now_utc(),
            deleted_at: None,
            os_name: login_credentials.os_name
     }; 

     let _ = sqlx::query_as!(
        SessionGlobal,
        r#"
        INSERT INTO sessions (device_id, username, installation_id, seen_date, created_at, deleted_at, os_name)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING id, device_id, username, installation_id, seen_date, created_at, deleted_at, os_name
        "#,
        new_session.device_id,
        new_session.username,
        new_session.installation_id,
        new_session.seen_date,
        new_session.created_at,
        new_session.deleted_at,
        new_session.os_name
    )
    .fetch_one(&state.pgpool)
    .await
    .map_err(|_| AppError::database("Failed to create session"))?;

    let byte_32: [u8; 32] = generate_32_bytes();

    let base_64_string = bytes_to_base64(&byte_32);


     let query = format!(
        "UPDATE users SET last_key = $1, updated_at = NOW() WHERE username = $2"
    );

    let keys = LastKeys{ old: user.last_key.new, new: base_64_string.clone()};
    
    let _ = sqlx::query!(
         "UPDATE users SET last_key = $1, updated_at = NOW() WHERE username = $2",
         &keys,
         &user.username
         )
//        .bind(&keys)
//        .bind(&user.username) 
        .execute(&state.pgpool)
        .await;
      

    Ok(Json(UserResponse { installation_id: installation_id, base_64_string: base_64_string, name: user.name }))
}