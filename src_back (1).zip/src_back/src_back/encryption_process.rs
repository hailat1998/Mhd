use rayon::{ThreadPool, ThreadPoolBuilder};
use tokio::sync::mpsc::Receiver;
use tokio::sync::oneshot;
use std::sync::Arc;
use crate::utils::encryption::{ encrypt_string, decrypt_string };

pub struct EncryptorDecryptor {
    pool: Arc<ThreadPool>,
}

impl EncryptorDecryptor {
    pub fn new() -> Self {
        Self {
            pool: Arc::new(
                ThreadPoolBuilder::new()
                    .num_threads(num_cpus::get() / 2)
                    .build()
                    .unwrap()
            ),
        }
    }
    
    pub async fn encryption_process(
        &self,
        mut rx_encr: Receiver<([u8; 32], String, [u8; 12], oneshot::Sender<String>)>
    ) {
        while let Some((arg1, arg2, arg3, tx)) = rx_encr.recv().await {
            let pool = self.pool.clone();
            
            pool.spawn(move || {
                let result = encrypt_string(&arg1, arg2.as_str(), &arg3);
                 match result {
                    Ok(r) => { let _ = tx.send(r); },
                    Err(_) => { let _ = tx.send("Failed To encrypt".to_string()); }
                } 
            });
        }
    }

    pub async fn decryption_process(
         &self,
        mut rx_decr: Receiver<([u8; 32], String, [u8; 12], oneshot::Sender<String>)>
    ) {
        while let Some((arg1, arg2, arg3, tx)) = rx_decr.recv().await {
            let pool = self.pool.clone();
            
            pool.spawn(move || {
                let result = decrypt_string(&arg1, arg2.as_str(), &arg3);
                match result {
                    Ok(r) => { let _ = tx.send(r); },
                    Err(_) => { let _ = tx.send("Failed To decrypt".to_string()); }
                }               
            });
        }
    }
}