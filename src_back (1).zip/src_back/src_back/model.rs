pub mod user;
pub mod session;
pub mod modified_message;
pub mod message;

use serde::{Deserialize, Serialize};

use sqlx::{ Type };

pub use user::{ User };
pub use session::SessionGlobal;
pub use modified_message::ModifiedMessage;
pub use modified_message::EventType;
pub use message::Message;

#[derive(Debug, Type, Serialize, Deserialize, Clone)]
#[sqlx(type_name = "file_type")] 
pub struct FileType {
    pub name: String,
    pub type_of_file: String,
}

#[derive(Debug, Type, Serialize, Deserialize, Clone)]
#[sqlx(type_name = "key_pair")] 
pub struct LastKeys{ 
    pub old: String,
    pub new: String
}
