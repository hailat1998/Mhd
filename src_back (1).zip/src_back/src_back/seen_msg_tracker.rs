use crate::{AppState, app_state, cache_manager::CacheManager};
use crate::utils::AppError;
use std::sync::Arc;

pub async fn write_seen_to_DB(state: Arc<AppState>) -> Result<(), AppError> {
    let seen = state.message_seen_tracker.read_range(&app_state::MESSAGE_SEEN_TRACKER.to_string()).await;

   match seen {
    Ok(list) => {
        let available = match list {
            Some(N) => { N },
            None => { Vec::new() }
        };

   
    let _ = sqlx::query!(
        "UPDATE messages SET seen = $1, updated_at = NOW() WHERE id = ANY($2)",
        true,
        &available   
    )
        .execute(&state.pgpool);

    let _ = state.message_seen_tracker.remove(&app_state::MESSAGE_SEEN_TRACKER.to_string()).await;
        
    },
    Err(_) => {
        return Err(AppError::Unexpected);
    }
   }

    Ok(())
} 