mod model;
mod db;
mod messages;
mod sessions;
mod cache_manager;
mod utils;
mod app_state;
mod auth;
mod handlers;
mod encryption_process;
mod seen_msg_tracker;

use axum::extract::WebSocketUpgrade;
use axum::extract::State;
use axum::extract::ws::Message;
use axum::response::IntoResponse;
use app_state::AppState;
use axum::extract::ws::WebSocket;
use dashmap::DashMap;
use futures::SinkExt;
use futures::StreamExt;
use time::OffsetDateTime;
use tokio::sync::mpsc;
use tokio::sync::oneshot;
use std::sync::Arc;
use tokio::sync::{OnceCell, Notify};
use dotenvy::from_filename;
use std::env;
use redis::{ Client as RedisClient };
use tokio::sync::mpsc::Sender;
use tokio::time:: {sleep, Duration};
use axum::Router;
use axum::routing::{post, get};


use crate::cache_manager::CacheManager;
use crate::cache_manager::redis_cache_manager::RedisCacheManager;
use crate::db::create_db_conn;
use crate::encryption_process::EncryptorDecryptor;
use crate::handlers::auth_handler::delete_handler::delete_account_handle;
use crate::handlers::auth_handler::logout_handler::logout_handler;
use crate::handlers::auth_handler::sessions_handler::sessions_handler;
use crate::handlers::edit_handler;
use crate::handlers::join_handler;
use crate::handlers::message_handler::sent_message::sent_message_handler;
use crate::handlers::new_messages::next_messages_handler;
use crate::handlers::profile_handler;
use crate::handlers::profile_pic_handler;
use crate::handlers::search_handler;
use crate::handlers::status_handler;
use crate::handlers::send_handler;
use crate::handlers::delete_handler;
use crate::messages::ServerMessage;
use crate::messages::UserMessage;
use crate::sessions::Session;
use crate::sessions::SessionManager;
use crate::sessions::{last_seen::LastSeenSession, user_session::UserSession};
use crate::utils::{ bytes_to_base64, generate_32_bytes, generate_12_bytes, base64_to_array, hash_to_0_9, hash_string};
use crate::utils::time_aware_lru::TimeAwareLru;
use crate::messages::ComposeMessage;
use crate::seen_msg_tracker::write_seen_to_DB;
use crate::auth::{login::login, sign_up::sign_up};
use crate::model::{User, SessionGlobal, LastKeys };

pub async fn create_app() {

    from_filename("backend/.env").ok();

    let redis_addr = env::var("REDIS_ADDR").unwrap();

    let db_url = env::var("DATABASE_URL").unwrap();

    let redis_client = RedisClient::open(redis_addr)
        .expect("Failed to connect to Redis");

    let usersession_cache_manager: RedisCacheManager<String, UserSession> = RedisCacheManager::new(redis_client.clone());

    let users_session_online = SessionManager::new(Box::new(usersession_cache_manager), sessions::SessionIdentifier::Online);

    let lastseen_cache_manager: RedisCacheManager<String, LastSeenSession> = RedisCacheManager::new(redis_client.clone());

    let users_session_last_seen = SessionManager::new(Box::new(lastseen_cache_manager), sessions::SessionIdentifier::Online);

    let message_seen_tracker: RedisCacheManager<String, i64> = RedisCacheManager::new(redis_client.clone());

    let username_hashes: RedisCacheManager<String, String> = RedisCacheManager::new(redis_client.clone()); 

    let mut online_user_handle: Vec<DashMap<String, Sender<ComposeMessage>>> = vec![];

    for _ in 0..=9 {
        online_user_handle.push(DashMap::new());
    } 
 
    let (encryption_tx, encryption_rx) = mpsc::channel::<([u8; 32], String, [u8; 12], oneshot::Sender<String>)> (100);

    let (decryption_tx, decryption_rx) = mpsc::channel::<([u8; 32], String, [u8; 12], oneshot::Sender<String>)> (100);

    let pgpool = create_db_conn(&db_url).await;

    let mut sender_user_status = vec![];
    let mut receivers_user_status = vec![];

    for _ in 0..=9 {
        let (tx, rx) = mpsc::channel::<String>(100);
        sender_user_status.push(tx);
        receivers_user_status.push(rx);
    }

    let app_state = Arc::new(AppState {
        users_session_online: Arc::new(users_session_online),
        users_session_last_seen: Arc::new(users_session_last_seen),
        message_seen_tracker: Arc::new(message_seen_tracker),
        online_channels: Arc::new(online_user_handle),
        encryption_decryption_channels: (encryption_tx, decryption_tx),
        pgpool: pgpool,
        online_status_senders: Arc::new(sender_user_status),
        username_hashes: Arc::new(username_hashes)
    });

    let app_state_clone = app_state.clone();

    let seen_tracker_task = tokio::spawn(async move {
        let mut run_fast = true;
       
        loop {
            let clone_here = app_state_clone.clone();
            if run_fast {
             let _ = write_seen_to_DB(clone_here).await;
            } else {
                sleep(Duration::from_secs(60)).await;
            }
            run_fast = !run_fast; 
        }
     });

     let app_state_clone2 = app_state.clone();

    let online_status_task = tokio::spawn(async move { 
        handle_online_status(receivers_user_status, app_state_clone2).await;
        } 
    );

    let encryption_process = Arc::new(EncryptorDecryptor::new());

    let encryption_process_clone = encryption_process.clone();

    let encryption_process_task = tokio::spawn(async move {        
        encryption_process_clone.encryption_process(encryption_rx).await;
    });

    let encryption_process_clone2 = encryption_process.clone();

     let decryption_process_task = tokio::spawn(async move {
        encryption_process_clone2.decryption_process(decryption_rx).await;
    });

     let app_state_clone3 = app_state.clone();

     let app = Router::new()
               .route("/login", post(login))
               .route("/signup", post(sign_up))
               .route("/live", get(ws_handler))
               .with_state(app_state_clone3);

     let addr = tokio::net::TcpListener::bind("127.0.0.1:3000").await.unwrap();  // Have not changed yet.

     let app_start = axum::serve(addr, app.into_make_service());
    
     tokio::select! {
        _ = seen_tracker_task => { println!("seen tracker stopped")},
        _ = online_status_task => { println!("online status stopped")},
        _ = encryption_process_task => { println!("encryption stopped")},
        _ = decryption_process_task => { println!("decryption stopped")},
        _ = app_start => { println!("app stopped")}
     }

}


async fn ws_handler(
    ws: WebSocketUpgrade,
    State(state): State<Arc<AppState>>,
) -> impl IntoResponse {
    ws.on_upgrade(move |socket| handle_socket(socket, state))
}
 
async fn handle_socket(socket: WebSocket, state: Arc<AppState>) {
       let (mut sender, mut receiver) = socket.split();

       let (tx, mut rx) = mpsc::channel::<ComposeMessage>(5);

       static USERNAME: OnceCell<String> = OnceCell::const_new();
       static NEW_KEY: OnceCell<[u8; 32]> = OnceCell::const_new();
       static OLD_KEY: OnceCell<[u8; 32]> = OnceCell::const_new();
       static UNIQUE_KEY: OnceCell<String> = OnceCell::const_new();
       static READY: Notify = Notify::const_new();
       let state_clone_task1 = state.clone();

       let mut first_message = true;
      
     let receiver_task = tokio::spawn(async move {

        let mut user_sender_set = false ;  

        while let Some(Ok(msg)) = receiver.next().await {          
            if let Message::Text(text) = msg {

               let parsed_message: ComposeMessage = serde_json::from_str(&text).unwrap();

                if let ComposeMessage::UserMessageCompose { key, username, installation_id, user_message, tracker } = parsed_message {
                    
                    let state_clone=  state_clone_task1.clone();                                 

                    if !user_sender_set {
                        let tx_sender_clone = tx.clone();

                        state_clone.online_channels[hash_to_0_9(&username) as usize].insert(username.clone(), tx_sender_clone);

                        let username_hash = hash_string(&username);

                        let _ = state_clone.username_hashes.save(&username_hash, &username).await;
                        
                        user_sender_set = true;
                    }

                  if UNIQUE_KEY.get().is_none() {                  

                   let unique_key = format!("{}_{}", username.clone(), uuid::Uuid::new_v4());

                    UNIQUE_KEY.set(unique_key).unwrap();
                  }
                                      
                    if let Ok(se_on) = state_clone.users_session_online.get_session(&username).await {
                                                
                        if installation_id != se_on.get_installation_id().to_string() || UNIQUE_KEY.get().unwrap() != se_on.get_unique_key() {
                            state_clone.online_channels[hash_to_0_9(&username) as usize].remove(&username);
                            return 
                        }                        

                        first_message = false;                                         
                        
                    } else {

                           first_message = true;

                           let user_search: Option<User> =  sqlx::query_as!(
                            User, 
                            r#"
                                SELECT 
                                 id, username, password_hash, pub_key, profile_pics, created_at, updated_at, name, last_key as "last_key: LastKeys", chats, deleted_at
                                FROM users 
                                WHERE username = $1
                                "#,
                                &username
                            )
                            .fetch_optional(&state_clone.pgpool)
                            .await.unwrap(); 

                        if user_search.is_none() || user_search.as_ref().unwrap().deleted_at.is_some_and(|u| u <= OffsetDateTime::now_utc()) {
                             state_clone.online_channels[hash_to_0_9(&username) as usize].remove(&username);
                            return;
                        }                          

                            let user: User = user_search.unwrap();                            
                             
                            let user_previous_key = base64_to_array(&user.last_key.new).unwrap();

                            let session_global_result = sqlx::query_as!(                          
                            SessionGlobal,
                            r#"
                            SELECT * FROM sessions WHERE installation_id = $1 AND seen_date >= NOW() - INTERVAL '1 month'
                            "#,
                            installation_id.clone()
                            ).fetch_optional(&state_clone.pgpool).await;

                            if session_global_result.unwrap().is_none() {    
                            let _ = tx.send(ComposeMessage::Error { msg: "Expired or unavailable Session.".to_string(), tracker: 1 });               
                                }                             

                           let _ = sqlx::query!(
                                "UPDATE sessions SET seen_date = NOW() WHERE installation_id = $1 ",
                                 installation_id.clone()
                            ).execute(&state_clone.pgpool).await;                                             
                            
                            let byte_32: [u8; 32] = generate_32_bytes();

                            let byte_12: [u8; 12] = generate_12_bytes();

                            let base_64_string = bytes_to_base64(&byte_32);

                            let base_64_string_12 = bytes_to_base64(&byte_12);

                             let query = format!(
                                "UPDATE users SET last_key = $1, updated_at = NOW() WHERE username = $2"
                               );

                            let keys = LastKeys{ old: user.last_key.new.clone(), new: base_64_string.clone()};

                            let _ = sqlx::query(&query)
                                .bind(&keys)
                                .bind(&user.username) 
                                .execute(&state_clone.pgpool)
                                .await;
                            

                           let user_session = UserSession {
                            installation_id: installation_id.clone(),
                            username: username.clone(),
                            pub_key: user.pub_key,
                            unique_key: UNIQUE_KEY.get().unwrap().clone(),
                            connected_at: time::OffsetDateTime::now_utc().unix_timestamp(),
                            name: user.name,
                            profile_pics:user.profile_pics.unwrap_or(Vec::new()),
                            last_key: base_64_string.clone(),
                            chats: user.chats.clone()
                            };

                            let _ = state_clone.users_session_online.save_session(&user_session);

                             USERNAME.set(username.clone()).unwrap();
                             NEW_KEY.set(byte_32).unwrap();
                             OLD_KEY.set(user_previous_key).unwrap();
                             READY.notify_waiters(); 

                            let welcome = ServerMessage::Welcome { unique_key: UNIQUE_KEY.get().unwrap().clone(), base_64_string: base_64_string };

                            let string_form = serde_json::to_string(&welcome).unwrap();                    

                            let (one_tx, one_rx) = oneshot::channel::<String>();

                            let _ =  state_clone.encryption_decryption_channels.0.send((user_previous_key, string_form.clone(), byte_12, one_tx)).await;

                             let r = match one_rx.await {
                                  Ok(v) => { v },
                                  Err(_) => {
                                   return;
                                   }
                              };  
                              
                               if r.starts_with("Failed To encrypt") { 
                               state_clone.online_channels[hash_to_0_9(&username) as usize].remove(&username); 
                               return;
                               }

                             let _= tx.send(ComposeMessage::ServerMessageCompose { key: base_64_string_12.clone(), username: username.clone(), server_message: r, tracker: 2 }).await;  

                             let message_delivered = ComposeMessage::ServerMessage{server_message: ServerMessage::Joined { username: username.clone() }, tracker: 2};

                            for u in user.chats {
                               let clone_here = state_clone.clone();
                               let message_clone = message_delivered.clone();
                               if let Some(sender)= clone_here.online_channels[hash_to_0_9(&u) as usize].get(&u) {
                                   sender.try_send(message_clone).unwrap()
                                }
                            }
                         };  

                     if USERNAME.get().is_none() || NEW_KEY.get().is_none() || OLD_KEY.get().is_none() {
                         READY.notified().await;
                            }          
                                     
                    if user_message == "ping".to_string() {
                        let hash = hash_to_0_9(&username);
                        let _= state_clone.online_status_senders[hash as usize].send(username.clone()).await;
                        let _= tx.send(ComposeMessage::ServerMessageCompose { key: "".to_string(), username: username.clone(), server_message: "pong".to_string(), tracker: 2 }).await;
                        continue;
                    }                

                   let (one_tx, one_rx) = oneshot::channel::<String>();

                   let nonce_ar = base64_to_array::<12>(key.as_str()).unwrap();                   
                   
                   let _ =  state_clone.encryption_decryption_channels.1.send((if first_message { OLD_KEY.get().unwrap().clone() } else { NEW_KEY.get().unwrap().clone() }, user_message.clone(), nonce_ar, one_tx));    

                    let mut  r = match one_rx.await {
                             Ok(v) => { v },
                             Err(_) => {
                               state_clone.online_channels[hash_to_0_9(&username) as usize].remove(&username);
                               return;
                              }
                          };               

                    if r.starts_with("Failed To decrypt") {                                            

                     let (one_tx_, one_rx_) = oneshot::channel::<String>(); 
                                           
                      let nonce_ar_here = generate_12_bytes();

                      let welcome = ServerMessage::Welcome { unique_key: UNIQUE_KEY.get().unwrap().clone(), base_64_string: bytes_to_base64(NEW_KEY.get().unwrap()) };

                      let string_form = serde_json::to_string_pretty(&welcome).unwrap();

                      let _ = state_clone.encryption_decryption_channels.0.send((OLD_KEY.get().unwrap().clone(), string_form, nonce_ar_here.clone(), one_tx_));

                      let r_local = match one_rx_.await {
                        Ok(v) => { 
                            if v.starts_with("Failed To decrypt") {
                             let _ = tx.send(ComposeMessage::Error { msg: "Login again".to_string(), tracker: 1 }).await;
                                state_clone.online_channels[hash_to_0_9(&username) as usize].remove(&username);
                                tokio::time::sleep(Duration::from_secs(2)).await;
                               return;  
                            }                            
                            v 
                        },
                        Err(_) => {
                         let _ = tx.send(ComposeMessage::Error { msg: "Login again".to_string(), tracker: 1 }).await;
                           state_clone.online_channels[hash_to_0_9(&username) as usize].remove(&username);
                          tokio::time::sleep(Duration::from_secs(2)).await;
                            return;
                         }
                       };                     

                      let _ = tx.send(ComposeMessage::ServerMessageCompose { key: bytes_to_base64(&nonce_ar_here), username: username.clone(), server_message: r_local, tracker: 2}).await; 

                      let (one_tx_again, one_rx_again) = oneshot::channel::<String>(); 
                                           
                      let nonce_again = generate_12_bytes();

                      let _ =  state_clone.encryption_decryption_channels.1.send((if !first_message { OLD_KEY.get().unwrap().clone() } else { NEW_KEY.get().unwrap().clone() }, user_message.clone(), nonce_again, one_tx_again));    

                      r = match one_rx_again.await {
                             Ok(v) => { v },
                             Err(_) => {
                               state_clone.online_channels[hash_to_0_9(&username) as usize].remove(&username);
                               return;
                              }
                          }; 

                        if r.starts_with("Failed To decrypt") {
                           continue;
                         }
                       }                                                    

                   let parsed_user_massege: UserMessage = serde_json::from_str(&r).unwrap();                   

                   match parsed_user_massege {
                    UserMessage::Join { delete, edit, seen_message, last_seen, username, unique_key, sent_message_edit, new } => {
                      let tx_clone = tx.clone();
                      let state_clone_here = state_clone.clone();
                      let message = UserMessage::Join {delete: delete, edit: edit, seen_message, last_seen: last_seen, username: username, unique_key: unique_key, sent_message_edit: sent_message_edit, new: new };
                      let _ = join_handler(tx_clone, state_clone_here, message, tracker).await;
                    },
                    UserMessage::Status { username, other_username, unique_key } => {
                        let tx_clone = tx.clone();
                        let state_clone_here = state_clone.clone();
                        let message =  UserMessage::Status { username: username, other_username: other_username, unique_key: unique_key };
                        let _ = status_handler(tx_clone, state_clone_here, message, tracker).await;                        
                    },
                    UserMessage::Seen { message_id, username, unique_key } => {
                        let tx_clone = tx.clone();
                        let state_clone_here = state_clone.clone();
                        let message = UserMessage::Seen { message_id: message_id, username: username, unique_key: unique_key };
                        let _ = send_handler(tx_clone, state_clone_here, message, tracker).await;
                    },
                    UserMessage::Delete { message_id, username, other_username, unique_key } => {
                        let tx_clone = tx.clone();
                        let state_clone_here = state_clone.clone();
                        let message =  UserMessage::Delete { message_id: message_id, username: username, other_username: other_username, unique_key: unique_key };
                        let _ = delete_handler(tx_clone, state_clone_here, message, tracker).await;
                    },
                    UserMessage::Edit { message, username, unique_key } => {
                        let tx_clone = tx.clone();
                        let state_clone_here: Arc<AppState> = state_clone.clone();
                        let message = UserMessage::Edit { message: message, username: username, unique_key: unique_key };
                        let _ = edit_handler(tx_clone, state_clone_here, message, tracker).await; 
                    },
                    UserMessage::Ping { username, unique_key } => {
                       // Handled it above.  
                    },
                    UserMessage::Profile { username, other_username, unique_key } => {
                        let tx_clone = tx.clone();
                        let state_clone_here = state_clone.clone();
                        let message =  UserMessage::Profile { username: username, other_username: other_username, unique_key: unique_key };
                        let _ = profile_handler(tx_clone, state_clone_here, message, tracker).await; 
                    },
                    UserMessage::ProfilePic { action, username, unique_key } => {
                        let tx_clone = tx.clone();
                        let state_clone_here = state_clone.clone();
                        let message =  UserMessage::ProfilePic { action: action, username: username, unique_key: unique_key };
                        let _ = profile_pic_handler(tx_clone, state_clone_here, message, tracker).await; 
                    },
                    UserMessage::Search { search_kind, username, unique_key, page } => {
                        let tx_clone = tx.clone();
                        let state_clone_here = state_clone.clone();
                        let message =  UserMessage::Search { search_kind: search_kind, username: username, unique_key: unique_key, page: page };
                        let _ = search_handler(tx_clone, state_clone_here, message, tracker).await; 
                    },
                    UserMessage::Send { message, username, unique_key, sent_message } => {
                        let tx_clone = tx.clone();
                        let state_clone_here = state_clone.clone();
                        let message =  UserMessage::Send { message: message, username: username, unique_key: unique_key, sent_message };
                        let _ = send_handler(tx_clone, state_clone_here, message, tracker).await; 
                    },
                    UserMessage::NextMessages { starting_from, username, unique_key } => {
                        let tx_clone = tx.clone();
                        let state_clone_here = state_clone.clone();
                        let message = UserMessage::NextMessages { starting_from: starting_from, username: username, unique_key: unique_key };
                        let _ = next_messages_handler(tx_clone, state_clone_here, message, tracker).await;
                    },
                    UserMessage::SentMessage { message_id , username, unique_key} => {
                        let tx_clone = tx.clone();
                        let state_clone_here = state_clone.clone();
                        let message = UserMessage::SentMessage { message_id: message_id, username: username, unique_key: unique_key };
                        let _ = sent_message_handler(tx_clone, state_clone_here, message, tracker).await;
                    },
                    UserMessage::SentMessageData { sent_message , username, unique_key } => {

                    },
                    UserMessage::DeleteAccount { username, unique_key } => {
                        let tx_clone = tx.clone();
                        let state_clone_here = state_clone.clone();
                        let message = UserMessage::DeleteAccount { username: username, unique_key: unique_key };
                        let _ = delete_account_handle(tx_clone, state_clone_here, message, tracker).await;
                    },
                    UserMessage::Logout { username, unique_key } => {
                        let tx_clone = tx.clone();
                        let state_clone_here = state_clone.clone();
                        let message = UserMessage::Logout { username: username, unique_key: unique_key };
                        let _ = logout_handler(tx_clone, state_clone_here, message, tracker).await;
                    },
                    UserMessage::Sessions { username, unique_key } => {
                        let tx_clone = tx.clone();
                        let state_clone_here = state_clone.clone();
                        let message = UserMessage::Sessions { username: username, unique_key: unique_key };
                        let _ = sessions_handler(tx_clone, state_clone_here, message, tracker).await;
                    },
                     }                                  
                  }
                }
            }
        }
    
    );

    let state_clone_task2 = state.clone();

    let sender_task = tokio::spawn(async move {

        let state_clone = state_clone_task2.clone();
         
        if USERNAME.get().is_none() {
            READY.notified().await;
        }

        let username = USERNAME.get().unwrap();

        while let Some(msg) = rx.recv().await {

            let state_clone = state_clone.clone();

            match msg {
                ComposeMessage::ServerMessageCompose { key, username, server_message , tracker} => {
                 // Already encrypted, just send

                 let message = ComposeMessage::ServerMessageCompose { key: key, username: username, server_message: server_message, tracker }; 

                 let string_form = serde_json::to_string(&message).unwrap();
                 let _ = sender.send(string_form.into()).await;
                },
                ComposeMessage::ServerMessage{server_message, tracker} => {
                 let string_form = serde_json::to_string(&server_message).unwrap();
                 let (one_tx, one_rx) = oneshot::channel::<String>();     
                 let nonce = generate_12_bytes();
                 let _ = state_clone.encryption_decryption_channels.0.send((NEW_KEY.get().unwrap().clone(), string_form, nonce, one_tx));

                    let r = match one_rx.await {
                        Ok(v) => { v },
                        Err(_) => { return; }
                    };                    
                    let message = ComposeMessage::ServerMessageCompose { key: bytes_to_base64(&nonce), username: username.clone(), server_message: r, tracker };
                    let string_form = serde_json::to_string(&message).unwrap();
                    let _ = sender.send(string_form.into());                
                 },
                ComposeMessage::Error { msg, tracker } => {
                    let message = ComposeMessage::Error { msg: msg, tracker };
                    let string_form = serde_json::to_string(&message).unwrap();
                    let _ = sender.send(string_form.into()).await;
                },
                 // Leave these as they are, they are used for the opposite direction. 
                ComposeMessage::UserMessage{user_message: _ , tracker: _ } => {},
                ComposeMessage::UserMessageCompose { key: _, username: _, installation_id : _, user_message : _ , tracker : _} => {}
            }
        }    
    }
);

   tokio::select! {
    _ = receiver_task => {},
    _ = sender_task => {}
   }

}

// trackes users inactive for a while and removes form online and inserts into lastseen
async fn handle_online_status(
    rec_list: Vec<tokio::sync::mpsc::Receiver<String>>,
    state: Arc<AppState>,
) {
    let time_aware_cache_list: Vec<TimeAwareLru> = rec_list
        .into_iter()
        .map(|rx| TimeAwareLru::new(rx, 5, 20))
        .collect();

    let mut handles = Vec::with_capacity(time_aware_cache_list.len());

    for cache in time_aware_cache_list {
        let manager_online = state.users_session_online.clone();
        let manager_last_seen = state.users_session_last_seen.clone();
        let online_channels = state.online_channels.clone();
        let username_hash = state.username_hashes.clone();
        let handle = tokio::spawn(async move {
            cache
                .run(|key| {
                    let manager_online = manager_online.clone();
                    let manager_last_seen = manager_last_seen.clone();
                    let online_channels_clone = online_channels.clone();
                    let username_hash_clone = username_hash.clone();
                    async move {
                        let online_session = manager_online.get_session(&key).await.unwrap();
                        let _ = manager_online.remove_session(&key).await;
                        online_channels_clone[hash_to_0_9(&key) as usize].remove(&key);
                        let message = ComposeMessage::ServerMessage{server_message: ServerMessage::Left { username: key.to_string() }, tracker: 2};
                        let _ = username_hash_clone.remove(&key).await;

                        for u in online_session.get_chats() {
                            let message_clone = message.clone();
                              let online_channels_clone_here = online_channels_clone.clone();
                              if let Some(sender)= online_channels_clone_here[hash_to_0_9(&u) as usize].get(u) {
                                   sender.try_send(message_clone).unwrap()
                                }
                        }

                        let last_seen_session = LastSeenSession{ 
                            installation_id: online_session.get_installation_id().to_string(),
                            username: online_session.get_username().to_string(),
                            time: time::OffsetDateTime::now_utc().unix_timestamp(),
                            pub_key: online_session.get_pub_key().to_string(),
                            name: online_session.get_name().to_string(),
                            profile_pics: online_session.get_profile_pics().to_vec(),
                            last_key: online_session.get_last_key().to_string(),
                            chats: online_session.get_chats().clone()
                        };
                        let _ = manager_last_seen.save_session(&last_seen_session).await;
                    }
                })
                .await;
        });

        handles.push(handle);
    }

    for h in handles {
        let _ = h.await;
    }
}