pub mod user_session;
pub mod last_seen;

use redis::{FromRedisValue, ToRedisArgs};
use serde::{ Serialize, de::DeserializeOwned };

use crate::{ cache_manager::{ CacheManager }, utils::AppError };

pub trait Session {
    type Key;

    fn get_key(&self) -> & Self::Key;
    fn get_pub_key(&self) -> &String;
    fn get_installation_id(&self) -> &String;
    fn get_username(&self) -> &String;
    fn get_time(&self) -> i64;
    fn get_unique_key(&self) -> &String;
    fn get_name(&self) -> &String;
    fn get_profile_pics(&self) -> &Vec<String>;
    fn get_last_key(&self) -> &String;
    fn get_chats(&self) -> &Vec<String>;
}


pub struct SessionManager<S: Serialize + DeserializeOwned + Send + Sync>
where
    S: Session<Key = String>,
{
    cache_manager: Box<dyn CacheManager<String, S> + Send + Sync>,
    session_identifier: SessionIdentifier,
}

pub enum SessionIdentifier {
  Online ,
  LastSeen 
}

impl<S: Serialize + DeserializeOwned + Send + Sync> SessionManager<S>
where
    S: Session<Key = String>,
{
    pub fn new(
        cache_manager: Box<dyn CacheManager<String, S> + Send + Sync>,
        session_identifier: SessionIdentifier,
    ) -> SessionManager<S> {
        SessionManager {
            cache_manager,
            session_identifier,
        }
    }

    pub async fn save_session(&self, session: &S) -> Result<(), AppError> {

        let key = session.get_key().clone();
        self.cache_manager.save(&key, session).await?;

        Ok(())
    }

    pub async fn get_session(&self, key: &String) -> Result<impl Session<Key = String>, AppError> {
      
        let value = self.cache_manager.get(key).await
        .map_err(|e| e)?;
         
        Ok(value.unwrap())
    }

    pub async fn update_session(&self, session: &S) -> Result<(), AppError> {
    
        let key = session.get_key();
         self.cache_manager.save(&key, session).await?;

        Ok(())
    }

    pub async fn remove_session(&self, key: &String) -> Result<(), AppError> {
         self.cache_manager.remove(key).await
         .map_err(|e| e)
    }
}


 