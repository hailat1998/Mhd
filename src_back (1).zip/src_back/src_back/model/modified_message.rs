use serde::{Deserialize, Serialize};

use sqlx::{ Type, prelude::FromRow};
use time::OffsetDateTime;

#[derive(Debug, Type, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[sqlx(type_name = "event_type")]
pub enum EventType {
     #[sqlx(rename = "delete")] 
    Delete,
    #[sqlx(rename = "edit")]
    Edit
}


#[derive(Serialize, Deserialize, FromRow, Debug, Clone)]
pub struct ModifiedMessage {
pub id: Option<i64>,
pub event_type: EventType,
pub payload: Option<String>,
pub attachment_name: Option<String>,
pub attachment_type: Option<String>,
pub caption: Option<String>,
pub is_delivered: bool,
pub event_owner: String,
pub message_id: i64,
pub event_receiver: String,
pub created_at: OffsetDateTime,
pub updated_at: OffsetDateTime,
pub pub_key: String,
}

