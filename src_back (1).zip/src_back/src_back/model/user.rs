use serde::{Deserialize, Serialize};

use sqlx::{prelude::FromRow};
use time::OffsetDateTime;

use crate::model::LastKeys;

#[derive(Serialize, Deserialize, FromRow, Debug)]
pub struct User {
    pub id: Option<i64>,
    pub username: String,
    pub password_hash: String,
    pub pub_key: String,
    pub profile_pics: Option<Vec<String>>,
    pub created_at: OffsetDateTime,
    pub updated_at: OffsetDateTime,
    pub name: String,
    pub last_key: LastKeys,
    pub chats: Vec<String>,
    pub deleted_at: Option<OffsetDateTime>
}

#[derive(Serialize, Deserialize, FromRow)]
pub struct LoginUser {
    pub username: String,
    pub password: String,
    pub device_id: String,
    pub os_name: String
}

#[derive(Serialize, Deserialize, FromRow)]
pub struct CreateUser {
    pub username: String,
    pub password: String,
    pub pub_key: String,
    pub device_id: String,
    pub name: String,
    pub os_name: String
}

#[derive(Serialize, Deserialize, FromRow)]
pub struct UserResponse {
    pub installation_id: String,
    pub base_64_string: String,
    pub name: String
}
