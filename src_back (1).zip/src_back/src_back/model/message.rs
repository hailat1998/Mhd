use serde::{Deserialize, Serialize};

use sqlx::{prelude::FromRow };
use time::OffsetDateTime;

#[derive(Serialize, Deserialize, FromRow, Debug, Clone)]
pub struct Message {
    pub id: Option<i64>,
    pub payload: Option<String>,
    pub attachment_name: Option<String>,
    pub attachment_type: Option<String>,
    pub caption: Option<String>, 
    pub recipient: String,
    pub sender: String,
    pub seen: bool,
    pub pub_key: String,
    pub locale: Option<String>,
    pub created_at: OffsetDateTime,
    pub updated_at: OffsetDateTime,
    pub deleted_at: Option<OffsetDateTime>
}

#[derive(Serialize, Deserialize, FromRow, Debug, Clone)]
pub struct SentMessage {
    pub id: Option<i64>,
    pub message_id: i64,
    pub payload: Option<String>,
    pub attachment_name: Option<String>,
    pub attachment_type: Option<String>,
    pub caption: Option<String>
}

