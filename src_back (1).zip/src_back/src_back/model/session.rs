use serde::{Deserialize, Serialize};

use sqlx::{prelude::FromRow};
use time::OffsetDateTime;


#[derive(Serialize, Deserialize, FromRow)]
pub struct SessionGlobal {
    pub id: Option<i64>,
    pub device_id: String,
    pub username: String,
    pub seen_date: OffsetDateTime,
    pub installation_id: String, 
    pub created_at: OffsetDateTime,
    pub deleted_at: Option<OffsetDateTime>,
    pub os_name: String
}
