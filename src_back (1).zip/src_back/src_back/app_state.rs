use dashmap::DashMap;

use crate::messages::{ComposeMessage };
use crate::{ cache_manager::redis_cache_manager::RedisCacheManager, sessions::{ SessionManager, last_seen::LastSeenSession, user_session::UserSession }};
use tokio::sync::mpsc::{self, Sender};
use sqlx::PgPool;
use std::sync::Arc;
use tokio::sync::oneshot;

pub const MESSAGE_SEEN_TRACKER: &str = "seen_messages";

pub struct AppState {
   pub users_session_online: Arc<SessionManager<UserSession>>, // online user session
   pub users_session_last_seen: Arc<SessionManager<LastSeenSession>>, // last seen of the recent users
   pub message_seen_tracker: Arc<RedisCacheManager<String, i64>>,  // to track messages that have been seen by the recipient, frequently have to be writen to DB 
   pub online_channels: Arc<Vec<DashMap<String, Sender<ComposeMessage>>>>,  // used for inter user communication
   pub encryption_decryption_channels: (mpsc::Sender<([u8; 32], String, [u8; 12], oneshot::Sender<String>)>, mpsc::Sender<([u8; 32], String, [u8; 12], oneshot::Sender<String>)>), 
   pub pgpool: PgPool,
   pub online_status_senders: Arc<Vec<Sender<String>>>,
   pub username_hashes: Arc<RedisCacheManager<String, String>>
}