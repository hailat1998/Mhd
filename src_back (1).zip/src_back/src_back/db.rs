use std::time::Duration;
mod database_task;

use sqlx::{PgPool, postgres::PgPoolOptions};


pub async fn create_db_conn(db_url: &str) -> PgPool {
    PgPoolOptions::new()
    .max_connections(20)
    .min_connections(5)
    .idle_timeout(Duration::from_millis(30000))
    .connect(db_url)
    .await
    .expect("failed to connect to database")
}