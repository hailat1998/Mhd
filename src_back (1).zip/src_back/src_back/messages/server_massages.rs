use serde::{Serialize, Deserialize};

use crate::model::{ message::Message };
use crate::model::message::SentMessage;

#[derive(Serialize, Deserialize, Debug, Clone)]
#[serde(tag = "type", content = "server_message")]
pub enum ServerMessage {
 Welcome { unique_key: String, base_64_string: String },
 JoinReplay { delete: Vec<i64>, edit: Vec<Message>, new: Vec<Message>, new_message_replay: Vec<Message>, new_sent_replay: Vec<SentMessage> },
 StatusReplay { name: String, username: String, status: StatusNow, pub_key: String },
 Pong,
 EditReplay { message: Message, result: ResultHere },
 SendReplay { message: Message, sent_message: Option<SentMessage>, result: ResultHere },
 DeleteReplay { message_id: i64, result: ResultHere },
 ProfileReplay { pics: Vec<String>, username: String, name: String, last_seen: i64 },
 ProfilePicReplay { result: ResultHere },
 SearchReplay { result: SearchResult },
 Error {
        message: String
    },
 Joined { username: String },
 Left { username: String },
 NextMessagesReplay { messages: Vec<Message> },
 SeenReplay { message_id: i64 },
 SentMessageReplay { result: ResultHere, sent_message: Option<SentMessage>},
 SentMessageDataReplay { result: ResultHere },
 DeleteAccountReplay { result: ResultHere },
 LogoutReplay { result: ResultHere },
 SessionsReplay { sessions: Vec<ActiveSession> }
}


#[derive(Serialize, Deserialize, Debug, Clone)]
#[serde(tag = "type", content = "status")]
pub enum StatusNow {
    Online,
    Offline
}


#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct SearchResult {
   pub messages: Vec<Message>,
   pub users: Vec<UserSearch> 
}


#[derive(Serialize, Deserialize, Debug, Clone)]
#[serde(tag = "type", content = "result")]
pub enum ResultHere{
    Error, 
    Ok
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct UserSearch {
   pub username: String, 
   pub name: String
}


#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct ActiveSession {
   pub os_name: String, 
   pub device_id: String
}