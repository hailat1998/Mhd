use serde::{Serialize, Deserialize};

use crate::model::message::Message;
use time::OffsetDateTime;
use crate::model::message::SentMessage;


#[derive(Serialize, Deserialize, Debug, Clone)]
#[serde(tag = "type", content = "user_message")]
pub enum UserMessage{
    Join { delete: Vec<i64>, edit: Vec<Message>, sent_message_edit:Vec<SentMessage>, seen_message: Vec<i64>,  new: Vec<(Message, Option<SentMessage>)>, last_seen: i64, username: String, unique_key: String},
    Status { username: String, other_username: String, unique_key: String },
    Seen { message_id: i64, username: String, unique_key: String },
    Ping { username: String, unique_key: String },
    Send { message: Message, sent_message: SentMessage, username: String, unique_key: String },
    Edit { message: Message, username: String, unique_key: String },
    Delete { message_id: i64, username: String, other_username: String, unique_key: String },
    Profile { username: String, other_username: String, unique_key: String },
    ProfilePic { action: ProfilePicAction, username: String, unique_key: String },
    Search { search_kind: SearchKind, username: String, unique_key: String, page: i32 },
    NextMessages { starting_from: OffsetDateTime, username: String, unique_key: String },
    SentMessage { message_id: i64, username: String, unique_key: String},
    SentMessageData { sent_message: SentMessage, username: String, unique_key: String },
    DeleteAccount { username: String, unique_key: String },
    Logout { username: String, unique_key: String },
    Sessions { username: String, unique_key: String }
}


#[derive(Serialize, Deserialize, Debug, Clone)]
#[serde(tag = "type", content = "profile_action")]
pub enum ProfilePicAction {
   SetFirst { pic_id: String },
   Delete { pic_id: String }, 
   Update { pic_id: String }
}

#[derive(Serialize, Deserialize, Debug, Clone)]
#[serde(tag = "type", content = "serch_kind")]
pub enum SearchKind {
  OtherUser { key_term: String },
  MessageSet   { key_term: String } // we cant provide any helpful result with regard to message payload because we received encrypted  data, but we can just provide the data sent to this person and the client will fetch anything usefull on its own.
}