pub mod error;
pub mod redis_connect;
pub mod password;
pub mod mappers;
pub mod time_aware_lru;
pub mod encryption;

use base64::Engine;
pub use error::AppError;


use std::hash::{Hash, Hasher};
use std::collections::hash_map::DefaultHasher;
use sha2::{Sha512, Digest};
use base64::engine::general_purpose::STANDARD;

pub use encryption::{bytes_to_base64, generate_32_bytes, generate_12_bytes, base64_to_array};

pub fn hash_to_0_9(input: &str) -> u8 {
    let mut hasher = DefaultHasher::new();
    input.hash(&mut hasher);
    (hasher.finish() % 10) as u8
}

pub fn hash_string(input: &str) -> String {
    let mut hasher = Sha512::new(); 
    hasher.update(input.as_bytes());

    let result = hasher.finalize();

   STANDARD.encode(result)
}