use serde::{Serialize, Deserialize};
use crate::sessions::Session;


#[derive(Serialize, Deserialize, Debug)]
pub struct UserSession {
     pub installation_id: String,
     pub username: String,
     pub pub_key: String,
     pub unique_key: String,
     pub connected_at: i64,
     pub name: String,
     pub profile_pics: Vec<String>, 
     pub last_key: String,
     pub chats: Vec<String>
}


  impl Session for UserSession {
    type Key = String;

    fn get_key(&self) -> &Self::Key {
        &self.username
    }

    fn get_pub_key(&self) -> &String {
        &self.pub_key
    }

    fn get_installation_id(&self) -> &String {
        &self.installation_id
    }

    fn get_username(&self) -> &String {
        &self.username
    }

    fn get_time(&self) -> i64 {
        self.connected_at
    }

    fn get_unique_key(&self) -> &String {
        &self.unique_key
    }

    fn get_name(&self) -> &String {
        &self.name
    }

    fn get_profile_pics(&self) -> &Vec<String> {
        &self.profile_pics
    }

    fn get_last_key(&self) -> &String {
        &self.last_key
    }
    fn get_chats(&self) -> &Vec<String> {
        &self.chats
    }
}




